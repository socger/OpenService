-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.6.28-log - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando estructura de base de datos para facturascripts
DROP DATABASE IF EXISTS `facturascripts`;
CREATE DATABASE IF NOT EXISTS `facturascripts` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `facturascripts`;


-- Volcando estructura para tabla facturascripts.agenciastrans
DROP TABLE IF EXISTS `agenciastrans`;
CREATE TABLE IF NOT EXISTS `agenciastrans` (
  `codtrans` varchar(8) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `telefono` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `web` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`codtrans`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.agenciastrans: ~0 rows (aproximadamente)
DELETE FROM `agenciastrans`;
/*!40000 ALTER TABLE `agenciastrans` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenciastrans` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.agentes
DROP TABLE IF EXISTS `agentes`;
CREATE TABLE IF NOT EXISTS `agentes` (
  `apellidos` varchar(100) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin NOT NULL,
  `coddepartamento` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `dnicif` varchar(15) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `idusuario` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `nombreap` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `seg_social` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `cargo` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `banco` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `f_alta` date DEFAULT NULL,
  `f_baja` date DEFAULT NULL,
  `f_nacimiento` date DEFAULT NULL,
  PRIMARY KEY (`codagente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.agentes: ~0 rows (aproximadamente)
DELETE FROM `agentes`;
/*!40000 ALTER TABLE `agentes` DISABLE KEYS */;
INSERT INTO `agentes` (`apellidos`, `ciudad`, `codagente`, `coddepartamento`, `codpais`, `codpostal`, `direccion`, `dnicif`, `email`, `fax`, `idprovincia`, `idusuario`, `irpf`, `nombre`, `nombreap`, `porcomision`, `provincia`, `telefono`, `seg_social`, `cargo`, `banco`, `f_alta`, `f_baja`, `f_nacimiento`) VALUES
	('Pepe', NULL, '1', NULL, NULL, NULL, NULL, '00000014Z', NULL, NULL, NULL, NULL, NULL, 'Paco', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `agentes` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.albaranescli
DROP TABLE IF EXISTS `albaranescli`;
CREATE TABLE IF NOT EXISTS `albaranescli` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddir` int(11) DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time DEFAULT '00:00:00',
  `femail` date DEFAULT NULL,
  `idalbaran` int(11) NOT NULL AUTO_INCREMENT,
  `idfactura` int(11) DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nombrecliente` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numero2` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ptefactura` tinyint(1) NOT NULL DEFAULT '1',
  `recfinanciero` double NOT NULL DEFAULT '0',
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  `codtrans` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `codigoenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `nombreenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `apellidosenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `direccionenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostalenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `ciudadenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `provinciaenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idalbaran`),
  UNIQUE KEY `uniq_codigo_albaranescli` (`codigo`),
  KEY `ca_albaranescli_series2` (`codserie`),
  KEY `ca_albaranescli_ejercicios2` (`codejercicio`),
  CONSTRAINT `ca_albaranescli_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_albaranescli_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.albaranescli: ~0 rows (aproximadamente)
DELETE FROM `albaranescli`;
/*!40000 ALTER TABLE `albaranescli` DISABLE KEYS */;
/*!40000 ALTER TABLE `albaranescli` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.albaranesprov
DROP TABLE IF EXISTS `albaranesprov`;
CREATE TABLE IF NOT EXISTS `albaranesprov` (
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idalbaran` int(11) NOT NULL AUTO_INCREMENT,
  `idfactura` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numproveedor` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `ptefactura` tinyint(1) NOT NULL DEFAULT '1',
  `recfinanciero` double NOT NULL DEFAULT '0',
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`idalbaran`),
  UNIQUE KEY `uniq_codigo_albaranesprov` (`codigo`),
  KEY `ca_albaranesprov_series2` (`codserie`),
  KEY `ca_albaranesprov_ejercicios2` (`codejercicio`),
  CONSTRAINT `ca_albaranesprov_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_albaranesprov_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.albaranesprov: ~0 rows (aproximadamente)
DELETE FROM `albaranesprov`;
/*!40000 ALTER TABLE `albaranesprov` DISABLE KEYS */;
INSERT INTO `albaranesprov` (`cifnif`, `codagente`, `codalmacen`, `coddivisa`, `codejercicio`, `codigo`, `codpago`, `codproveedor`, `codserie`, `fecha`, `hora`, `idalbaran`, `idfactura`, `irpf`, `neto`, `nombre`, `numero`, `numproveedor`, `observaciones`, `ptefactura`, `recfinanciero`, `tasaconv`, `total`, `totaleuros`, `totalirpf`, `totaliva`, `totalrecargo`) VALUES
	('', '1', 'ALG', 'EUR', '2016', 'ALB2016A1C', 'CONT', '000001', 'A', '2016-04-18', '15:19:51', 1, NULL, 0, 1223.3, 'yo mismo', '1', '', '', 1, 0, 1, 1480.19, 1480.19, 0, 256.89, 0);
/*!40000 ALTER TABLE `albaranesprov` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.almacenes
DROP TABLE IF EXISTS `almacenes`;
CREATE TABLE IF NOT EXISTS `almacenes` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `observaciones` text COLLATE utf8_bin,
  `poblacion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `porpvp` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `telefono` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `tipovaloracion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codalmacen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.almacenes: ~0 rows (aproximadamente)
DELETE FROM `almacenes`;
/*!40000 ALTER TABLE `almacenes` DISABLE KEYS */;
INSERT INTO `almacenes` (`apartado`, `codalmacen`, `codpais`, `codpostal`, `contacto`, `direccion`, `fax`, `idprovincia`, `nombre`, `observaciones`, `poblacion`, `porpvp`, `provincia`, `telefono`, `tipovaloracion`) VALUES
	(NULL, 'ALG', NULL, '', '', '', '', NULL, 'ALMACEN GENERAL', NULL, '', NULL, NULL, '', NULL);
/*!40000 ALTER TABLE `almacenes` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.articulos
DROP TABLE IF EXISTS `articulos`;
CREATE TABLE IF NOT EXISTS `articulos` (
  `factualizado` date DEFAULT NULL,
  `bloqueado` tinyint(1) DEFAULT '0',
  `equivalencia` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuentairpfcom` int(11) DEFAULT NULL,
  `idsubcuentacom` int(11) DEFAULT NULL,
  `stockmin` double DEFAULT '0',
  `observaciones` text COLLATE utf8_bin,
  `codbarras` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `stockfis` double DEFAULT '0',
  `stockmax` double DEFAULT '0',
  `costemedio` double DEFAULT '0',
  `preciocoste` double DEFAULT '0',
  `tipocodbarras` varchar(8) COLLATE utf8_bin DEFAULT 'Code39',
  `nostock` tinyint(1) DEFAULT NULL,
  `codsubcuentacom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `codsubcuentairpfcom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `secompra` tinyint(1) DEFAULT NULL,
  `codfamilia` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `imagen` text COLLATE utf8_bin,
  `controlstock` tinyint(1) DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `tipo` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `pvp` double DEFAULT '0',
  `sevende` tinyint(1) DEFAULT NULL,
  `publico` tinyint(1) DEFAULT '0',
  `partnumber` varchar(38) COLLATE utf8_bin DEFAULT NULL,
  `codfabricante` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`referencia`),
  KEY `ca_articulos_impuestos2` (`codimpuesto`),
  CONSTRAINT `ca_articulos_impuestos2` FOREIGN KEY (`codimpuesto`) REFERENCES `impuestos` (`codimpuesto`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.articulos: ~6 rows (aproximadamente)
DELETE FROM `articulos`;
/*!40000 ALTER TABLE `articulos` DISABLE KEYS */;
INSERT INTO `articulos` (`factualizado`, `bloqueado`, `equivalencia`, `idsubcuentairpfcom`, `idsubcuentacom`, `stockmin`, `observaciones`, `codbarras`, `codimpuesto`, `stockfis`, `stockmax`, `costemedio`, `preciocoste`, `tipocodbarras`, `nostock`, `codsubcuentacom`, `descripcion`, `codsubcuentairpfcom`, `secompra`, `codfamilia`, `imagen`, `controlstock`, `referencia`, `tipo`, `pvp`, `sevende`, `publico`, `partnumber`, `codfabricante`) VALUES
	('2016-04-18', 0, NULL, NULL, NULL, 0, '', '', 'IVA21', 5, 0, 147.53, 147.53, 'Code39', 0, NULL, '0141520030 juego flector', NULL, 1, NULL, NULL, 1, '0141520030', NULL, 147.53, 1, 0, NULL, NULL);
INSERT INTO `articulos` (`factualizado`, `bloqueado`, `equivalencia`, `idsubcuentairpfcom`, `idsubcuentacom`, `stockmin`, `observaciones`, `codbarras`, `codimpuesto`, `stockfis`, `stockmax`, `costemedio`, `preciocoste`, `tipocodbarras`, `nostock`, `codsubcuentacom`, `descripcion`, `codsubcuentairpfcom`, `secompra`, `codfamilia`, `imagen`, `controlstock`, `referencia`, `tipo`, `pvp`, `sevende`, `publico`, `partnumber`, `codfabricante`) VALUES
	('2016-04-18', 0, NULL, NULL, NULL, 0, '', '', 'IVA21', 1, 0, 31.89, 31.89, 'Code39', 0, NULL, '101212 bomba agua citroen,peuge.', NULL, 1, NULL, NULL, 1, '101212', NULL, 31.89, 1, 0, NULL, NULL);
INSERT INTO `articulos` (`factualizado`, `bloqueado`, `equivalencia`, `idsubcuentairpfcom`, `idsubcuentacom`, `stockmin`, `observaciones`, `codbarras`, `codimpuesto`, `stockfis`, `stockmax`, `costemedio`, `preciocoste`, `tipocodbarras`, `nostock`, `codsubcuentacom`, `descripcion`, `codsubcuentairpfcom`, `secompra`, `codfamilia`, `imagen`, `controlstock`, `referencia`, `tipo`, `pvp`, `sevende`, `publico`, `partnumber`, `codfabricante`) VALUES
	('2016-04-18', 0, NULL, NULL, NULL, 0, '', '', 'IVA21', 3, 0, 63.11, 63.11, 'Code39', 0, NULL, 'tijera asiento isri 6000', NULL, 1, NULL, NULL, 1, '1212000', NULL, 63.11, 1, 0, NULL, NULL);
INSERT INTO `articulos` (`factualizado`, `bloqueado`, `equivalencia`, `idsubcuentairpfcom`, `idsubcuentacom`, `stockmin`, `observaciones`, `codbarras`, `codimpuesto`, `stockfis`, `stockmax`, `costemedio`, `preciocoste`, `tipocodbarras`, `nostock`, `codsubcuentacom`, `descripcion`, `codsubcuentairpfcom`, `secompra`, `codfamilia`, `imagen`, `controlstock`, `referencia`, `tipo`, `pvp`, `sevende`, `publico`, `partnumber`, `codfabricante`) VALUES
	('2016-04-18', 0, NULL, NULL, NULL, 0, '', '', 'IVA21', 5, 0, 22.8, 22.8, 'Code39', 0, NULL, 'valvula expansion conica 1.5t', NULL, 1, NULL, NULL, 1, '1212008', NULL, 22.8, 1, 0, NULL, NULL);
INSERT INTO `articulos` (`factualizado`, `bloqueado`, `equivalencia`, `idsubcuentairpfcom`, `idsubcuentacom`, `stockmin`, `observaciones`, `codbarras`, `codimpuesto`, `stockfis`, `stockmax`, `costemedio`, `preciocoste`, `tipocodbarras`, `nostock`, `codsubcuentacom`, `descripcion`, `codsubcuentairpfcom`, `secompra`, `codfamilia`, `imagen`, `controlstock`, `referencia`, `tipo`, `pvp`, `sevende`, `publico`, `partnumber`, `codfabricante`) VALUES
	('2016-04-18', 0, NULL, NULL, NULL, 0, '', '', 'IVA21', 7, 0, 21.49, 21.49, 'Code39', 0, NULL, 'valvula expansion mb 126*r21', NULL, 1, NULL, NULL, 1, '1212101', NULL, 21.49, 1, 0, NULL, NULL);
INSERT INTO `articulos` (`factualizado`, `bloqueado`, `equivalencia`, `idsubcuentairpfcom`, `idsubcuentacom`, `stockmin`, `observaciones`, `codbarras`, `codimpuesto`, `stockfis`, `stockmax`, `costemedio`, `preciocoste`, `tipocodbarras`, `nostock`, `codsubcuentacom`, `descripcion`, `codsubcuentairpfcom`, `secompra`, `codfamilia`, `imagen`, `controlstock`, `referencia`, `tipo`, `pvp`, `sevende`, `publico`, `partnumber`, `codfabricante`) VALUES
	('2016-04-18', 0, NULL, NULL, NULL, 0, '', '', 'IVA21', 0, 0, 0, 0, 'Code39', 0, NULL, 'articulo con descripcion uno', NULL, 1, 'VARI', NULL, 1, 'Articulo1', NULL, 0, 1, 0, NULL, NULL);
/*!40000 ALTER TABLE `articulos` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.articulosprov
DROP TABLE IF EXISTS `articulosprov`;
CREATE TABLE IF NOT EXISTS `articulosprov` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `refproveedor` varchar(25) COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin,
  `precio` double DEFAULT NULL,
  `dto` double DEFAULT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `stock` double DEFAULT NULL,
  `nostock` tinyint(1) DEFAULT '1',
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codbarras` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `partnumber` varchar(38) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_articulo_proveedor2` (`codproveedor`,`refproveedor`),
  CONSTRAINT `ca_articulosprov_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.articulosprov: ~4 rows (aproximadamente)
DELETE FROM `articulosprov`;
/*!40000 ALTER TABLE `articulosprov` DISABLE KEYS */;
INSERT INTO `articulosprov` (`id`, `referencia`, `codproveedor`, `refproveedor`, `descripcion`, `precio`, `dto`, `codimpuesto`, `stock`, `nostock`, `nombre`, `coddivisa`, `codbarras`, `partnumber`) VALUES
	(1, '101212', '000001', '101212', '101212 bomba agua citroen,peuge.', 31.89, 0, 'IVA21', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `articulosprov` (`id`, `referencia`, `codproveedor`, `refproveedor`, `descripcion`, `precio`, `dto`, `codimpuesto`, `stock`, `nostock`, `nombre`, `coddivisa`, `codbarras`, `partnumber`) VALUES
	(2, '1212008', '000001', '1212008', 'valvula expansion conica 1.5t', 22.8, 0, 'IVA21', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `articulosprov` (`id`, `referencia`, `codproveedor`, `refproveedor`, `descripcion`, `precio`, `dto`, `codimpuesto`, `stock`, `nostock`, `nombre`, `coddivisa`, `codbarras`, `partnumber`) VALUES
	(3, '1212000', '000001', '1212000', 'tijera asiento isri 6000', 63.11, 0, 'IVA21', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `articulosprov` (`id`, `referencia`, `codproveedor`, `refproveedor`, `descripcion`, `precio`, `dto`, `codimpuesto`, `stock`, `nostock`, `nombre`, `coddivisa`, `codbarras`, `partnumber`) VALUES
	(4, '1212101', '000001', '1212101', 'valvula expansion mb 126*r21', 21.49, 0, 'IVA21', 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO `articulosprov` (`id`, `referencia`, `codproveedor`, `refproveedor`, `descripcion`, `precio`, `dto`, `codimpuesto`, `stock`, `nostock`, `nombre`, `coddivisa`, `codbarras`, `partnumber`) VALUES
	(5, '0141520030', '000001', '0141520030', '0141520030 juego flector', 147.53, 0, 'IVA21', 0, 1, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `articulosprov` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.articulo_propiedades
DROP TABLE IF EXISTS `articulo_propiedades`;
CREATE TABLE IF NOT EXISTS `articulo_propiedades` (
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `text` text COLLATE utf8_bin,
  PRIMARY KEY (`name`,`referencia`),
  KEY `ca_articulo_propiedades_articulos` (`referencia`),
  CONSTRAINT `ca_articulo_propiedades_articulos` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.articulo_propiedades: ~0 rows (aproximadamente)
DELETE FROM `articulo_propiedades`;
/*!40000 ALTER TABLE `articulo_propiedades` DISABLE KEYS */;
/*!40000 ALTER TABLE `articulo_propiedades` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.atributos
DROP TABLE IF EXISTS `atributos`;
CREATE TABLE IF NOT EXISTS `atributos` (
  `codatributo` varchar(8) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codatributo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.atributos: ~0 rows (aproximadamente)
DELETE FROM `atributos`;
/*!40000 ALTER TABLE `atributos` DISABLE KEYS */;
/*!40000 ALTER TABLE `atributos` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.cajas
DROP TABLE IF EXISTS `cajas`;
CREATE TABLE IF NOT EXISTS `cajas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fs_id` int(11) NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin NOT NULL,
  `f_inicio` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `d_inicio` double NOT NULL DEFAULT '0',
  `f_fin` timestamp NULL DEFAULT NULL,
  `d_fin` double DEFAULT NULL,
  `tickets` int(11) DEFAULT NULL,
  `ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.cajas: ~0 rows (aproximadamente)
DELETE FROM `cajas`;
/*!40000 ALTER TABLE `cajas` DISABLE KEYS */;
/*!40000 ALTER TABLE `cajas` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.cajas_terminales
DROP TABLE IF EXISTS `cajas_terminales`;
CREATE TABLE IF NOT EXISTS `cajas_terminales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `tickets` text COLLATE utf8_bin,
  `anchopapel` int(11) DEFAULT NULL,
  `comandocorte` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `comandoapertura` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `num_tickets` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.cajas_terminales: ~0 rows (aproximadamente)
DELETE FROM `cajas_terminales`;
/*!40000 ALTER TABLE `cajas_terminales` DISABLE KEYS */;
/*!40000 ALTER TABLE `cajas_terminales` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.clientes
DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `capitalimpagado` double DEFAULT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `codcontacto` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentadom` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentarem` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codedi` varchar(17) COLLATE utf8_bin DEFAULT NULL,
  `codgrupo` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codtiporappel` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `copiasfactura` int(11) DEFAULT NULL,
  `debaja` tinyint(1) DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `fechabaja` date DEFAULT NULL,
  `fechaalta` date DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `ivaincluido` tinyint(1) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `razonsocial` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `recargo` tinyint(1) DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `riesgoalcanzado` double DEFAULT NULL,
  `riesgomax` double DEFAULT NULL,
  `telefono1` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `telefono2` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tipoidfiscal` varchar(25) COLLATE utf8_bin NOT NULL DEFAULT 'NIF',
  `personafisica` tinyint(1) DEFAULT '1',
  `web` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.clientes: ~0 rows (aproximadamente)
DELETE FROM `clientes`;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_asientos
DROP TABLE IF EXISTS `co_asientos`;
CREATE TABLE IF NOT EXISTS `co_asientos` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codplanasiento` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `documento` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `editable` tinyint(1) NOT NULL,
  `fecha` date NOT NULL,
  `idasiento` int(11) NOT NULL AUTO_INCREMENT,
  `idconcepto` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `importe` double DEFAULT NULL,
  `numero` int(11) NOT NULL,
  `tipodocumento` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idasiento`),
  KEY `ca_co_asientos_ejercicios2` (`codejercicio`),
  CONSTRAINT `ca_co_asientos_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_asientos: ~0 rows (aproximadamente)
DELETE FROM `co_asientos`;
/*!40000 ALTER TABLE `co_asientos` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_asientos` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_codbalances08
DROP TABLE IF EXISTS `co_codbalances08`;
CREATE TABLE IF NOT EXISTS `co_codbalances08` (
  `descripcion4ba` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `descripcion4` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel4` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion3` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `orden3` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `nivel3` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion2` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel2` int(11) DEFAULT NULL,
  `descripcion1` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel1` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `naturaleza` varchar(15) COLLATE utf8_bin NOT NULL,
  `codbalance` varchar(15) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codbalance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_codbalances08: ~0 rows (aproximadamente)
DELETE FROM `co_codbalances08`;
/*!40000 ALTER TABLE `co_codbalances08` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_codbalances08` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_conceptospar
DROP TABLE IF EXISTS `co_conceptospar`;
CREATE TABLE IF NOT EXISTS `co_conceptospar` (
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idconceptopar` varchar(4) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idconceptopar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_conceptospar: ~0 rows (aproximadamente)
DELETE FROM `co_conceptospar`;
/*!40000 ALTER TABLE `co_conceptospar` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_conceptospar` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_cuentas
DROP TABLE IF EXISTS `co_cuentas`;
CREATE TABLE IF NOT EXISTS `co_cuentas` (
  `codbalance` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codepigrafe` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `idcuentaesp` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `idepigrafe` int(11) NOT NULL,
  PRIMARY KEY (`idcuenta`),
  UNIQUE KEY `uniq_codcuenta` (`codcuenta`,`codejercicio`),
  KEY `ca_co_cuentas_ejercicios` (`codejercicio`),
  KEY `ca_co_cuentas_epigrafes2` (`idepigrafe`),
  CONSTRAINT `ca_co_cuentas_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_cuentas_epigrafes2` FOREIGN KEY (`idepigrafe`) REFERENCES `co_epigrafes` (`idepigrafe`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_cuentas: ~0 rows (aproximadamente)
DELETE FROM `co_cuentas`;
/*!40000 ALTER TABLE `co_cuentas` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_cuentas` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_cuentascbba
DROP TABLE IF EXISTS `co_cuentascbba`;
CREATE TABLE IF NOT EXISTS `co_cuentascbba` (
  `desccuenta` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codbalance` varchar(15) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_cuentascbba: ~0 rows (aproximadamente)
DELETE FROM `co_cuentascbba`;
/*!40000 ALTER TABLE `co_cuentascbba` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_cuentascbba` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_cuentasesp
DROP TABLE IF EXISTS `co_cuentasesp`;
CREATE TABLE IF NOT EXISTS `co_cuentasesp` (
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idcuentaesp` varchar(6) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idcuentaesp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_cuentasesp: ~29 rows (aproximadamente)
DELETE FROM `co_cuentasesp`;
/*!40000 ALTER TABLE `co_cuentasesp` DISABLE KEYS */;
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de acreedores', 'ACREED');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de caja', 'CAJA');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de diferencias negativas de cambio', 'CAMNEG');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de diferencias positivas de cambio', 'CAMPOS');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de clientes', 'CLIENT');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de compras', 'COMPRA');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Devoluciones de compras', 'DEVCOM');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Devoluciones de ventas', 'DEVVEN');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas por diferencias positivas en divisa extranjera', 'DIVPOS');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas por diferencias negativas de conversión a la moneda local', 'EURNEG');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas por diferencias positivas de conversión a la moneda local', 'EURPOS');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Gastos por recargo financiero', 'GTORF');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Ingresos por recargo financiero', 'INGRF');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de retenciones IRPF', 'IRPF');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de retenciones para proveedores IRPFPR', 'IRPFPR');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas acreedoras de IVA en la regularización', 'IVAACR');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas deudoras de IVA en la regularización', 'IVADEU');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'IVA en entregas intracomunitarias U.E.', 'IVAEUE');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de IVA repercutido', 'IVAREP');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de IVA repercutido para clientes exentos de IVA', 'IVAREX');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de IVA soportado UE', 'IVARUE');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de IVA repercutido en exportaciones', 'IVARXP');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de IVA soportado en importaciones', 'IVASIM');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de IVA soportado', 'IVASOP');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de IVA soportado UE', 'IVASUE');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas relativas al ejercicio previo', 'PREVIO');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de proveedores', 'PROVEE');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Pérdidas y ganancias', 'PYG');
INSERT INTO `co_cuentasesp` (`codcuenta`, `codsubcuenta`, `descripcion`, `idcuentaesp`) VALUES
	(NULL, NULL, 'Cuentas de ventas', 'VENTAS');
/*!40000 ALTER TABLE `co_cuentasesp` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_epigrafes
DROP TABLE IF EXISTS `co_epigrafes`;
CREATE TABLE IF NOT EXISTS `co_epigrafes` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codepigrafe` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idepigrafe` int(11) NOT NULL AUTO_INCREMENT,
  `idgrupo` int(11) DEFAULT NULL,
  `idpadre` int(11) DEFAULT NULL,
  PRIMARY KEY (`idepigrafe`),
  KEY `ca_co_epigrafes_ejercicios` (`codejercicio`),
  KEY `ca_co_epigrafes_gruposepigrafes2` (`idgrupo`),
  CONSTRAINT `ca_co_epigrafes_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_epigrafes_gruposepigrafes2` FOREIGN KEY (`idgrupo`) REFERENCES `co_gruposepigrafes` (`idgrupo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_epigrafes: ~0 rows (aproximadamente)
DELETE FROM `co_epigrafes`;
/*!40000 ALTER TABLE `co_epigrafes` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_epigrafes` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_gruposepigrafes
DROP TABLE IF EXISTS `co_gruposepigrafes`;
CREATE TABLE IF NOT EXISTS `co_gruposepigrafes` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codgrupo` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idgrupo` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idgrupo`),
  KEY `ca_co_gruposepigrafes_ejercicios` (`codejercicio`),
  CONSTRAINT `ca_co_gruposepigrafes_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_gruposepigrafes: ~0 rows (aproximadamente)
DELETE FROM `co_gruposepigrafes`;
/*!40000 ALTER TABLE `co_gruposepigrafes` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_gruposepigrafes` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_regiva
DROP TABLE IF EXISTS `co_regiva`;
CREATE TABLE IF NOT EXISTS `co_regiva` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codsubcuentaacr` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentadeu` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `fechaasiento` date NOT NULL,
  `fechafin` date NOT NULL,
  `fechainicio` date NOT NULL,
  `idasiento` int(11) NOT NULL,
  `idregiva` int(11) NOT NULL AUTO_INCREMENT,
  `idsubcuentaacr` int(11) DEFAULT NULL,
  `idsubcuentadeu` int(11) DEFAULT NULL,
  `periodo` varchar(8) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idregiva`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_regiva: ~0 rows (aproximadamente)
DELETE FROM `co_regiva`;
/*!40000 ALTER TABLE `co_regiva` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_regiva` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_secuencias
DROP TABLE IF EXISTS `co_secuencias`;
CREATE TABLE IF NOT EXISTS `co_secuencias` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `idsecuencia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `valor` int(11) DEFAULT NULL,
  `valorout` int(11) DEFAULT NULL,
  PRIMARY KEY (`idsecuencia`),
  KEY `ca_co_secuencias_ejercicios` (`codejercicio`),
  CONSTRAINT `ca_co_secuencias_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_secuencias: ~0 rows (aproximadamente)
DELETE FROM `co_secuencias`;
/*!40000 ALTER TABLE `co_secuencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_secuencias` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.co_subcuentas
DROP TABLE IF EXISTS `co_subcuentas`;
CREATE TABLE IF NOT EXISTS `co_subcuentas` (
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `debe` double NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `haber` double NOT NULL,
  `idcuenta` int(11) DEFAULT NULL,
  `idsubcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `iva` double NOT NULL,
  `recargo` double NOT NULL,
  `saldo` double NOT NULL,
  PRIMARY KEY (`idsubcuenta`),
  UNIQUE KEY `uniq_codsubcuenta` (`codsubcuenta`,`codejercicio`),
  KEY `ca_co_subcuentas_ejercicios` (`codejercicio`),
  KEY `ca_co_subcuentas_cuentas2` (`idcuenta`),
  CONSTRAINT `ca_co_subcuentas_cuentas2` FOREIGN KEY (`idcuenta`) REFERENCES `co_cuentas` (`idcuenta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_subcuentas_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.co_subcuentas: ~0 rows (aproximadamente)
DELETE FROM `co_subcuentas`;
/*!40000 ALTER TABLE `co_subcuentas` DISABLE KEYS */;
/*!40000 ALTER TABLE `co_subcuentas` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.cuentasbanco
DROP TABLE IF EXISTS `cuentasbanco`;
CREATE TABLE IF NOT EXISTS `cuentasbanco` (
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codcuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.cuentasbanco: ~0 rows (aproximadamente)
DELETE FROM `cuentasbanco`;
/*!40000 ALTER TABLE `cuentasbanco` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuentasbanco` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.cuentasbcocli
DROP TABLE IF EXISTS `cuentasbcocli`;
CREATE TABLE IF NOT EXISTS `cuentasbcocli` (
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  `ctaentidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `agencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `entidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `ctaagencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `cuenta` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `principal` tinyint(1) DEFAULT NULL,
  `fmandato` date DEFAULT NULL,
  PRIMARY KEY (`codcuenta`),
  KEY `ca_cuentasbcocli_clientes` (`codcliente`),
  CONSTRAINT `ca_cuentasbcocli_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.cuentasbcocli: ~0 rows (aproximadamente)
DELETE FROM `cuentasbcocli`;
/*!40000 ALTER TABLE `cuentasbcocli` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuentasbcocli` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.cuentasbcopro
DROP TABLE IF EXISTS `cuentasbcopro`;
CREATE TABLE IF NOT EXISTS `cuentasbcopro` (
  `agencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `ctaagencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `ctaentidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `cuenta` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `entidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  `principal` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`codcuenta`),
  KEY `ca_cuentasbcopro_proveedores` (`codproveedor`),
  CONSTRAINT `ca_cuentasbcopro_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.cuentasbcopro: ~0 rows (aproximadamente)
DELETE FROM `cuentasbcopro`;
/*!40000 ALTER TABLE `cuentasbcopro` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuentasbcopro` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.detalles_garantias
DROP TABLE IF EXISTS `detalles_garantias`;
CREATE TABLE IF NOT EXISTS `detalles_garantias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `ngarantias` int(11) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_detalle_garantias` (`ngarantias`),
  CONSTRAINT `ca_detalle_garantias` FOREIGN KEY (`ngarantias`) REFERENCES `registros_garantias` (`ngarantias`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.detalles_garantias: ~0 rows (aproximadamente)
DELETE FROM `detalles_garantias`;
/*!40000 ALTER TABLE `detalles_garantias` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalles_garantias` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.divisas
DROP TABLE IF EXISTS `divisas`;
CREATE TABLE IF NOT EXISTS `divisas` (
  `bandera` text COLLATE utf8_bin,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codiso` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `simbolo` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `tasaconv` double NOT NULL,
  `tasaconv_compra` double DEFAULT NULL,
  PRIMARY KEY (`coddivisa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.divisas: ~9 rows (aproximadamente)
DELETE FROM `divisas`;
/*!40000 ALTER TABLE `divisas` DISABLE KEYS */;
INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
	(NULL, 'ARS', '32', 'PESOS (ARG)', NULL, '$', 10.83, NULL);
INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
	(NULL, 'CLP', '152', 'PESOS (CLP)', NULL, '$', 755.73, NULL);
INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
	(NULL, 'COP', '170', 'PESOS (COP)', NULL, '$', 2573, NULL);
INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
	(NULL, 'EUR', '978', 'EUROS', NULL, '€', 1, NULL);
INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
	(NULL, 'MXN', '484', 'PESOS (MXN)', NULL, '$', 18.1, NULL);
INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
	(NULL, 'PAB', '590', 'BALBOAS', NULL, 'B', 38.17, NULL);
INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
	(NULL, 'PEN', '604', 'NUEVOS SOLES', NULL, 'S/.', 3.52, NULL);
INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
	(NULL, 'USD', '840', 'DÓLARES EE.UU.', NULL, '$', 1.36, NULL);
INSERT INTO `divisas` (`bandera`, `coddivisa`, `codiso`, `descripcion`, `fecha`, `simbolo`, `tasaconv`, `tasaconv_compra`) VALUES
	(NULL, 'VEF', '937', 'BOLÍVARES', NULL, 'Bs', 38.17, NULL);
/*!40000 ALTER TABLE `divisas` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.ejercicios
DROP TABLE IF EXISTS `ejercicios`;
CREATE TABLE IF NOT EXISTS `ejercicios` (
  `idasientocierre` int(11) DEFAULT NULL,
  `idasientopyg` int(11) DEFAULT NULL,
  `idasientoapertura` int(11) DEFAULT NULL,
  `plancontable` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `longsubcuenta` int(11) DEFAULT NULL,
  `estado` varchar(15) COLLATE utf8_bin NOT NULL,
  `fechafin` date NOT NULL,
  `fechainicio` date NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codejercicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.ejercicios: ~0 rows (aproximadamente)
DELETE FROM `ejercicios`;
/*!40000 ALTER TABLE `ejercicios` DISABLE KEYS */;
INSERT INTO `ejercicios` (`idasientocierre`, `idasientopyg`, `idasientoapertura`, `plancontable`, `longsubcuenta`, `estado`, `fechafin`, `fechainicio`, `nombre`, `codejercicio`) VALUES
	(NULL, NULL, NULL, '08', 10, 'ABIERTO', '2016-12-31', '2016-01-01', '2016', '2016');
/*!40000 ALTER TABLE `ejercicios` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.empresa
DROP TABLE IF EXISTS `empresa`;
CREATE TABLE IF NOT EXISTS `empresa` (
  `administrador` varchar(100) COLLATE utf8_bin NOT NULL,
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuentarem` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codedi` varchar(17) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `contintegrada` tinyint(1) DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `horario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idprovincia` int(11) DEFAULT NULL,
  `xid` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `lema` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `logo` text COLLATE utf8_bin,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `nombrecorto` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `pie_factura` text COLLATE utf8_bin,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `recequivalencia` tinyint(1) DEFAULT NULL,
  `stockpedidos` tinyint(1) DEFAULT NULL,
  `telefono` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `web` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `inicioact` date DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.empresa: ~0 rows (aproximadamente)
DELETE FROM `empresa`;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` (`administrador`, `apartado`, `cifnif`, `ciudad`, `codalmacen`, `codcuentarem`, `coddivisa`, `codedi`, `codejercicio`, `codpago`, `codpais`, `codpostal`, `codserie`, `contintegrada`, `direccion`, `email`, `fax`, `horario`, `id`, `idprovincia`, `xid`, `lema`, `logo`, `nombre`, `nombrecorto`, `pie_factura`, `provincia`, `recequivalencia`, `stockpedidos`, `telefono`, `web`, `inicioact`, `regimeniva`) VALUES
	('', '', '00000014Z', '', 'ALG', NULL, 'EUR', NULL, '2016', 'CONT', 'ESP', '', 'A', 1, 'C/ Falsa, 123', '', '', '', 1, NULL, 'JbngdjEhukVqAF0H9t38icNr5MoO1B', '', NULL, 'Empresa 264 S.L.', 'E-264', '', '', 0, 0, '', 'https://www.facturascripts.com', '1970-01-01', NULL);
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.fabricantes
DROP TABLE IF EXISTS `fabricantes`;
CREATE TABLE IF NOT EXISTS `fabricantes` (
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codfabricante` varchar(8) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codfabricante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.fabricantes: ~0 rows (aproximadamente)
DELETE FROM `fabricantes`;
/*!40000 ALTER TABLE `fabricantes` DISABLE KEYS */;
INSERT INTO `fabricantes` (`nombre`, `codfabricante`) VALUES
	('OEM', 'OEM');
/*!40000 ALTER TABLE `fabricantes` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.facturascli
DROP TABLE IF EXISTS `facturascli`;
CREATE TABLE IF NOT EXISTS `facturascli` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `automatica` tinyint(1) DEFAULT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddir` int(11) DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codigorect` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `deabono` tinyint(1) DEFAULT '0',
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `editable` tinyint(1) DEFAULT '0',
  `fecha` date NOT NULL,
  `vencimiento` date DEFAULT NULL,
  `femail` date DEFAULT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idasiento` int(11) DEFAULT NULL,
  `idasientop` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL AUTO_INCREMENT,
  `idfacturarect` int(11) DEFAULT NULL,
  `idpagodevol` int(11) DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `irpf` double NOT NULL,
  `neto` double NOT NULL,
  `nogenerarasiento` tinyint(1) DEFAULT NULL,
  `nombrecliente` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numero2` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `pagada` tinyint(1) NOT NULL DEFAULT '0',
  `anulada` tinyint(1) NOT NULL DEFAULT '0',
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `recfinanciero` double DEFAULT NULL,
  `tasaconv` double NOT NULL,
  `total` double NOT NULL,
  `totaleuros` double NOT NULL,
  `totalirpf` double NOT NULL,
  `totaliva` double NOT NULL,
  `totalrecargo` double DEFAULT NULL,
  `tpv` tinyint(1) DEFAULT NULL,
  `codtrans` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `codigoenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `nombreenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `apellidosenv` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `direccionenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostalenv` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `ciudadenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `provinciaenv` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idfactura`),
  UNIQUE KEY `uniq_codigo_facturascli` (`codigo`),
  KEY `ca_facturascli_series2` (`codserie`),
  KEY `ca_facturascli_ejercicios2` (`codejercicio`),
  KEY `ca_facturascli_asiento2` (`idasiento`),
  KEY `ca_facturascli_asientop` (`idasientop`),
  CONSTRAINT `ca_facturascli_asiento2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturascli_asientop` FOREIGN KEY (`idasientop`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturascli_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_facturascli_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.facturascli: ~0 rows (aproximadamente)
DELETE FROM `facturascli`;
/*!40000 ALTER TABLE `facturascli` DISABLE KEYS */;
/*!40000 ALTER TABLE `facturascli` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.facturasprov
DROP TABLE IF EXISTS `facturasprov`;
CREATE TABLE IF NOT EXISTS `facturasprov` (
  `automatica` tinyint(1) DEFAULT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(20) COLLATE utf8_bin NOT NULL,
  `codigorect` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `deabono` tinyint(1) DEFAULT '0',
  `editable` tinyint(1) DEFAULT '0',
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idasiento` int(11) DEFAULT NULL,
  `idasientop` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL AUTO_INCREMENT,
  `idfacturarect` int(11) DEFAULT NULL,
  `idpagodevol` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `neto` double DEFAULT NULL,
  `nogenerarasiento` tinyint(1) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numproveedor` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `pagada` tinyint(1) NOT NULL DEFAULT '0',
  `anulada` tinyint(1) NOT NULL DEFAULT '0',
  `recfinanciero` double DEFAULT NULL,
  `tasaconv` double NOT NULL,
  `total` double DEFAULT NULL,
  `totaleuros` double DEFAULT NULL,
  `totalirpf` double DEFAULT NULL,
  `totaliva` double DEFAULT NULL,
  `totalrecargo` double DEFAULT NULL,
  PRIMARY KEY (`idfactura`),
  UNIQUE KEY `uniq_codigo_facturasprov` (`codigo`),
  KEY `ca_facturasprov_series2` (`codserie`),
  KEY `ca_facturasprov_ejercicios2` (`codejercicio`),
  KEY `ca_facturasprov_asiento2` (`idasiento`),
  KEY `ca_facturasprov_asientop` (`idasientop`),
  CONSTRAINT `ca_facturasprov_asiento2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturasprov_asientop` FOREIGN KEY (`idasientop`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturasprov_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_facturasprov_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.facturasprov: ~0 rows (aproximadamente)
DELETE FROM `facturasprov`;
/*!40000 ALTER TABLE `facturasprov` DISABLE KEYS */;
/*!40000 ALTER TABLE `facturasprov` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.familias
DROP TABLE IF EXISTS `familias`;
CREATE TABLE IF NOT EXISTS `familias` (
  `descripcion` varchar(100) COLLATE utf8_bin NOT NULL,
  `codfamilia` varchar(8) COLLATE utf8_bin NOT NULL,
  `madre` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codfamilia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.familias: ~0 rows (aproximadamente)
DELETE FROM `familias`;
/*!40000 ALTER TABLE `familias` DISABLE KEYS */;
INSERT INTO `familias` (`descripcion`, `codfamilia`, `madre`) VALUES
	('VARIOS', 'VARI', NULL);
/*!40000 ALTER TABLE `familias` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.formaspago
DROP TABLE IF EXISTS `formaspago`;
CREATE TABLE IF NOT EXISTS `formaspago` (
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `genrecibos` varchar(10) COLLATE utf8_bin NOT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `domiciliado` tinyint(1) DEFAULT NULL,
  `vencimiento` varchar(20) COLLATE utf8_bin DEFAULT '+1month',
  PRIMARY KEY (`codpago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.formaspago: ~3 rows (aproximadamente)
DELETE FROM `formaspago`;
/*!40000 ALTER TABLE `formaspago` DISABLE KEYS */;
INSERT INTO `formaspago` (`codpago`, `descripcion`, `genrecibos`, `codcuenta`, `domiciliado`, `vencimiento`) VALUES
	('CONT', 'Al contado', 'Pagados', NULL, 0, '+1month');
INSERT INTO `formaspago` (`codpago`, `descripcion`, `genrecibos`, `codcuenta`, `domiciliado`, `vencimiento`) VALUES
	('PAYPAL', 'PayPal', 'Pagados', NULL, 0, '+1week');
INSERT INTO `formaspago` (`codpago`, `descripcion`, `genrecibos`, `codcuenta`, `domiciliado`, `vencimiento`) VALUES
	('TRANS', 'Transferencia bancaria', 'Emitidos', NULL, 0, '+1month');
/*!40000 ALTER TABLE `formaspago` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.fs_extensions2
DROP TABLE IF EXISTS `fs_extensions2`;
CREATE TABLE IF NOT EXISTS `fs_extensions2` (
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `page_from` varchar(30) COLLATE utf8_bin NOT NULL,
  `page_to` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `text` text COLLATE utf8_bin,
  `params` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`,`page_from`),
  KEY `ca_fs_extensions2_fs_pages` (`page_from`),
  CONSTRAINT `ca_fs_extensions2_fs_pages` FOREIGN KEY (`page_from`) REFERENCES `fs_pages` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.fs_extensions2: ~33 rows (aproximadamente)
DELETE FROM `fs_extensions2`;
/*!40000 ALTER TABLE `fs_extensions2` DISABLE KEYS */;
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('agrupar_albaranes', 'compras_agrupar_albaranes', 'compras_albaranes', 'button', '<span class="glyphicon glyphicon-duplicate"></span><span class="hidden-xs">&nbsp; Agrupar</span>', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('agrupar_albaranes', 'ventas_agrupar_albaranes', 'ventas_albaranes', 'button', '<span class="glyphicon glyphicon-duplicate"></span><span class="hidden-xs">&nbsp; Agrupar</span>', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('albaranes_agente', 'compras_albaranes', 'admin_agente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Albaranes de proveedor', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('albaranes_agente', 'ventas_albaranes', 'admin_agente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Albaranes de cliente', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('albaranes_articulo', 'compras_albaranes', 'ventas_articulo', 'tab_button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Albaranes de proveedor', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('albaranes_articulo', 'ventas_albaranes', 'ventas_articulo', 'tab_button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Albaranes de cliente', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('albaranes_cliente', 'ventas_albaranes', 'ventas_cliente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Albaranes', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('albaranes_proveedor', 'compras_albaranes', 'compras_proveedor', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Albaranes', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('api_remote_printer', 'tpv_recambios', NULL, 'api', 'remote_printer', NULL);
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('articulo_subcuentas', 'articulo_subcuentas', 'ventas_articulo', 'tab', '<span class="glyphicon glyphicon-book" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Subcuentas</span>', NULL);
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('btn_albaran', 'compras_actualiza_arts', 'compras_albaran', 'tab', '<span class="glyphicon glyphicon-share" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Actualizar</span>', '&doc=albaran');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('btn_atributos', 'ventas_atributos', 'ventas_articulos', 'button', '<span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span><span class="hidden-xs"> &nbsp; Atributos</span>', NULL);
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('btn_fabricantes', 'ventas_fabricantes', 'ventas_articulos', 'button', '<span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span><span class="hidden-xs"> &nbsp; Fabricantes</span>', NULL);
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('btn_familias', 'ventas_familias', 'ventas_articulos', 'button', '<span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span><span class="hidden-xs"> &nbsp; Familias</span>', NULL);
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('btn_pedido', 'compras_actualiza_arts', 'compras_pedido', 'tab', '<span class="glyphicon glyphicon-share" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Actualizar</span>', '&doc=pedido');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('email_albaran', 'ventas_imprimir', 'ventas_albaran', 'email', 'Albarán simple', '&albaran=TRUE');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('email_albaran_proveedor', 'compras_imprimir', 'compras_albaran', 'email', 'Albarán simple', '&albaran=TRUE');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('email_factura', 'ventas_imprimir', 'ventas_factura', 'email', 'Factura simple', '&factura=TRUE&tipo=simple');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('facturas_agente', 'compras_facturas', 'admin_agente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas de proveedor', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('facturas_agente', 'ventas_facturas', 'admin_agente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas de cliente', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('facturas_articulo', 'compras_facturas', 'ventas_articulo', 'tab_button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas de proveedor', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('facturas_articulo', 'ventas_facturas', 'ventas_articulo', 'tab_button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas de cliente', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('facturas_cliente', 'ventas_facturas', 'ventas_cliente', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('facturas_proveedor', 'compras_facturas', 'compras_proveedor', 'button', '<span class="glyphicon glyphicon-list" aria-hidden="true"></span> &nbsp; Facturas', '');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('imprimir_albaran', 'ventas_imprimir', 'ventas_albaran', 'pdf', 'Albarán simple', '&albaran=TRUE');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('imprimir_albaran_noval', 'ventas_imprimir', 'ventas_albaran', 'pdf', 'Albarán sin valorar', '&albaran=TRUE&noval=TRUE');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('imprimir_albaran_proveedor', 'compras_imprimir', 'compras_albaran', 'pdf', 'Albarán simple', '&albaran=TRUE');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('imprimir_factura', 'ventas_imprimir', 'ventas_factura', 'pdf', 'Factura simple', '&factura=TRUE&tipo=simple');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('imprimir_factura_carta', 'ventas_imprimir', 'ventas_factura', 'pdf', 'Modelo carta', '&factura=TRUE&tipo=carta');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('imprimir_factura_proveedor', 'compras_imprimir', 'compras_factura', 'pdf', 'Factura simple', '&factura=TRUE');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('informe_articulo', 'informe_articulos', 'ventas_articulo', 'tab_button', '<span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> &nbsp; Informe', '&tab=varios');
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('opciones_clientes', 'ventas_clientes_opciones', 'ventas_clientes', 'button', '<span class="glyphicon glyphicon-cog" aria-hidden="true" title="Opciones para nuevos clientes"></span>', NULL);
INSERT INTO `fs_extensions2` (`name`, `page_from`, `page_to`, `type`, `text`, `params`) VALUES
	('tab_devoluciones', 'ventas_factura_devolucion', 'ventas_factura', 'tab', '<span class="glyphicon glyphicon-share" aria-hidden="true"></span><span class="hidden-xs">&nbsp; Devoluciones</span>', NULL);
/*!40000 ALTER TABLE `fs_extensions2` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.fs_logs
DROP TABLE IF EXISTS `fs_logs`;
CREATE TABLE IF NOT EXISTS `fs_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) COLLATE utf8_bin NOT NULL,
  `detalle` text COLLATE utf8_bin NOT NULL,
  `fecha` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `usuario` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `alerta` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.fs_logs: ~24 rows (aproximadamente)
DELETE FROM `fs_logs`;
/*!40000 ALTER TABLE `fs_logs` DISABLE KEYS */;
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(1, 'login', 'Login correcto.', '2016-04-18 08:44:16', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(2, 'login', 'Login correcto.', '2016-04-18 09:04:42', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(3, 'error', 'Empleado no encontrado.', '2016-04-18 09:17:40', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(4, 'error', 'Artículo no encontrado.', '2016-04-18 09:17:41', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(5, 'error', 'Faltan datos.', '2016-04-18 09:17:41', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(6, 'error', '¡albarán de proveedor no encontrado!', '2016-04-18 09:17:42', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(7, 'error', '¡Factura de proveedor no encontrada!', '2016-04-18 09:17:43', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(8, 'error', '¡Proveedor no encontrado!', '2016-04-18 09:17:43', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(9, 'error', 'Asiento no encontrado.', '2016-04-18 09:17:44', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(10, 'error', 'Cuenta no encontrada.', '2016-04-18 09:17:44', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(11, 'error', 'Ejercicio no encontrado.', '2016-04-18 09:17:45', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(12, 'error', 'Subcuenta no encontrada.', '2016-04-18 09:17:46', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(13, 'error', '¡albarán de cliente no encontrado!', '2016-04-18 09:17:47', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(14, 'error', 'Artículo no encontrado.', '2016-04-18 09:17:48', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(15, 'error', '¡Cliente no encontrado!', '2016-04-18 09:17:48', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(16, 'error', 'Fabricante no encontrado.', '2016-04-18 09:17:48', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(17, 'error', '¡Factura de cliente no encontrada!', '2016-04-18 09:17:48', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(18, 'error', 'Factura no encontrada.', '2016-04-18 09:17:48', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(19, 'error', 'Familia no encontrada.', '2016-04-18 09:17:48', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(20, 'error', 'Grupo no encontrado.', '2016-04-18 09:17:48', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(21, 'login', 'El usuario ha cerrado la sesión.', '2016-04-18 12:34:08', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(22, 'error', '¡Contraseña incorrecta!', '2016-04-18 12:34:12', NULL, '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(23, 'login', 'Login correcto.', '2016-04-18 12:34:19', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(24, 'login', 'El usuario ha cerrado la sesión.', '2016-04-18 12:39:04', 'admin', '::1', 0);
INSERT INTO `fs_logs` (`id`, `tipo`, `detalle`, `fecha`, `usuario`, `ip`, `alerta`) VALUES
	(25, 'login', 'Login correcto.', '2016-04-18 12:39:08', 'admin', '::1', 0);
/*!40000 ALTER TABLE `fs_logs` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.fs_pages
DROP TABLE IF EXISTS `fs_pages`;
CREATE TABLE IF NOT EXISTS `fs_pages` (
  `name` varchar(30) COLLATE utf8_bin NOT NULL,
  `title` varchar(40) COLLATE utf8_bin NOT NULL,
  `folder` varchar(15) COLLATE utf8_bin NOT NULL,
  `version` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `show_on_menu` tinyint(1) NOT NULL DEFAULT '1',
  `important` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.fs_pages: ~61 rows (aproximadamente)
DELETE FROM `fs_pages`;
/*!40000 ALTER TABLE `fs_pages` DISABLE KEYS */;
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('admin_agente', 'Empleado', 'admin', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('admin_agentes', 'Empleados', 'admin', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('admin_almacenes', 'Almacenes', 'admin', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('admin_divisas', 'Divisas', 'admin', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('admin_empresa', 'Empresa', 'admin', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('admin_home', 'Panel de control', 'admin', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('admin_paises', 'Paises', 'admin', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('admin_transportes', 'Agencias de transporte', 'admin', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('articulo_subcuentas', 'Subcuentas', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('base_wizard', 'Asistente de instalación', 'admin', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('compras_actualiza_arts', 'Artículos documento', 'compras', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('compras_agrupar_albaranes', 'Agrupar albaranes', 'compras', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('compras_albaran', 'albarán de proveedor', 'compras', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('compras_albaranes', 'Albaranes', 'compras', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('compras_factura', 'Factura de proveedor', 'compras', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('compras_facturas', 'Facturas', 'compras', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('compras_imprimir', 'imprimir', 'compras', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('compras_proveedor', 'Proveedor', 'compras', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('compras_proveedores', 'Proveedores / Acreedores', 'compras', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_asiento', 'Asiento', 'contabilidad', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_asientos', 'Asientos', 'contabilidad', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_cuenta', 'Cuenta', 'contabilidad', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_cuentas', 'Cuentas', 'contabilidad', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_ejercicio', 'Ejercicio', 'contabilidad', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_ejercicios', 'Ejercicios', 'contabilidad', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_epigrafes', 'Grupos y epígrafes', 'contabilidad', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_formas_pago', 'Formas de Pago', 'contabilidad', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_impuestos', 'Impuestos', 'contabilidad', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_nuevo_asiento', 'Nuevo asiento', 'contabilidad', '2016.002', 0, 1);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_regusiva', 'Regularizaciones de IVA', 'contabilidad', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_series', 'Series', 'contabilidad', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('contabilidad_subcuenta', 'Subcuenta', 'contabilidad', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('cuentas_especiales', 'Cuentas Especiales', 'contabilidad', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('garantia', 'Garantias', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('informe_albaranes', 'Albaranes', 'informes', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('informe_articulos', 'Artículos', 'informes', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('informe_contabilidad', 'Contabilidad', 'informes', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('informe_errores', 'Errores', 'informes', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('informe_facturas', 'Facturas', 'informes', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('informe_stock', 'inventario', 'informes', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('listado_garantias', 'Garantías', 'ventas', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('mi_pagina', 'mi página', 'informes', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('nueva_compra', 'Nueva compra...', 'compras', '2016.002', 0, 1);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('nueva_venta', 'Nueva venta...', 'ventas', '2016.002', 0, 1);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('subcuenta_asociada', 'Asignar subcuenta...', 'contabilidad', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('tpv_caja', 'Cajas', 'TPV', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('tpv_recambios', 'TPV Genérico', 'TPV', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_agrupar_albaranes', 'Agrupar albaranes', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_albaran', 'albarán de cliente', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_albaranes', 'Albaranes', 'ventas', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_articulo', 'Articulo', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_articulos', 'Artículos', 'ventas', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_atributos', 'Atributod de artículos', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_cliente', 'Cliente', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_clientes', 'Clientes', 'ventas', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_clientes_opciones', 'Opciones', 'clientes', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_fabricante', 'Familia', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_fabricantes', 'Fabricantes', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_factura', 'Factura de cliente', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_factura_devolucion', 'Devoluciones de factura de venta', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_facturas', 'Facturas', 'ventas', '2016.002', 1, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_familia', 'Familia', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_familias', 'Familias', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_grupo', 'Grupo', 'ventas', '2016.002', 0, 0);
INSERT INTO `fs_pages` (`name`, `title`, `folder`, `version`, `show_on_menu`, `important`) VALUES
	('ventas_imprimir', 'imprimir', 'ventas', '2016.002', 0, 0);
/*!40000 ALTER TABLE `fs_pages` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.fs_users
DROP TABLE IF EXISTS `fs_users`;
CREATE TABLE IF NOT EXISTS `fs_users` (
  `nick` varchar(12) COLLATE utf8_bin NOT NULL,
  `password` varchar(100) COLLATE utf8_bin NOT NULL,
  `log_key` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `last_login` date DEFAULT NULL,
  `last_login_time` time DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `last_browser` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `fs_page` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `css` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`nick`),
  KEY `ca_fs_users_pages` (`fs_page`),
  CONSTRAINT `ca_fs_users_pages` FOREIGN KEY (`fs_page`) REFERENCES `fs_pages` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.fs_users: ~0 rows (aproximadamente)
DELETE FROM `fs_users`;
/*!40000 ALTER TABLE `fs_users` DISABLE KEYS */;
INSERT INTO `fs_users` (`nick`, `password`, `log_key`, `admin`, `codagente`, `last_login`, `last_login_time`, `last_ip`, `last_browser`, `fs_page`, `css`, `email`) VALUES
	('admin', '7bf1ab1b8f7331ab5dc410e01f959d958bfd210e', 'c4528b12c0581e2d63285f369dd6eb97a1dc4364', 1, '1', '2016-04-18', '18:38:31', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:32.0) Gecko/20100101 Firefox/32.0', NULL, 'view/css/bootstrap-yeti.min.css', NULL);
/*!40000 ALTER TABLE `fs_users` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.fs_vars
DROP TABLE IF EXISTS `fs_vars`;
CREATE TABLE IF NOT EXISTS `fs_vars` (
  `name` varchar(35) COLLATE utf8_bin NOT NULL,
  `varchar` text COLLATE utf8_bin,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.fs_vars: ~9 rows (aproximadamente)
DELETE FROM `fs_vars`;
/*!40000 ALTER TABLE `fs_vars` DISABLE KEYS */;
INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
	('install_step', '5');
INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
	('last_download_check', '2016-04-11');
INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
	('mail_bcc', '');
INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
	('mail_enc', 'ssl');
INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
	('mail_firma', '\n---\nEnviado con FacturaScripts');
INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
	('mail_host', 'smtp.gmail.com');
INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
	('mail_password', '');
INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
	('mail_port', '465');
INSERT INTO `fs_vars` (`name`, `varchar`) VALUES
	('mail_user', '');
/*!40000 ALTER TABLE `fs_vars` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.gruposclientes
DROP TABLE IF EXISTS `gruposclientes`;
CREATE TABLE IF NOT EXISTS `gruposclientes` (
  `codgrupo` varchar(6) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codtarifa` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codgrupo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.gruposclientes: ~0 rows (aproximadamente)
DELETE FROM `gruposclientes`;
/*!40000 ALTER TABLE `gruposclientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `gruposclientes` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.impuestos
DROP TABLE IF EXISTS `impuestos`;
CREATE TABLE IF NOT EXISTS `impuestos` (
  `codimpuesto` varchar(10) COLLATE utf8_bin NOT NULL,
  `codsubcuentaacr` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentadeu` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadedadue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadevadue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadeventue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepexe` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepexp` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepre` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopagra` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopexe` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopimp` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentarep` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentasop` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuentaacr` int(11) DEFAULT NULL,
  `idsubcuentadeu` int(11) DEFAULT NULL,
  `idsubcuentaivadedadue` int(11) DEFAULT NULL,
  `idsubcuentaivadevadue` int(11) DEFAULT NULL,
  `idsubcuentaivadeventue` int(11) DEFAULT NULL,
  `idsubcuentaivarepexe` int(11) DEFAULT NULL,
  `idsubcuentaivarepexp` int(11) DEFAULT NULL,
  `idsubcuentaivarepre` int(11) DEFAULT NULL,
  `idsubcuentaivasopagra` int(11) DEFAULT NULL,
  `idsubcuentaivasopexe` int(11) DEFAULT NULL,
  `idsubcuentaivasopimp` int(11) DEFAULT NULL,
  `idsubcuentarep` int(11) DEFAULT NULL,
  `idsubcuentasop` int(11) DEFAULT NULL,
  `iva` double NOT NULL,
  `recargo` double NOT NULL,
  PRIMARY KEY (`codimpuesto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.impuestos: ~4 rows (aproximadamente)
DELETE FROM `impuestos`;
/*!40000 ALTER TABLE `impuestos` DISABLE KEYS */;
INSERT INTO `impuestos` (`codimpuesto`, `codsubcuentaacr`, `codsubcuentadeu`, `codsubcuentaivadedadue`, `codsubcuentaivadevadue`, `codsubcuentaivadeventue`, `codsubcuentaivarepexe`, `codsubcuentaivarepexp`, `codsubcuentaivarepre`, `codsubcuentaivasopagra`, `codsubcuentaivasopexe`, `codsubcuentaivasopimp`, `codsubcuentarep`, `codsubcuentasop`, `descripcion`, `idsubcuentaacr`, `idsubcuentadeu`, `idsubcuentaivadedadue`, `idsubcuentaivadevadue`, `idsubcuentaivadeventue`, `idsubcuentaivarepexe`, `idsubcuentaivarepexp`, `idsubcuentaivarepre`, `idsubcuentaivasopagra`, `idsubcuentaivasopexe`, `idsubcuentaivasopimp`, `idsubcuentarep`, `idsubcuentasop`, `iva`, `recargo`) VALUES
	('IVA0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'IVA 0%', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
INSERT INTO `impuestos` (`codimpuesto`, `codsubcuentaacr`, `codsubcuentadeu`, `codsubcuentaivadedadue`, `codsubcuentaivadevadue`, `codsubcuentaivadeventue`, `codsubcuentaivarepexe`, `codsubcuentaivarepexp`, `codsubcuentaivarepre`, `codsubcuentaivasopagra`, `codsubcuentaivasopexe`, `codsubcuentaivasopimp`, `codsubcuentarep`, `codsubcuentasop`, `descripcion`, `idsubcuentaacr`, `idsubcuentadeu`, `idsubcuentaivadedadue`, `idsubcuentaivadevadue`, `idsubcuentaivadeventue`, `idsubcuentaivarepexe`, `idsubcuentaivarepexp`, `idsubcuentaivarepre`, `idsubcuentaivasopagra`, `idsubcuentaivasopexe`, `idsubcuentaivasopimp`, `idsubcuentarep`, `idsubcuentasop`, `iva`, `recargo`) VALUES
	('IVA10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'IVA 10%', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1.4);
INSERT INTO `impuestos` (`codimpuesto`, `codsubcuentaacr`, `codsubcuentadeu`, `codsubcuentaivadedadue`, `codsubcuentaivadevadue`, `codsubcuentaivadeventue`, `codsubcuentaivarepexe`, `codsubcuentaivarepexp`, `codsubcuentaivarepre`, `codsubcuentaivasopagra`, `codsubcuentaivasopexe`, `codsubcuentaivasopimp`, `codsubcuentarep`, `codsubcuentasop`, `descripcion`, `idsubcuentaacr`, `idsubcuentadeu`, `idsubcuentaivadedadue`, `idsubcuentaivadevadue`, `idsubcuentaivadeventue`, `idsubcuentaivarepexe`, `idsubcuentaivarepexp`, `idsubcuentaivarepre`, `idsubcuentaivasopagra`, `idsubcuentaivasopexe`, `idsubcuentaivasopimp`, `idsubcuentarep`, `idsubcuentasop`, `iva`, `recargo`) VALUES
	('IVA21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'IVA 21%', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 21, 5.2);
INSERT INTO `impuestos` (`codimpuesto`, `codsubcuentaacr`, `codsubcuentadeu`, `codsubcuentaivadedadue`, `codsubcuentaivadevadue`, `codsubcuentaivadeventue`, `codsubcuentaivarepexe`, `codsubcuentaivarepexp`, `codsubcuentaivarepre`, `codsubcuentaivasopagra`, `codsubcuentaivasopexe`, `codsubcuentaivasopimp`, `codsubcuentarep`, `codsubcuentasop`, `descripcion`, `idsubcuentaacr`, `idsubcuentadeu`, `idsubcuentaivadedadue`, `idsubcuentaivadevadue`, `idsubcuentaivadeventue`, `idsubcuentaivarepexe`, `idsubcuentaivarepexp`, `idsubcuentaivarepre`, `idsubcuentaivasopagra`, `idsubcuentaivasopexe`, `idsubcuentaivasopimp`, `idsubcuentarep`, `idsubcuentasop`, `iva`, `recargo`) VALUES
	('IVA4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'IVA 4%', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 0.5);
/*!40000 ALTER TABLE `impuestos` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.lineasalbaranesprov
DROP TABLE IF EXISTS `lineasalbaranesprov`;
CREATE TABLE IF NOT EXISTS `lineasalbaranesprov` (
  `cantidad` double NOT NULL DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL DEFAULT '0',
  `idalbaran` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `idlineapedido` int(11) DEFAULT NULL,
  `idpedido` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL DEFAULT '0',
  `pvpsindto` double NOT NULL DEFAULT '0',
  `pvptotal` double NOT NULL DEFAULT '0',
  `pvpunitario` double NOT NULL DEFAULT '0',
  `recargo` double DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idlinea`),
  KEY `ca_lineasalbaranesprov_albaranesprov2` (`idalbaran`),
  CONSTRAINT `ca_lineasalbaranesprov_albaranesprov2` FOREIGN KEY (`idalbaran`) REFERENCES `albaranesprov` (`idalbaran`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.lineasalbaranesprov: ~5 rows (aproximadamente)
DELETE FROM `lineasalbaranesprov`;
/*!40000 ALTER TABLE `lineasalbaranesprov` DISABLE KEYS */;
INSERT INTO `lineasalbaranesprov` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`) VALUES
	(1, 'IVA21', '101212 bomba agua citroen,peuge.', 0, 0, 1, 1, NULL, NULL, 0, 21, 31.89, 31.89, 31.89, 0, '101212');
INSERT INTO `lineasalbaranesprov` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`) VALUES
	(5, 'IVA21', 'valvula expansion conica 1.5t', 0, 0, 1, 2, NULL, NULL, 0, 21, 114, 114, 22.8, 0, '1212008');
INSERT INTO `lineasalbaranesprov` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`) VALUES
	(3, 'IVA21', 'tijera asiento isri 6000', 0, 0, 1, 3, NULL, NULL, 0, 21, 189.33, 189.33, 63.11, 0, '1212000');
INSERT INTO `lineasalbaranesprov` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`) VALUES
	(7, 'IVA21', 'valvula expansion mb 126*r21', 0, 0, 1, 4, NULL, NULL, 0, 21, 150.43, 150.43, 21.49, 0, '1212101');
INSERT INTO `lineasalbaranesprov` (`cantidad`, `codimpuesto`, `descripcion`, `dtolineal`, `dtopor`, `idalbaran`, `idlinea`, `idlineapedido`, `idpedido`, `irpf`, `iva`, `pvpsindto`, `pvptotal`, `pvpunitario`, `recargo`, `referencia`) VALUES
	(5, 'IVA21', '0141520030 juego flector', 0, 0, 1, 5, NULL, NULL, 0, 21, 737.65, 737.65, 147.53, 0, '0141520030');
/*!40000 ALTER TABLE `lineasalbaranesprov` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.lineasfacturascli
DROP TABLE IF EXISTS `lineasfacturascli`;
CREATE TABLE IF NOT EXISTS `lineasfacturascli` (
  `cantidad` double NOT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL,
  `idalbaran` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL,
  `porcomision` double DEFAULT NULL,
  `pvpsindto` double NOT NULL,
  `pvptotal` double NOT NULL,
  `pvpunitario` double NOT NULL,
  `recargo` double DEFAULT NULL,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idlinea`),
  KEY `ca_linea_facturascli2` (`idfactura`),
  CONSTRAINT `ca_linea_facturascli2` FOREIGN KEY (`idfactura`) REFERENCES `facturascli` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.lineasfacturascli: ~0 rows (aproximadamente)
DELETE FROM `lineasfacturascli`;
/*!40000 ALTER TABLE `lineasfacturascli` DISABLE KEYS */;
/*!40000 ALTER TABLE `lineasfacturascli` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.lineasfacturasprov
DROP TABLE IF EXISTS `lineasfacturasprov`;
CREATE TABLE IF NOT EXISTS `lineasfacturasprov` (
  `cantidad` double NOT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` text COLLATE utf8_bin,
  `dtolineal` double DEFAULT '0',
  `dtopor` double NOT NULL,
  `idalbaran` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `idsubcuenta` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL,
  `pvpsindto` double NOT NULL,
  `pvptotal` double DEFAULT NULL,
  `pvpunitario` double NOT NULL,
  `recargo` double DEFAULT NULL,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idlinea`),
  KEY `ca_linea_facturasprov2` (`idfactura`),
  CONSTRAINT `ca_linea_facturasprov2` FOREIGN KEY (`idfactura`) REFERENCES `facturasprov` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.lineasfacturasprov: ~0 rows (aproximadamente)
DELETE FROM `lineasfacturasprov`;
/*!40000 ALTER TABLE `lineasfacturasprov` DISABLE KEYS */;
/*!40000 ALTER TABLE `lineasfacturasprov` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.lineasregstocks
DROP TABLE IF EXISTS `lineasregstocks`;
CREATE TABLE IF NOT EXISTS `lineasregstocks` (
  `cantidadfin` double NOT NULL DEFAULT '0',
  `cantidadini` double NOT NULL DEFAULT '0',
  `codalmacendest` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idstock` int(11) NOT NULL,
  `motivo` text COLLATE utf8_bin,
  `nick` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_lineasregstocks_stocks` (`idstock`),
  CONSTRAINT `ca_lineasregstocks_stocks` FOREIGN KEY (`idstock`) REFERENCES `stocks` (`idstock`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.lineasregstocks: ~0 rows (aproximadamente)
DELETE FROM `lineasregstocks`;
/*!40000 ALTER TABLE `lineasregstocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `lineasregstocks` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.paises
DROP TABLE IF EXISTS `paises`;
CREATE TABLE IF NOT EXISTS `paises` (
  `validarprov` tinyint(1) DEFAULT NULL,
  `codiso` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `bandera` text COLLATE utf8_bin,
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codpais`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.paises: ~22 rows (aproximadamente)
DELETE FROM `paises`;
/*!40000 ALTER TABLE `paises` DISABLE KEYS */;
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'AD', NULL, 'Andorra', 'AND');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'AR', NULL, 'Argentina', 'ARG');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'BO', NULL, 'Bolivia', 'BOL');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'CL', NULL, 'Chile', 'CHL');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'CO', NULL, 'Colombia', 'COL');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'CR', NULL, 'Costa Rica', 'CRI');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'CU', NULL, 'Cuba', 'CUB');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'DO', NULL, 'República Dominicana', 'DOM');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'EC', NULL, 'Ecuador', 'ECU');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'ES', NULL, 'España', 'ESP');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'GQ', NULL, 'Guinea Ecuatorial', 'GNQ');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'GT', NULL, 'Guatemala', 'GTM');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'HN', NULL, 'Honduras', 'HND');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'MX', NULL, 'México', 'MEX');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'NI', NULL, 'Nicaragua', 'NIC');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'PA', NULL, 'Panamá', 'PAN');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'PE', NULL, 'Perú', 'PER');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'PR', NULL, 'Puerto Rico', 'PRI');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'PY', NULL, 'Paraguay', 'PRY');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'SV', NULL, 'El Salvador', 'SLV');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'UY', NULL, 'Uruguay', 'URY');
INSERT INTO `paises` (`validarprov`, `codiso`, `bandera`, `nombre`, `codpais`) VALUES
	(NULL, 'VE', NULL, 'Venezuela', 'VEN');
/*!40000 ALTER TABLE `paises` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.proveedores
DROP TABLE IF EXISTS `proveedores`;
CREATE TABLE IF NOT EXISTS `proveedores` (
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `codcontacto` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentadom` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentapago` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `ivaportes` double DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `razonsocial` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `recfinanciero` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `telefono1` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `telefono2` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tipoidfiscal` varchar(25) COLLATE utf8_bin NOT NULL DEFAULT 'NIF',
  `web` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `acreedor` tinyint(1) DEFAULT '0',
  `personafisica` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`codproveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.proveedores: ~0 rows (aproximadamente)
DELETE FROM `proveedores`;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` (`cifnif`, `codcontacto`, `codcuentadom`, `codcuentapago`, `coddivisa`, `codpago`, `codproveedor`, `codserie`, `codsubcuenta`, `contacto`, `email`, `fax`, `idsubcuenta`, `ivaportes`, `nombre`, `razonsocial`, `observaciones`, `recfinanciero`, `regimeniva`, `telefono1`, `telefono2`, `tipoidfiscal`, `web`, `acreedor`, `personafisica`) VALUES
	('', NULL, NULL, NULL, 'EUR', 'CONT', '000001', NULL, NULL, NULL, '', '', NULL, NULL, 'yo mismo', 'yo mismo', '', NULL, 'General', '', '', 'CIF/NIF', '', 0, 1);
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.registros_garantias
DROP TABLE IF EXISTS `registros_garantias`;
CREATE TABLE IF NOT EXISTS `registros_garantias` (
  `ngarantias` int(11) NOT NULL AUTO_INCREMENT,
  `prioridad` int(11) DEFAULT NULL,
  `fentrada` date NOT NULL,
  `modelo` text COLLATE utf8_bin,
  `estado` int(11) NOT NULL,
  `averia` text COLLATE utf8_bin NOT NULL,
  `accesorios` text COLLATE utf8_bin,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `fechfactventa` date DEFAULT NULL,
  `factventa` text COLLATE utf8_bin,
  `fechfactcompra` date DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `factcompra` text COLLATE utf8_bin,
  `numserie` text COLLATE utf8_bin,
  `numrma` text COLLATE utf8_bin,
  `observaciones` text COLLATE utf8_bin,
  `posicion` text COLLATE utf8_bin,
  PRIMARY KEY (`ngarantias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.registros_garantias: ~0 rows (aproximadamente)
DELETE FROM `registros_garantias`;
/*!40000 ALTER TABLE `registros_garantias` DISABLE KEYS */;
/*!40000 ALTER TABLE `registros_garantias` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.secuencias
DROP TABLE IF EXISTS `secuencias`;
CREATE TABLE IF NOT EXISTS `secuencias` (
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL,
  `idsec` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `valor` int(11) DEFAULT NULL,
  `valorout` int(11) DEFAULT NULL,
  PRIMARY KEY (`idsec`),
  KEY `ca_secuencias_secuenciasejercicios` (`id`),
  CONSTRAINT `ca_secuencias_secuenciasejercicios` FOREIGN KEY (`id`) REFERENCES `secuenciasejercicios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.secuencias: ~0 rows (aproximadamente)
DELETE FROM `secuencias`;
/*!40000 ALTER TABLE `secuencias` DISABLE KEYS */;
INSERT INTO `secuencias` (`descripcion`, `id`, `idsec`, `nombre`, `valor`, `valorout`) VALUES
	('Secuencia del ejercicio 2016 y la serie A', 1, 1, 'nalbaranprov', 1, 2);
/*!40000 ALTER TABLE `secuencias` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.secuenciasejercicios
DROP TABLE IF EXISTS `secuenciasejercicios`;
CREATE TABLE IF NOT EXISTS `secuenciasejercicios` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nalbarancli` int(11) NOT NULL,
  `nalbaranprov` int(11) NOT NULL,
  `nfacturacli` int(11) NOT NULL,
  `nfacturaprov` int(11) NOT NULL,
  `npedidocli` int(11) NOT NULL,
  `npedidoprov` int(11) NOT NULL,
  `npresupuestocli` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_secuenciasejercicios_ejercicios` (`codejercicio`),
  CONSTRAINT `ca_secuenciasejercicios_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.secuenciasejercicios: ~2 rows (aproximadamente)
DELETE FROM `secuenciasejercicios`;
/*!40000 ALTER TABLE `secuenciasejercicios` DISABLE KEYS */;
INSERT INTO `secuenciasejercicios` (`codejercicio`, `codserie`, `id`, `nalbarancli`, `nalbaranprov`, `nfacturacli`, `nfacturaprov`, `npedidocli`, `npedidoprov`, `npresupuestocli`) VALUES
	('2016', 'A', 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `secuenciasejercicios` (`codejercicio`, `codserie`, `id`, `nalbarancli`, `nalbaranprov`, `nfacturacli`, `nfacturaprov`, `npedidocli`, `npedidoprov`, `npresupuestocli`) VALUES
	('2016', 'R', 2, 1, 1, 1, 1, 1, 1, 1);
/*!40000 ALTER TABLE `secuenciasejercicios` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.series
DROP TABLE IF EXISTS `series`;
CREATE TABLE IF NOT EXISTS `series` (
  `irpf` double DEFAULT NULL,
  `idcuenta` int(11) DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `siniva` tinyint(1) DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `numfactura` int(11) DEFAULT '1',
  PRIMARY KEY (`codserie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.series: ~2 rows (aproximadamente)
DELETE FROM `series`;
/*!40000 ALTER TABLE `series` DISABLE KEYS */;
INSERT INTO `series` (`irpf`, `idcuenta`, `codserie`, `descripcion`, `siniva`, `codcuenta`, `codejercicio`, `numfactura`) VALUES
	(0, NULL, 'A', 'SERIE A', 0, NULL, NULL, 1);
INSERT INTO `series` (`irpf`, `idcuenta`, `codserie`, `descripcion`, `siniva`, `codcuenta`, `codejercicio`, `numfactura`) VALUES
	(0, NULL, 'R', 'RECTIFICATIVAS', 0, NULL, NULL, 1);
/*!40000 ALTER TABLE `series` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.stocks
DROP TABLE IF EXISTS `stocks`;
CREATE TABLE IF NOT EXISTS `stocks` (
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `disponible` double NOT NULL,
  `stockmin` double NOT NULL DEFAULT '0',
  `reservada` double NOT NULL,
  `horaultreg` time DEFAULT '00:00:00',
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `pterecibir` double NOT NULL,
  `fechaultreg` date DEFAULT '2016-04-18',
  `codalmacen` varchar(4) COLLATE utf8_bin NOT NULL,
  `cantidadultreg` double NOT NULL DEFAULT '0',
  `idstock` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` double NOT NULL DEFAULT '0',
  `stockmax` double NOT NULL DEFAULT '0',
  `ubicacion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idstock`),
  UNIQUE KEY `uniq_stocks_almacen_referencia` (`codalmacen`,`referencia`),
  KEY `ca_stocks_articulos2` (`referencia`),
  CONSTRAINT `ca_stocks_almacenes3` FOREIGN KEY (`codalmacen`) REFERENCES `almacenes` (`codalmacen`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_stocks_articulos2` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.stocks: ~5 rows (aproximadamente)
DELETE FROM `stocks`;
/*!40000 ALTER TABLE `stocks` DISABLE KEYS */;
INSERT INTO `stocks` (`referencia`, `disponible`, `stockmin`, `reservada`, `horaultreg`, `nombre`, `pterecibir`, `fechaultreg`, `codalmacen`, `cantidadultreg`, `idstock`, `cantidad`, `stockmax`, `ubicacion`) VALUES
	('101212', 1, 0, 0, '00:00:00', '', 0, '2016-04-18', 'ALG', 0, 1, 1, 0, NULL);
INSERT INTO `stocks` (`referencia`, `disponible`, `stockmin`, `reservada`, `horaultreg`, `nombre`, `pterecibir`, `fechaultreg`, `codalmacen`, `cantidadultreg`, `idstock`, `cantidad`, `stockmax`, `ubicacion`) VALUES
	('1212008', 5, 0, 0, '00:00:00', '', 0, '2016-04-18', 'ALG', 0, 2, 5, 0, NULL);
INSERT INTO `stocks` (`referencia`, `disponible`, `stockmin`, `reservada`, `horaultreg`, `nombre`, `pterecibir`, `fechaultreg`, `codalmacen`, `cantidadultreg`, `idstock`, `cantidad`, `stockmax`, `ubicacion`) VALUES
	('1212000', 3, 0, 0, '00:00:00', '', 0, '2016-04-18', 'ALG', 0, 3, 3, 0, NULL);
INSERT INTO `stocks` (`referencia`, `disponible`, `stockmin`, `reservada`, `horaultreg`, `nombre`, `pterecibir`, `fechaultreg`, `codalmacen`, `cantidadultreg`, `idstock`, `cantidad`, `stockmax`, `ubicacion`) VALUES
	('1212101', 7, 0, 0, '00:00:00', '', 0, '2016-04-18', 'ALG', 0, 4, 7, 0, NULL);
INSERT INTO `stocks` (`referencia`, `disponible`, `stockmin`, `reservada`, `horaultreg`, `nombre`, `pterecibir`, `fechaultreg`, `codalmacen`, `cantidadultreg`, `idstock`, `cantidad`, `stockmax`, `ubicacion`) VALUES
	('0141520030', 5, 0, 0, '00:00:00', '', 0, '2016-04-18', 'ALG', 0, 5, 5, 0, NULL);
/*!40000 ALTER TABLE `stocks` ENABLE KEYS */;


-- Volcando estructura para tabla facturascripts.tarifas
DROP TABLE IF EXISTS `tarifas`;
CREATE TABLE IF NOT EXISTS `tarifas` (
  `incporcentual` double NOT NULL,
  `inclineal` double NOT NULL,
  `aplicar_a` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `mincoste` tinyint(1) DEFAULT '0',
  `maxpvp` tinyint(1) DEFAULT '0',
  `codtarifa` varchar(6) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codtarifa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Volcando datos para la tabla facturascripts.tarifas: ~0 rows (aproximadamente)
DELETE FROM `tarifas`;
/*!40000 ALTER TABLE `tarifas` DISABLE KEYS */;
/*!40000 ALTER TABLE `tarifas` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
