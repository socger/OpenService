-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.6.28-log - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando estructura de base de datos para socger
DROP DATABASE IF EXISTS `socger`;
CREATE DATABASE IF NOT EXISTS `socger` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci */;
USE `socger`;


-- Volcando estructura para procedimiento socger.function_ACT_totales_albaranes_compras
DROP PROCEDURE IF EXISTS `function_ACT_totales_albaranes_compras`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_albaranes_compras`(IN `param_id_albaranes` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_albaranes <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM albaranes_compras_impuestos
				WHERE id_albaranes = param_id_albaranes 
				ORDER BY id_albaranes ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO albaranes_compras_impuestos
				          ( id_albaranes,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_albaranes,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM albaranes_compras_detalles  
				                         WHERE id_albaranes = param_id_albaranes 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN albaranes_compras_detalles AS f_c_d
				                ON f_c_d.id_albaranes = param_id_albaranes AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_Compras
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM albaranes_compras_impuestos
				                  WHERE id_albaranes = param_id_albaranes
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_albaranes ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO albaranes_compras_impuestos
				          ( id_albaranes,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_albaranes,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM albaranes_compras_detalles  
				                         WHERE id_albaranes = param_id_albaranes 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN albaranes_compras_detalles AS f_c_d
				                ON f_c_d.id_albaranes = param_id_albaranes AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_Compras
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en albaranes_compras_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM albaranes_compras_impuestos
				                  WHERE id_albaranes = param_id_albaranes
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_albaranes ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE albaranes_compras_impuestos
				SET albaranes_compras_impuestos.Importe = ( albaranes_compras_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = albaranes_compras_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE albaranes_compras_impuestos.id_albaranes = param_id_albaranes;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE albaranes_compras

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM albaranes_compras_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_albaranes = param_id_albaranes 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM albaranes_compras_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_albaranes = param_id_albaranes 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM albaranes_compras_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_albaranes = param_id_albaranes 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM albaranes_compras_detalles AS f_c_d
 				                     WHERE f_c_d.id_albaranes = param_id_albaranes 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
			                     (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                            FROM albaranes_compras_impuestos AS f_c_i
                                            LEFT JOIN impuestos AS i
										              ON i.id = f_c_i.id_impuestos 
 				                                WHERE f_c_i.id_albaranes = param_id_albaranes 
										              AND f_c_i.Del_WHEN IS NULL 
										              AND i.Sumado_A_Ftra_SN = 'S' ), 0)
											 -
											 IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                FROM albaranes_compras_impuestos AS f_c_i
                                            LEFT JOIN impuestos AS i
													     ON i.id = f_c_i.id_impuestos
 				                                WHERE f_c_i.id_albaranes = param_id_albaranes 
										              AND f_c_i.Del_WHEN IS NULL 
													     AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )

				WHERE id = param_id_albaranes;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_albaranes_ventas
DROP PROCEDURE IF EXISTS `function_ACT_totales_albaranes_ventas`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_albaranes_ventas`(IN `param_id_albaranes` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_albaranes <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM albaranes_ventas_impuestos
				WHERE id_albaranes = param_id_albaranes 
				ORDER BY id_albaranes ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO albaranes_ventas_impuestos
				          ( id_albaranes,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_albaranes,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM albaranes_ventas_detalles  
				                         WHERE id_albaranes = param_id_albaranes 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN albaranes_ventas_detalles AS f_c_d
				                ON f_c_d.id_albaranes = param_id_albaranes AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_ventas
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM albaranes_ventas_impuestos
				                  WHERE id_albaranes = param_id_albaranes
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_albaranes ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO albaranes_ventas_impuestos
				          ( id_albaranes,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_albaranes,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM albaranes_ventas_detalles  
				                         WHERE id_albaranes = param_id_albaranes 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN albaranes_ventas_detalles AS f_c_d
				                ON f_c_d.id_albaranes = param_id_albaranes AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_ventas
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en albaranes_ventas_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM albaranes_ventas_impuestos
				                  WHERE id_albaranes = param_id_albaranes
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_albaranes ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE albaranes_ventas_impuestos
				SET albaranes_ventas_impuestos.Importe = ( albaranes_ventas_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = albaranes_ventas_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE albaranes_ventas_impuestos.id_albaranes = param_id_albaranes;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE albaranes_ventas

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM albaranes_ventas_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_albaranes = param_id_albaranes 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM albaranes_ventas_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_albaranes = param_id_albaranes 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM albaranes_ventas_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_albaranes = param_id_albaranes 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM albaranes_ventas_detalles AS f_c_d
 				                     WHERE f_c_d.id_albaranes = param_id_albaranes 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM albaranes_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_albaranes = param_id_albaranes 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM albaranes_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_albaranes = param_id_albaranes 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   
				WHERE id = param_id_albaranes;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_facturas_compras
DROP PROCEDURE IF EXISTS `function_ACT_totales_facturas_compras`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_facturas_compras`(IN `param_id_facturas` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- Si la factura está cerrada, pues no se actualiza nada
    -- ----------------------------------------------------------------------------------------------------------------- --
	 IF NOT EXISTS( SELECT fco.*
                   FROM facturas_compras AS fco
                   RIGHT JOIN facturas_cerradas AS fce
                   ON fce.id_empresas = fco.id_empresas AND
                      fco.Fecha >= fce.Desde AND
                      fco.Fecha <= fce.Hasta AND
                      fce.Del_WHEN IS NULL AND
                      fce.Tipo_Ventas_o_Compras_VC = 'C'
                   WHERE fco.id = param_id_facturas
                   ORDER BY fco.id ) THEN
        BEGIN
			    -- ----------------------------------------------------------------------------------------------------------------- --
			    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
			    -- ----------------------------------------------------------------------------------------------------------------- --
			    IF param_id_facturas <> 0 THEN
			        BEGIN
							-- --------------------------------------------------------------------------------------------------------- --
							-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
							-- --------------------------------------------------------------------------------------------------------- --
			        		DELETE FROM facturas_compras_impuestos
							WHERE id_facturas = param_id_facturas 
							ORDER BY id_facturas ASC, id_impuestos ASC;
							
							-- --------------------------------------------------------------------------------------------------------- --
							-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
							-- ENGLOBAN. PERO SOLO SI NO EXISTEN
							-- --------------------------------------------------------------------------------------------------------- --
							INSERT INTO facturas_compras_impuestos
							          ( id_facturas,
							            Base,
							            Importe,
							            Insert_Id_User,
							            Insert_WHEN, 
							            id_impuestos )
							
							SELECT * FROM ( SELECT param_id_facturas,
							
														  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
														                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(Unidades, 1) * PVP) -
														                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
														    FROM facturas_compras_detalles  
							                         WHERE id_facturas = param_id_facturas 
														    AND Del_WHEN IS NULL
														    AND Excluido_su_Cobro_SN <> 'S'
														    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) AS a,
							                     
							                     0 as b,
							                     
							                     param_id_users,
							                     NOW(),
							                     
							                     i_p.id_impuestos
							                     
							                FROM impuestos_composiciones AS i_p
							              
							                RIGHT JOIN facturas_compras_detalles AS f_c_d
							                ON f_c_d.id_facturas = param_id_facturas AND
							                   f_c_d.Del_WHEN IS NULL
							              
							              
							                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_Compras
							                AND i_p.Del_WHEN IS NULL
							                GROUP BY i_p.id_impuestos
							                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
							              ) AS tmp
							
							WHERE NOT EXISTS ( SELECT *
							                  FROM facturas_compras_impuestos
							                  WHERE id_facturas = param_id_facturas
							                  AND id_impuestos = tmp.id_impuestos
							                  ORDER BY id_facturas ASC, id_impuestos ASC 
							                );
							                
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
							-- NO EXISTEN
							-- --------------------------------------------------------------------------------------------------------- --
							INSERT INTO facturas_compras_impuestos
							          ( id_facturas,
							            Base,
							            Importe,
							            Insert_Id_User,
							            Insert_WHEN, 
							            id_impuestos )
							
							SELECT * FROM ( SELECT param_id_facturas,
							
														  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
														                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(Unidades, 1) * PVP) -
														                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
														    FROM facturas_compras_detalles  
							                         WHERE id_facturas = param_id_facturas 
														    AND Del_WHEN IS NULL
														    AND Excluido_su_Cobro_SN <> 'S'
														    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) as a,
							                     
							                     0 as b,
							                     
							                     param_id_users,
							                     NOW(),
							                     
							                     i.id
							                     
							                FROM impuestos AS i
							              
							                RIGHT JOIN facturas_compras_detalles AS f_c_d
							                ON f_c_d.id_facturas = param_id_facturas AND
							                   f_c_d.Del_WHEN IS NULL
							              
							              
							                WHERE i.id = f_c_d.id_impuestos_Compras
							                AND NOT i.Tanto_Por_Ciento IS NULL
							                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en facturas_compras_detalles
							                GROUP BY i.id
							                ORDER BY i.id ASC
							              ) AS tmp
							
							WHERE NOT EXISTS ( SELECT *
							                  FROM facturas_compras_impuestos
							                  WHERE id_facturas = param_id_facturas
							                  AND id_impuestos = tmp.id
							                  ORDER BY id_facturas ASC, id_impuestos ASC 
							                );
			
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
							-- DETALLE DE LA FACTURA
							-- --------------------------------------------------------------------------------------------------------- --
							UPDATE facturas_compras_impuestos
							SET facturas_compras_impuestos.Importe = ( facturas_compras_impuestos.Base * 
							                                           ( SELECT Tanto_Por_Ciento 
							                									   FROM impuestos
							                									   WHERE impuestos.id = facturas_compras_impuestos.id_impuestos ) )
							                								  / 100	   
							WHERE facturas_compras_impuestos.id_facturas = param_id_facturas;
			
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
							-- DETALLE DE LA FACTURA
							-- --------------------------------------------------------------------------------------------------------- --
							UPDATE facturas_compras
			
							SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                        FROM facturas_compras_detalles AS f_c_d
							                        
							                        RIGHT JOIN articulos AS a
							                        ON a.id = f_c_d.id_articulos AND
							                           a.Tipo_de_articulo = 2
							                        
			 				                        WHERE f_c_d.id_facturas = param_id_facturas 
			 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
														   AND f_c_d.Del_WHEN IS NULL ),
														    
			 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                         FROM facturas_compras_detalles AS f_c_d
							                        
							                         RIGHT JOIN articulos AS a
							                         ON a.id = f_c_d.id_articulos AND
							                            a.Tipo_de_articulo = 0
							                        
			 				                         WHERE f_c_d.id_facturas = param_id_facturas 
			 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
														    AND f_c_d.Del_WHEN IS NULL ),
														   
								 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                    FROM facturas_compras_detalles AS f_c_d
							                        
							                    RIGHT JOIN articulos AS a
							                    ON a.id = f_c_d.id_articulos AND
							                       (  ( a.Tipo_de_articulo <> 0 AND
							                            a.Tipo_de_articulo <> 2 )
																 OR 
															  ( a.Tipo_de_articulo IS NULL ) ) 	 
							                        
			 				                    WHERE f_c_d.id_facturas = param_id_facturas 
			 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
													  AND f_c_d.Del_WHEN IS NULL ),
														   
								 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
			                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
			                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
			                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
			                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                     FROM facturas_compras_detalles AS f_c_d
			 				                     WHERE f_c_d.id_facturas = param_id_facturas 
			 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
													   AND f_c_d.Del_WHEN IS NULL ),
														   
			 					 Total_Total = Total_Lineas + 
								                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM facturas_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_facturas = param_id_facturas 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM facturas_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_facturas = param_id_facturas 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
														   

							WHERE id = param_id_facturas;
							
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA VAMOS A CREAR SUS VENCIMIENTOS/RECIBOS (CARTERA)
							-- --------------------------------------------------------------------------------------------------------- --
							CALL function_Recibos_Crear_a_Ftra( 'P', param_id_facturas, param_id_users );
										
			        END;
			    END IF;	
			    
			    
        END;
	 END IF;

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_facturas_ventas
DROP PROCEDURE IF EXISTS `function_ACT_totales_facturas_ventas`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_facturas_ventas`(IN `param_id_facturas` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- Si la factura está cerrada, pues no se actualiza nada
    -- ----------------------------------------------------------------------------------------------------------------- --
	 IF NOT EXISTS( SELECT fco.*
                   FROM facturas_ventas AS fco
                   RIGHT JOIN facturas_cerradas AS fce
                   ON fce.id_empresas = fco.id_empresas AND
                      fco.Fecha >= fce.Desde AND
                      fco.Fecha <= fce.Hasta AND
                      fce.Del_WHEN IS NULL AND
                      fce.Tipo_Ventas_o_Compras_VC = 'V'
                   WHERE fco.id = param_id_facturas
                   ORDER BY fco.id ) THEN
        BEGIN
			    -- ----------------------------------------------------------------------------------------------------------------- --
			    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
			    -- ----------------------------------------------------------------------------------------------------------------- --
			    IF param_id_facturas <> 0 THEN
			        BEGIN
							-- --------------------------------------------------------------------------------------------------------- --
							-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
							-- --------------------------------------------------------------------------------------------------------- --
			        		DELETE FROM facturas_ventas_impuestos
							WHERE id_facturas = param_id_facturas 
							ORDER BY id_facturas ASC, id_impuestos ASC;
							
							-- --------------------------------------------------------------------------------------------------------- --
							-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
							-- ENGLOBAN. PERO SOLO SI NO EXISTEN
							-- --------------------------------------------------------------------------------------------------------- --
							INSERT INTO facturas_ventas_impuestos
							          ( id_facturas,
							            Base,
							            Importe,
							            Insert_Id_User,
							            Insert_WHEN, 
							            id_impuestos )
							
							SELECT * FROM ( SELECT param_id_facturas,
							
														  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
														                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(Unidades, 1) * PVP) -
														                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
														    FROM facturas_ventas_detalles  
							                         WHERE id_facturas = param_id_facturas 
														    AND Del_WHEN IS NULL
														    AND Excluido_su_Cobro_SN <> 'S'
														    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) AS a,
							                     
							                     0 as b,
							                     
							                     param_id_users,
							                     NOW(),
							                     
							                     i_p.id_impuestos
							                     
							                FROM impuestos_composiciones AS i_p
							              
							                RIGHT JOIN facturas_ventas_detalles AS f_c_d
							                ON f_c_d.id_facturas = param_id_facturas AND
							                   f_c_d.Del_WHEN IS NULL
							              
							              
							                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_ventas
							                AND i_p.Del_WHEN IS NULL
							                GROUP BY i_p.id_impuestos
							                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
							              ) AS tmp
							
							WHERE NOT EXISTS ( SELECT *
							                  FROM facturas_ventas_impuestos
							                  WHERE id_facturas = param_id_facturas
							                  AND id_impuestos = tmp.id_impuestos
							                  ORDER BY id_facturas ASC, id_impuestos ASC 
							                );
							                
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
							-- NO EXISTEN
							-- --------------------------------------------------------------------------------------------------------- --
							INSERT INTO facturas_ventas_impuestos
							          ( id_facturas,
							            Base,
							            Importe,
							            Insert_Id_User,
							            Insert_WHEN, 
							            id_impuestos )
							
							SELECT * FROM ( SELECT param_id_facturas,
							
														  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
														                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(Unidades, 1) * PVP) -
														                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
														    FROM facturas_ventas_detalles  
							                         WHERE id_facturas = param_id_facturas 
														    AND Del_WHEN IS NULL
														    AND Excluido_su_Cobro_SN <> 'S'
														    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) as a,
							                     
							                     0 as b,
							                     
							                     param_id_users,
							                     NOW(),
							                     
							                     i.id
							                     
							                FROM impuestos AS i
							              
							                RIGHT JOIN facturas_ventas_detalles AS f_c_d
							                ON f_c_d.id_facturas = param_id_facturas AND
							                   f_c_d.Del_WHEN IS NULL
							              
							              
							                WHERE i.id = f_c_d.id_impuestos_ventas
							                AND NOT i.Tanto_Por_Ciento IS NULL
							                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en facturas_ventas_detalles
							                GROUP BY i.id
							                ORDER BY i.id ASC
							              ) AS tmp
							
							WHERE NOT EXISTS ( SELECT *
							                  FROM facturas_ventas_impuestos
							                  WHERE id_facturas = param_id_facturas
							                  AND id_impuestos = tmp.id
							                  ORDER BY id_facturas ASC, id_impuestos ASC 
							                );
			
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
							-- DETALLE DE LA FACTURA
							-- --------------------------------------------------------------------------------------------------------- --
							UPDATE facturas_ventas_impuestos
							SET facturas_ventas_impuestos.Importe = ( facturas_ventas_impuestos.Base * 
							                                           ( SELECT Tanto_Por_Ciento 
							                									   FROM impuestos
							                									   WHERE impuestos.id = facturas_ventas_impuestos.id_impuestos ) )
							                								  / 100	   
							WHERE facturas_ventas_impuestos.id_facturas = param_id_facturas;
			
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
							-- DETALLE DE LA FACTURA
							-- --------------------------------------------------------------------------------------------------------- --
							UPDATE facturas_ventas
			
							SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                        FROM facturas_ventas_detalles AS f_c_d
							                        
							                        RIGHT JOIN articulos AS a
							                        ON a.id = f_c_d.id_articulos AND
							                           a.Tipo_de_articulo = 2
							                        
			 				                        WHERE f_c_d.id_facturas = param_id_facturas 
			 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
														   AND f_c_d.Del_WHEN IS NULL ),
														    
			 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                         FROM facturas_ventas_detalles AS f_c_d
							                        
							                         RIGHT JOIN articulos AS a
							                         ON a.id = f_c_d.id_articulos AND
							                            a.Tipo_de_articulo = 0
							                        
			 				                         WHERE f_c_d.id_facturas = param_id_facturas 
			 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
														    AND f_c_d.Del_WHEN IS NULL ),
														   
								 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                    FROM facturas_ventas_detalles AS f_c_d
							                        
							                    RIGHT JOIN articulos AS a
							                    ON a.id = f_c_d.id_articulos AND
							                       (  ( a.Tipo_de_articulo <> 0 AND
							                            a.Tipo_de_articulo <> 2 )
																 OR 
															  ( a.Tipo_de_articulo IS NULL ) ) 	 
							                        
			 				                    WHERE f_c_d.id_facturas = param_id_facturas 
			 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
													  AND f_c_d.Del_WHEN IS NULL ),
														   
								 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
			                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
			                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
			                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
			                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                     FROM facturas_ventas_detalles AS f_c_d
			 				                     WHERE f_c_d.id_facturas = param_id_facturas 
			 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
													   AND f_c_d.Del_WHEN IS NULL ),
														   
			 					 Total_Total = Total_Lineas + 
								                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM facturas_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_facturas = param_id_facturas 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM facturas_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_facturas = param_id_facturas 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

							WHERE id = param_id_facturas;
							
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA VAMOS A CREAR SUS VENCIMIENTOS/RECIBOS (CARTERA)
							-- --------------------------------------------------------------------------------------------------------- --
							CALL function_Recibos_Crear_a_Ftra( 'C', param_id_facturas, param_id_users );
										
			        END;
			    END IF;	
			    
        END;
	 END IF;

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_pedidos_compras
DROP PROCEDURE IF EXISTS `function_ACT_totales_pedidos_compras`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_pedidos_compras`(IN `param_id_pedidos` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_pedidos <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM pedidos_compras_impuestos
				WHERE id_pedidos = param_id_pedidos 
				ORDER BY id_pedidos ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO pedidos_compras_impuestos
				          ( id_pedidos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_pedidos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM pedidos_compras_detalles  
				                         WHERE id_pedidos = param_id_pedidos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN pedidos_compras_detalles AS f_c_d
				                ON f_c_d.id_pedidos = param_id_pedidos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_Compras
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM pedidos_compras_impuestos
				                  WHERE id_pedidos = param_id_pedidos
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_pedidos ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO pedidos_compras_impuestos
				          ( id_pedidos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_pedidos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM pedidos_compras_detalles  
				                         WHERE id_pedidos = param_id_pedidos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN pedidos_compras_detalles AS f_c_d
				                ON f_c_d.id_pedidos = param_id_pedidos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_Compras
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en pedidos_compras_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM pedidos_compras_impuestos
				                  WHERE id_pedidos = param_id_pedidos
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_pedidos ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE pedidos_compras_impuestos
				SET pedidos_compras_impuestos.Importe = ( pedidos_compras_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = pedidos_compras_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE pedidos_compras_impuestos.id_pedidos = param_id_pedidos;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE pedidos_compras

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM pedidos_compras_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_pedidos = param_id_pedidos 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM pedidos_compras_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_pedidos = param_id_pedidos 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM pedidos_compras_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_pedidos = param_id_pedidos 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM pedidos_compras_detalles AS f_c_d
 				                     WHERE f_c_d.id_pedidos = param_id_pedidos 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM pedidos_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_pedidos = param_id_pedidos 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM pedidos_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_pedidos = param_id_pedidos 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

				WHERE id = param_id_pedidos;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_pedidos_ventas
DROP PROCEDURE IF EXISTS `function_ACT_totales_pedidos_ventas`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_pedidos_ventas`(IN `param_id_pedidos` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_pedidos <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM pedidos_ventas_impuestos
				WHERE id_pedidos = param_id_pedidos 
				ORDER BY id_pedidos ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO pedidos_ventas_impuestos
				          ( id_pedidos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_pedidos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM pedidos_ventas_detalles  
				                         WHERE id_pedidos = param_id_pedidos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN pedidos_ventas_detalles AS f_c_d
				                ON f_c_d.id_pedidos = param_id_pedidos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_ventas
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM pedidos_ventas_impuestos
				                  WHERE id_pedidos = param_id_pedidos
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_pedidos ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO pedidos_ventas_impuestos
				          ( id_pedidos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_pedidos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM pedidos_ventas_detalles  
				                         WHERE id_pedidos = param_id_pedidos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN pedidos_ventas_detalles AS f_c_d
				                ON f_c_d.id_pedidos = param_id_pedidos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_ventas
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en pedidos_ventas_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM pedidos_ventas_impuestos
				                  WHERE id_pedidos = param_id_pedidos
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_pedidos ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE pedidos_ventas_impuestos
				SET pedidos_ventas_impuestos.Importe = ( pedidos_ventas_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = pedidos_ventas_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE pedidos_ventas_impuestos.id_pedidos = param_id_pedidos;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE pedidos_ventas

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM pedidos_ventas_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_pedidos = param_id_pedidos 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM pedidos_ventas_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_pedidos = param_id_pedidos 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM pedidos_ventas_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_pedidos = param_id_pedidos 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM pedidos_ventas_detalles AS f_c_d
 				                     WHERE f_c_d.id_pedidos = param_id_pedidos 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM pedidos_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_pedidos = param_id_pedidos 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM pedidos_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_pedidos = param_id_pedidos 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

				WHERE id = param_id_pedidos;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_presupuestos_compras
DROP PROCEDURE IF EXISTS `function_ACT_totales_presupuestos_compras`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_presupuestos_compras`(IN `param_id_presupuestos` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_presupuestos <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM presupuestos_compras_impuestos
				WHERE id_presupuestos = param_id_presupuestos 
				ORDER BY id_presupuestos ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO presupuestos_compras_impuestos
				          ( id_presupuestos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_presupuestos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM presupuestos_compras_detalles  
				                         WHERE id_presupuestos = param_id_presupuestos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN presupuestos_compras_detalles AS f_c_d
				                ON f_c_d.id_presupuestos = param_id_presupuestos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_Compras
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM presupuestos_compras_impuestos
				                  WHERE id_presupuestos = param_id_presupuestos
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_presupuestos ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO presupuestos_compras_impuestos
				          ( id_presupuestos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_presupuestos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM presupuestos_compras_detalles  
				                         WHERE id_presupuestos = param_id_presupuestos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN presupuestos_compras_detalles AS f_c_d
				                ON f_c_d.id_presupuestos = param_id_presupuestos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_Compras
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en presupuestos_compras_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM presupuestos_compras_impuestos
				                  WHERE id_presupuestos = param_id_presupuestos
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_presupuestos ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE presupuestos_compras_impuestos
				SET presupuestos_compras_impuestos.Importe = ( presupuestos_compras_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = presupuestos_compras_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE presupuestos_compras_impuestos.id_presupuestos = param_id_presupuestos;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE presupuestos_compras

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM presupuestos_compras_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM presupuestos_compras_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM presupuestos_compras_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM presupuestos_compras_detalles AS f_c_d
 				                     WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM presupuestos_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_presupuestos = param_id_presupuestos 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM presupuestos_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_presupuestos = param_id_presupuestos 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

				WHERE id = param_id_presupuestos;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_presupuestos_ventas
DROP PROCEDURE IF EXISTS `function_ACT_totales_presupuestos_ventas`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_presupuestos_ventas`(IN `param_id_presupuestos` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_presupuestos <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM presupuestos_ventas_impuestos
				WHERE id_presupuestos = param_id_presupuestos 
				ORDER BY id_presupuestos ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO presupuestos_ventas_impuestos
				          ( id_presupuestos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_presupuestos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM presupuestos_ventas_detalles  
				                         WHERE id_presupuestos = param_id_presupuestos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN presupuestos_ventas_detalles AS f_c_d
				                ON f_c_d.id_presupuestos = param_id_presupuestos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_ventas
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM presupuestos_ventas_impuestos
				                  WHERE id_presupuestos = param_id_presupuestos
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_presupuestos ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO presupuestos_ventas_impuestos
				          ( id_presupuestos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_presupuestos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM presupuestos_ventas_detalles  
				                         WHERE id_presupuestos = param_id_presupuestos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN presupuestos_ventas_detalles AS f_c_d
				                ON f_c_d.id_presupuestos = param_id_presupuestos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_ventas
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en presupuestos_ventas_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM presupuestos_ventas_impuestos
				                  WHERE id_presupuestos = param_id_presupuestos
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_presupuestos ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE presupuestos_ventas_impuestos
				SET presupuestos_ventas_impuestos.Importe = ( presupuestos_ventas_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = presupuestos_ventas_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE presupuestos_ventas_impuestos.id_presupuestos = param_id_presupuestos;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE presupuestos_ventas

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM presupuestos_ventas_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM presupuestos_ventas_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM presupuestos_ventas_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM presupuestos_ventas_detalles AS f_c_d
 				                     WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM presupuestos_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_presupuestos = param_id_presupuestos 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM presupuestos_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_presupuestos = param_id_presupuestos 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

				WHERE id = param_id_presupuestos;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_Articulos_Crear_en_Stock
DROP PROCEDURE IF EXISTS `function_Articulos_Crear_en_Stock`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_Articulos_Crear_en_Stock`(IN `param_id_articulos` BIGINT, IN `param_id_almacenes` BIGINT)
BEGIN
	IF NOT EXISTS( SELECT * FROM articulos_stock
						WHERE id_articulos = param_id_articulos
						AND id_almacenes = param_id_almacenes
						ORDER BY id_almacenes ASC, id_almacenes ASC ) THEN
		begin
			INSERT INTO articulos_stock
				( id_articulos,
			  	  id_almacenes,
			     Stock )
			VALUES ( param_id_articulos,
			   	   param_id_almacenes,
				   	0 );
		end;
	END IF;

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ejecutar
DROP PROCEDURE IF EXISTS `function_ejecutar`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ejecutar`(IN `Param1` LINESTRING)
BEGIN
SET @snt = Param1; 
PREPARE sent FROM @snt;
EXECUTE sent;
DEALLOCATE PREPARE sent;

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_Recibos_Borrar_a_Ftra
DROP PROCEDURE IF EXISTS `function_Recibos_Borrar_a_Ftra`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_Recibos_Borrar_a_Ftra`(IN `param_clientes_o_proveedores` CHAR(1), IN `param_id_facturas` BIGINT)
BEGIN
		-- ----------------------------------------------------------------------------------------------------------------- --
		-- SOLO ACTUALIZAREMOS SUS RECIBOS SI SE INTRODUJO LA ID DE LA FACTURA
		-- ----------------------------------------------------------------------------------------------------------------- --
		IF param_id_facturas <> 0 THEN
			BEGIN
        		IF param_clientes_o_proveedores = 'C' THEN
        		
        			-- ------------------------------------------------------------------------------------------------------ --
        			-- SE TRATA DE UNA FACTURA DE VENTAS
        			-- ------------------------------------------------------------------------------------------------------ --
        			BEGIN
        				-- --------------------------------------------------------------------------------------------------- --
        				-- SI NO ESTA CERRADA LA FACTURA PUES CREAMOS SUS RECIBOS / CARTERA
        				-- --------------------------------------------------------------------------------------------------- --
						IF NOT EXISTS( SELECT fco.*
						               FROM facturas_ventas AS fco
						               RIGHT JOIN facturas_cerradas AS fce
						               ON fce.id_empresas = fco.id_empresas AND
						                  fco.Fecha >= fce.Desde AND
						                  fco.Fecha <= fce.Hasta AND
						                  fce.Del_WHEN IS NULL AND
						                  fce.Tipo_Ventas_o_Compras_VC = 'V'
						               WHERE fco.id = param_id_facturas
						               ORDER BY fco.id ) THEN
							BEGIN
								-- --------------------------------------------------------------------------------------------- --
								-- PRIMERO, SE BORRAN TODOS LOS VENCIMIENTOS QUE TUVIERA LA FACTURA 
								-- --------------------------------------------------------------------------------------------- --
								DELETE FROM facturas_cobros_pagos
								WHERE id_facturas = param_id_facturas 
		            		AND NOT id_clientes IS NULL
		            		ORDER BY id_clientes ASC, id_facturas ASC, id ASC;
							END;
						END IF;			
						
					END;
					
					
				ELSE
				
				
        			-- ------------------------------------------------------------------------------------------------------ --
        			-- SE TRATA DE UNA FACTURA DE COMPRAS
        			-- ------------------------------------------------------------------------------------------------------ --
        			BEGIN
        				-- --------------------------------------------------------------------------------------------------- --
        				-- SI NO ESTA CERRADA LA FACTURA PUES CREAMOS SUS RECIBOS / CARTERA
        				-- --------------------------------------------------------------------------------------------------- --
						IF NOT EXISTS( SELECT fco.*
					                  FROM facturas_compras AS fco
					                  RIGHT JOIN facturas_cerradas AS fce
					                  ON fce.id_empresas = fco.id_empresas AND
					                     fco.Fecha >= fce.Desde AND
					                     fco.Fecha <= fce.Hasta AND
					                     fce.Del_WHEN IS NULL AND
					                     fce.Tipo_Ventas_o_Compras_VC = 'C'
					                  WHERE fco.id = param_id_facturas
					                  ORDER BY fco.id ) THEN
					        BEGIN
									-- --------------------------------------------------------------------------------------------------- --
									-- PRIMERO, SE BORRAN TODOS LOS VENCIMIENTOS QUE TUVIERA LA FACTURA 
									-- --------------------------------------------------------------------------------------------------- --
									DELETE FROM facturas_cobros_pagos
									WHERE id_facturas = param_id_facturas 
			            		AND NOT id_proveedores IS NULL
			            		ORDER BY id_proveedores ASC, id_facturas ASC, id ASC;
							  END;
						END IF;	
				
					END;
				END IF;	
				
			END;
		END IF;				


END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_Recibos_Crear_a_Ftra
DROP PROCEDURE IF EXISTS `function_Recibos_Crear_a_Ftra`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_Recibos_Crear_a_Ftra`(IN `param_clientes_o_proveedores` CHAR(1), IN `param_id_facturas` BIGINT, IN `param_id_users` BIGINT)
BEGIN
		-- ----------------------------------------------------------------------------------------------------------------- --
		-- SOLO ACTUALIZAREMOS SUS RECIBOS SI SE INTRODUJO LA ID DE LA FACTURA
		-- ----------------------------------------------------------------------------------------------------------------- --
		IF param_id_facturas <> 0 THEN
			BEGIN
				DECLARE var_Cliente_o_Proveedor BIGINT;
				DECLARE var_fecha_ftra DATETIME;
				DECLARE var_Vencimientos_Cantidad TINYINT;
				DECLARE var_Vencimientos_1_Dias TINYINT;
				DECLARE var_Vencimientos_Dias_Entre TINYINT;
				
				DECLARE var_donde_estoy TINYINT DEFAULT 0;
				DECLARE var_cantidad_que_queda DECIMAL(12,2);
				DECLARE var_cantidad_por_recibo DECIMAL(12,2);
				DECLARE var_total_ftra DECIMAL(12,2);
				DECLARE var_importe_recibo DECIMAL(12,2);
				DECLARE var_fecha_vencimiento DATETIME;
				DECLARE var_Vencimientos_automaticos_SN CHAR(1);
				
				DECLARE var_Year VARCHAR(15);
				DECLARE var_Month VARCHAR(15);
				DECLARE var_Day VARCHAR(15);
				DECLARE var_Hora VARCHAR(15);
				
				DECLARE var_Forma_pago_Dia_1 TINYINT DEFAULT 0;
				DECLARE var_Forma_pago_Dia_2 TINYINT DEFAULT 0;
				
        		IF param_clientes_o_proveedores = 'C' THEN
        		
        			-- ------------------------------------------------------------------------------------------------------ --
        			-- SE TRATA DE UNA FACTURA DE VENTAS
        			-- ------------------------------------------------------------------------------------------------------ --
        			BEGIN
        				-- --------------------------------------------------------------------------------------------------- --
        				-- SI NO ESTA CERRADA LA FACTURA PUES CREAMOS SUS RECIBOS / CARTERA
        				-- --------------------------------------------------------------------------------------------------- --
						IF NOT EXISTS( SELECT fco.*
						               FROM facturas_ventas AS fco
						               RIGHT JOIN facturas_cerradas AS fce
						               ON fce.id_empresas = fco.id_empresas AND
						                  fco.Fecha >= fce.Desde AND
						                  fco.Fecha <= fce.Hasta AND
						                  fce.Del_WHEN IS NULL AND
						                  fce.Tipo_Ventas_o_Compras_VC = 'V'
						               WHERE fco.id = param_id_facturas
						               ORDER BY fco.id ) THEN
							BEGIN
								-- --------------------------------------------------------------------------------------------- --
								-- PRIMERO, SE BORRAN TODOS LOS VENCIMIENTOS QUE TUVIERA LA FACTURA 
								-- --------------------------------------------------------------------------------------------- --
								CALL function_Recibos_Borrar_a_Ftra( param_clientes_o_proveedores, param_id_facturas );

								-- --------------------------------------------------------------------------------------------- --
								-- Traemos de la factura de ventas los datos que necesitamos            		
								-- --------------------------------------------------------------------------------------------- --
								SELECT f.id_clientes, 
										 f.Fecha,
										 f.Vencimientos_Cantidad,
										 f.Vencimientos_1_Dias,
										 f.Vencimientos_Dias_Entre,
										 f.Total_Total,
										 IFNULL(f.Forma_pago_Dia_1, 0),
										 IFNULL(f.Forma_pago_Dia_2, 0)
										 
								INTO var_Cliente_o_Proveedor, 
								     var_fecha_ftra,
								     var_Vencimientos_Cantidad,
								     var_Vencimientos_1_Dias,
								     var_Vencimientos_Dias_Entre,
								     var_total_ftra,
								     var_Forma_pago_Dia_1,
								     var_Forma_pago_Dia_2
								     
								FROM facturas_ventas AS f
								WHERE f.id = param_id_facturas; 
							    
								-- --------------------------------------------------------------------------------------------- --
								-- AHORA PASAMOS A CREAR CADA UNO DE LOS VENCIMIENTOS QUE NECESITE LA FACTURA
								-- --------------------------------------------------------------------------------------------- --
								SET var_cantidad_por_recibo = var_total_ftra / var_Vencimientos_Cantidad;
								SET var_cantidad_que_queda = var_total_ftra;
								SET var_donde_estoy = 1;
								
								WHILE var_donde_estoy <= var_Vencimientos_Cantidad DO
									BEGIN
										-- --------------------------------------------------------------------------------------- --
										-- Vamos a ver cual es la cantidad para el próximo vencimiento
										-- --------------------------------------------------------------------------------------- --
										IF var_donde_estoy = var_Vencimientos_Cantidad THEN
											BEGIN
												SET var_importe_recibo = var_cantidad_que_queda;
											END;
										ELSE
											BEGIN
												SET var_importe_recibo = var_cantidad_por_recibo;
											END;
										END IF;
										
										SET var_cantidad_que_queda = var_cantidad_que_queda - var_importe_recibo;
										
										-- --------------------------------------------------------------------------------------- --
										-- Vamos a ver cual es la fecha para para el próximo vencimiento
										-- --------------------------------------------------------------------------------------- --
										SET var_fecha_vencimiento = DATE_ADD(var_fecha_ftra, INTERVAL (var_Vencimientos_1_Dias * var_donde_estoy) DAY);
										
										-- --------------------------------------------------------------------------------------- --
										-- Separamos el año, mes, dia y hora de la fecha de vencimiento
										-- --------------------------------------------------------------------------------------- --
										-- select YEAR(NOW());  #Selecciona el año
										-- select MONTH (NOW()) as mes;  #Selecciona el mes
										-- select DAY(NOW()) as dia; #Selecciona el día 
										-- select TIME(NOW()) as hora;  #Selecciona la hora
										-- Select LAST_DAY(NOW()); # Selecciona el ultimo dia del mes
										-- --------------------------------------------------------------------------------------- --
										-- VER EJEMPLOS EN ... http://www.cristalab.com/tutoriales/fechas-con-mysql-c84136l/
										-- --------------------------------------------------------------------------------------- --
										SET var_Year  = YEAR(var_fecha_vencimiento);  -- Selecciona el AÑO
										SET var_Month = MONTH(var_fecha_vencimiento); -- Selecciona el MES
										SET var_Day   = DAY(var_fecha_vencimiento);   -- Selecciona el DIA
										SET var_Hora  = TIME(var_fecha_vencimiento);  -- Selecciona la HORA
										
										-- --------------------------------------------------------------------------------------- --
										-- El primer día no puede ser mayor que el segundo día de pago
										-- --------------------------------------------------------------------------------------- --
										IF (var_Forma_pago_Dia_1 > var_Forma_pago_Dia_2) then
											BEGIN
												SET var_Forma_pago_Dia_1 = var_Forma_pago_Dia_2;
												SET var_Forma_pago_Dia_2 = var_Forma_pago_Dia_1;
											END;
										END IF;
										
										-- --------------------------------------------------------------------------------------- --
										-- Cambiamos el vencimiento solo si se puso algún día fijo de pago
										-- --------------------------------------------------------------------------------------- --
										IF var_Forma_pago_Dia_1 <> 0 OR
										   var_Forma_pago_Dia_2 <> 0 THEN
											BEGIN
												IF var_Day <= var_Forma_pago_Dia_2 AND
												   var_Day >= var_Forma_pago_Dia_1 THEN
													BEGIN
									            	-- --------------------------------------------------------------------------- --
													   -- El dia del vencimiento puede ser igual al primer día de pago o superior al 
														-- primer día de pago. Por lo que si es igual al primer día, pues lo dejamos, 
														-- pero si es mayor pues ponemos como vencimiento el segundo día de pago
									            	-- --------------------------------------------------------------------------- --
													   IF var_Day > var_Forma_pago_Dia_1 THEN
														   BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_2 )
																											 AS DATETIME );
														   END;
													   END IF;
													END;
												ELSE 
													BEGIN
									            	-- --------------------------------------------------------------------------- --
													   -- El día de pago puede ser inferior al primer día de pago o superior a el 
														-- segundo día.                                                     
									            	-- --------------------------------------------------------------------------- --
													   -- Imaginemos que los días de pago son 15 y 20 ...
													   -- Ahora el programa nos ha calculado como vencimiento el día 13, pues tenemos 
														-- que ponerle el 15.
													   -- Pero y si calculo el 21, pues tambien tenemos que ponerle el 15.
									            	-- --------------------------------------------------------------------------- --
													   -- Pero imaginemos que los días de pago son 0(no se puso el 1er.día) y 20 para 
														-- el segundo día de pago
													   -- Ahora el programa nos ha calculado como vencimiento el día 13, pues tenemos 
														-- que ponerle el 20.
													   -- Pero y si calculo el 21, pues tambien tenemos que ponerle el 20.
									            	-- --------------------------------------------------------------------------- --
													   if var_Forma_pago_Dia_1 <> 0 then
														   BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_1 )
																											 AS DATETIME );
														   END;
														ELSE 
															BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_2 )
																											 AS DATETIME );
														   END;
													   END IF;
													   
													END;
												END IF;

											END;
										END IF;
										
										-- --------------------------------------------------------------------------------------- --
										-- Pasamos a crear el vencimiento con todos los campos calculados hasta el momento
										-- --------------------------------------------------------------------------------------- --
										INSERT INTO facturas_cobros_pagos (
										   id_clientes, -- id_proveedores,
					
										   id_facturas,
										   fecha_expedicion,
										   
										   fecha_vencimiento,
										   importe,
										   
										   Insert_WHEN,
										   Insert_Id_User )
									   
										VALUES (
											var_Cliente_o_Proveedor,
											
											param_id_facturas,
											var_fecha_ftra,
											
										   var_fecha_vencimiento,
										   var_importe_recibo,
											
											NOW(),
											param_id_users );
											
										SET var_donde_estoy = var_donde_estoy + 1;
									END;
								END WHILE;
							END;
						END IF;			
						
					END;
					
					
				ELSE
				
				
        			-- ------------------------------------------------------------------------------------------------------ --
        			-- SE TRATA DE UNA FACTURA DE COMPRAS
        			-- ------------------------------------------------------------------------------------------------------ --
        			BEGIN
        				-- --------------------------------------------------------------------------------------------------- --
        				-- SI NO ESTA CERRADA LA FACTURA PUES CREAMOS SUS RECIBOS / CARTERA
        				-- --------------------------------------------------------------------------------------------------- --
						 IF NOT EXISTS( SELECT fco.*
					                   FROM facturas_compras AS fco
					                   RIGHT JOIN facturas_cerradas AS fce
					                   ON fce.id_empresas = fco.id_empresas AND
					                      fco.Fecha >= fce.Desde AND
					                      fco.Fecha <= fce.Hasta AND
					                      fce.Del_WHEN IS NULL AND
					                      fce.Tipo_Ventas_o_Compras_VC = 'C'
					                   WHERE fco.id = param_id_facturas
					                   ORDER BY fco.id ) THEN
					   	BEGIN
								-- --------------------------------------------------------------------------------------------------- --
								-- PRIMERO, SE BORRAN TODOS LOS VENCIMIENTOS QUE TUVIERA LA FACTURA 
								-- --------------------------------------------------------------------------------------------------- --
								CALL function_Recibos_Borrar_a_Ftra( param_clientes_o_proveedores, param_id_facturas );

								-- --------------------------------------------------------------------------------------------------- --
								-- Traemos de la factura de compras los datos que necesitamos            		
								-- --------------------------------------------------------------------------------------------------- --
								SELECT f.id_proveedores, 
										 f.Fecha,
										 f.Vencimientos_Cantidad,
										 f.Vencimientos_1_Dias,
										 f.Vencimientos_Dias_Entre,
										 f.Total_Total,
										 IFNULL(f.Forma_pago_Dia_1, 0),
										 IFNULL(f.Forma_pago_Dia_2, 0)
										 
								INTO var_Cliente_o_Proveedor, 
								     var_fecha_ftra,
								     var_Vencimientos_Cantidad,
								     var_Vencimientos_1_Dias,
								     var_Vencimientos_Dias_Entre,
								     var_total_ftra,
								     var_Forma_pago_Dia_1,
								     var_Forma_pago_Dia_2
								     
								FROM facturas_compras AS f
								WHERE f.id = param_id_facturas; 
							    
								-- --------------------------------------------------------------------------------------------------------- --
								-- AHORA PASAMOS A CREAR CADA UNO DE LOS VENCIMIENTOS QUE NECESITE LA FACTURA
								-- --------------------------------------------------------------------------------------------------------- --
								SET var_cantidad_por_recibo = var_total_ftra / var_Vencimientos_Cantidad;
								SET var_cantidad_que_queda = var_total_ftra;
								SET var_donde_estoy = 1;
								
								WHILE var_donde_estoy <= var_Vencimientos_Cantidad DO
									BEGIN
										-- --------------------------------------------------------------------------------------------------- --
										-- Vamos a ver cual es la cantidad para el próximo vencimiento
										-- --------------------------------------------------------------------------------------------------- --
										IF var_donde_estoy = var_Vencimientos_Cantidad THEN
											BEGIN
												SET var_importe_recibo = var_cantidad_que_queda;
											END;
										ELSE
											BEGIN
												SET var_importe_recibo = var_cantidad_por_recibo;
											END;
										END IF;
										
										SET var_cantidad_que_queda = var_cantidad_que_queda - var_importe_recibo;
										
										-- --------------------------------------------------------------------------------------------------- --
										-- Vamos a ver cual es la fecha para para el próximo vencimiento
										-- --------------------------------------------------------------------------------------------------- --
										SET var_fecha_vencimiento = DATE_ADD(var_fecha_ftra, INTERVAL (var_Vencimientos_1_Dias * var_donde_estoy) DAY);
										
										-- --------------------------------------------------------------------------------------- --
										-- Separamos el año, mes, dia y hora de la fecha de vencimiento
										-- --------------------------------------------------------------------------------------- --
										-- select YEAR(NOW());  #Selecciona el año
										-- select MONTH (NOW()) as mes;  #Selecciona el mes
										-- select DAY(NOW()) as dia; #Selecciona el día 
										-- select TIME(NOW()) as hora;  #Selecciona la hora
										-- Select LAST_DAY(NOW()); # Selecciona el ultimo dia del mes
										-- --------------------------------------------------------------------------------------- --
										-- VER EJEMPLOS EN ... http://www.cristalab.com/tutoriales/fechas-con-mysql-c84136l/
										-- --------------------------------------------------------------------------------------- --
										SET var_Year  = YEAR(var_fecha_vencimiento);  -- Selecciona el AÑO
										SET var_Month = MONTH(var_fecha_vencimiento); -- Selecciona el MES
										SET var_Day   = DAY(var_fecha_vencimiento);   -- Selecciona el DIA
										SET var_Hora  = TIME(var_fecha_vencimiento);  -- Selecciona la HORA
										
										-- --------------------------------------------------------------------------------------- --
										-- El primer día no puede ser mayor que el segundo día de pago
										-- --------------------------------------------------------------------------------------- --
										IF (var_Forma_pago_Dia_1 > var_Forma_pago_Dia_2) then
											BEGIN
												SET var_Forma_pago_Dia_1 = var_Forma_pago_Dia_2;
												SET var_Forma_pago_Dia_2 = var_Forma_pago_Dia_1;
											END;
										END IF;
										
										-- --------------------------------------------------------------------------------------- --
										-- Cambiamos el vencimiento solo si se puso algún día fijo de pago
										-- --------------------------------------------------------------------------------------- --
										IF var_Forma_pago_Dia_1 <> 0 OR
										   var_Forma_pago_Dia_2 <> 0 THEN
											BEGIN
												IF var_Day <= var_Forma_pago_Dia_2 AND
												   var_Day >= var_Forma_pago_Dia_1 THEN
													BEGIN
									            	-- --------------------------------------------------------------------------- --
													   -- El dia del vencimiento puede ser igual al primer día de pago o superior al 
														-- primer día de pago. Por lo que si es igual al primer día, pues lo dejamos, 
														-- pero si es mayor pues ponemos como vencimiento el segundo día de pago
									            	-- --------------------------------------------------------------------------- --
													   IF var_Day > var_Forma_pago_Dia_1 THEN
														   BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_2 )
																											 AS DATETIME );
														   END;
													   END IF;
													END;
												ELSE 
													BEGIN
									            	-- --------------------------------------------------------------------------- --
													   -- El día de pago puede ser inferior al primer día de pago o superior a el 
														-- segundo día.                                                     
									            	-- --------------------------------------------------------------------------- --
													   -- Imaginemos que los días de pago son 15 y 20 ...
													   -- Ahora el programa nos ha calculado como vencimiento el día 13, pues tenemos 
														-- que ponerle el 15.
													   -- Pero y si calculo el 21, pues tambien tenemos que ponerle el 15.
									            	-- --------------------------------------------------------------------------- --
													   -- Pero imaginemos que los días de pago son 0(no se puso el 1er.día) y 20 para 
														-- el segundo día de pago
													   -- Ahora el programa nos ha calculado como vencimiento el día 13, pues tenemos 
														-- que ponerle el 20.
													   -- Pero y si calculo el 21, pues tambien tenemos que ponerle el 20.
									            	-- --------------------------------------------------------------------------- --
													   if var_Forma_pago_Dia_1 <> 0 then
														   BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_1 )
																											 AS DATETIME );
														   END;
														ELSE 
															BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_2 )
																											 AS DATETIME );
														   END;
													   END IF;
													   
													END;
												END IF;

											END;
										END IF;
										
										-- --------------------------------------------------------------------------------------- --
										-- Pasamos a crear el vencimiento con todos los campos calculados hasta el momento
										-- --------------------------------------------------------------------------------------- --
										INSERT INTO facturas_cobros_pagos (
										   id_proveedores, 
					
										   id_facturas,
										   fecha_expedicion,
										   
										   fecha_vencimiento,
										   importe,
										   
										   Insert_WHEN,
										   Insert_Id_User )
									   
										VALUES (
											var_Cliente_o_Proveedor,
											
											param_id_facturas,
											var_fecha_ftra,
											
										   var_fecha_vencimiento,
											var_importe_recibo,
											
											NOW(),
											param_id_users );
											
										SET var_donde_estoy = var_donde_estoy + 1;
									END;
								END WHILE;
								
							END;
						END IF;	
				
					END;
				END IF;	
				
			END;
		END IF;				


END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.funct_Impresora_Predeterminada
DROP PROCEDURE IF EXISTS `funct_Impresora_Predeterminada`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `funct_Impresora_Predeterminada`(IN `param_id` BIGINT)
BEGIN
	UPDATE impresoras
	SET predeterminada_SN = 'N';

	UPDATE impresoras
	SET predeterminada_SN = 'S'
   WHERE id = param_id;
END//
DELIMITER ;


-- Volcando estructura para disparador socger.TRIGGER_albaranes_compras_detalles_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_albaranes_compras_detalles_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_albaranes_compras_detalles_AFTER_INSERT` AFTER INSERT ON `albaranes_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del albarán
	-- -------------------------------------------------------------------------- --
	CALL function_ACT_totales_albaranes_compras( NEW.id_albaranes, NEW.Insert_Id_User );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_albaranes_compras_detalles_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_albaranes_compras_detalles_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_albaranes_compras_detalles_AFTER_UPDATE` AFTER UPDATE ON `albaranes_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del albarán
	-- -------------------------------------------------------------------------- --
	DECLARE var_id_users BIGINT;
	
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			SET var_id_users = NEW.Change_Id_User;
		END;
	ELSE
		BEGIN
			SET var_id_users = NEW.Del_Id_User;
		END;
	END IF;
	
	CALL function_ACT_totales_albaranes_compras( NEW.id_albaranes, var_id_users );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_albaranes_compras_detalles_BEFORE_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_albaranes_compras_detalles_BEFORE_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_albaranes_compras_detalles_BEFORE_INSERT` BEFORE INSERT ON `albaranes_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el proveedor a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes = ( SELECT ac.id_almacenes 
	                         FROM albaranes_compras AS ac
			  					    WHERE ac.id = NEW.id_albaranes
								    ORDER BY ac.id );
								
	SET NEW.id_proveedores = ( SELECT ac.id_proveedores 
	                           FROM albaranes_compras AS ac
							         WHERE ac.id = NEW.id_albaranes
							         ORDER BY ac.id );
	
	IF NOT NEW.id_articulos IS NULL THEN 
		BEGIN
			-- ------------------------------------------------------------------------------------ --
			-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
			-- ------------------------------------------------------------------------------------ --
			DECLARE var_Tipo_de_articulo VARCHAR(1);
			
			SELECT Tipo_de_articulo 
			INTO var_Tipo_de_articulo 
			FROM articulos AS art
			WHERE art.id = NEW.id_articulos; 
		    
			IF var_Tipo_de_articulo = '0' THEN 
				BEGIN
					-- ------------------------------------------------------------------------------ --
					-- Es un artículo al que tenemos que controlarle el stock               
					-- ------------------------------------------------------------------------------ --
					-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
					-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
					-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
					-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
					-- lo en la tabla articulos_stock si no existe
					-- ------------------------------------------------------------------------------ --
					IF NOT NEW.id_almacenes IS NULL AND
					   NOT NEW.Unidades IS NULL     THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
                                                             NEW.id_almacenes );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							UPDATE articulos_stock AS arts
							SET arts.Stock = arts.Stock + NEW.Unidades
							WHERE arts.id_articulos = NEW.id_articulos
							AND arts.id_almacenes = NEW.id_almacenes;
							
						END;
					END IF;
					
				END;
			END IF;
      
		END;
	END IF;

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_albaranes_compras_detalles_BEFORE_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_albaranes_compras_detalles_BEFORE_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_albaranes_compras_detalles_BEFORE_UPDATE` BEFORE UPDATE ON `albaranes_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el proveedor a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	set NEW.id_almacenes = ( SELECT ac.id_almacenes 
	                         FROM albaranes_compras AS ac
			  					    WHERE ac.id = NEW.id_albaranes
								    ORDER BY ac.id );
								
	SET NEW.id_proveedores = ( SELECT ac.id_proveedores 
	                           FROM albaranes_compras AS ac
							         WHERE ac.id = NEW.id_albaranes
							         ORDER BY ac.id );
	
	-- ------------------------------------------------------------------------------------------ --
	-- Si el artículo antes de ser modificado, pertenecía a un artículo que se le controlaba el
	-- stock pues primero quitamos del stock el valor de OLD.Unidades que tuviera anteriormente   
	-- ------------------------------------------------------------------------------------------ --
	IF NOT OLD.id_articulos IS NULL THEN 
		BEGIN
			-- ------------------------------------------------------------------------------------ --
			-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
			-- ------------------------------------------------------------------------------------ --
			DECLARE var_Tipo_de_articulo VARCHAR(1);
			
			SELECT Tipo_de_articulo 
			INTO var_Tipo_de_articulo 
			FROM articulos AS art
			WHERE art.id = OLD.id_articulos; 
		    
			IF var_Tipo_de_articulo = '0' THEN 
				BEGIN
					-- ------------------------------------------------------------------------------ --
					-- Es un artículo al que tenemos que controlarle el stock               
					-- ------------------------------------------------------------------------------ --
					-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
					-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
					-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
					-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
					-- lo en la tabla articulos_stock si no existe
					-- ------------------------------------------------------------------------------ --
					IF NOT OLD.id_almacenes IS NULL AND
					   NOT OLD.Unidades IS NULL     THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( OLD.id_articulos,
                                                             OLD.id_almacenes );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							IF OLD.Del_WHEN IS NULL THEN
								BEGIN
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock - OLD.Unidades
									WHERE arts.id_articulos = OLD.id_articulos
									AND arts.id_almacenes = OLD.id_almacenes;
								END;
							END IF;
							
						END;
					END IF;
					
				END;
			END IF;
      
		END;
	END IF;

	-- ------------------------------------------------------------------------------------------ --
	-- Si el artículo después de ser modificado, pertenece a un artículo que se le controla el
	-- stock pues primero quitamos del stock el valor de NEW.Unidades            
	-- ------------------------------------------------------------------------------------------ --
	IF NOT NEW.id_articulos IS NULL THEN 
		BEGIN
			-- ------------------------------------------------------------------------------------ --
			-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
			-- ------------------------------------------------------------------------------------ --
			DECLARE var_Tipo_de_articulo VARCHAR(1);
			
			SELECT Tipo_de_articulo 
			INTO var_Tipo_de_articulo 
			FROM articulos AS art
			WHERE art.id = NEW.id_articulos; 
		    
			IF var_Tipo_de_articulo = '0' THEN 
				BEGIN
					-- ------------------------------------------------------------------------------ --
					-- Es un artículo al que tenemos que controlarle el stock               
					-- ------------------------------------------------------------------------------ --
					-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
					-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
					-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
					-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
					-- lo en la tabla articulos_stock si no existe
					-- ------------------------------------------------------------------------------ --
					IF NOT NEW.id_almacenes IS NULL AND
					   NOT NEW.Unidades IS NULL     THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
                                                             NEW.id_almacenes );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							IF NEW.Del_WHEN IS NULL THEN
								BEGIN
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock + NEW.Unidades
									WHERE arts.id_articulos = NEW.id_articulos
									AND arts.id_almacenes = NEW.id_almacenes;
								END;
							END IF;
							
						END;
					END IF;
					
				END;
			END IF;
      
		END;
	END IF;

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_albaranes_ventas_detalles_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_albaranes_ventas_detalles_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_albaranes_ventas_detalles_AFTER_INSERT` AFTER INSERT ON `albaranes_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales deL albarán
	-- -------------------------------------------------------------------------- --
	CALL function_ACT_totales_albaranes_ventas( NEW.id_albaranes, NEW.Insert_Id_User );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_albaranes_ventas_detalles_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_albaranes_ventas_detalles_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_albaranes_ventas_detalles_AFTER_UPDATE` AFTER UPDATE ON `albaranes_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del albaran
	-- -------------------------------------------------------------------------- --
	DECLARE var_id_users BIGINT;
	
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			SET var_id_users = NEW.Change_Id_User;
		END;
	ELSE
		BEGIN
			SET var_id_users = NEW.Del_Id_User;
		END;
	END IF;
	
	CALL function_ACT_totales_albaranes_ventas( NEW.id_albaranes, var_id_users );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_albaranes_ventas_detalles_BEFORE_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_albaranes_ventas_detalles_BEFORE_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_albaranes_ventas_detalles_BEFORE_INSERT` BEFORE INSERT ON `albaranes_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el cliente a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	set NEW.id_almacenes = ( SELECT av.id_almacenes 
	                         FROM albaranes_ventas AS av
			  					    WHERE av.id = NEW.id_albaranes 
								    ORDER BY av.id );
								
	SET NEW.id_clientes = ( SELECT av.id_clientes 
	                        FROM albaranes_ventas AS av
							      WHERE av.id = NEW.id_albaranes 
							      ORDER BY av.id );
	
	IF NOT NEW.id_articulos IS NULL THEN 
		BEGIN
			-- ------------------------------------------------------------------------------------ --
			-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
			-- ------------------------------------------------------------------------------------ --
			DECLARE var_Tipo_de_articulo VARCHAR(1);
			
			SELECT Tipo_de_articulo 
			INTO var_Tipo_de_articulo 
			FROM articulos AS art
			WHERE art.id = NEW.id_articulos; 
		    
			IF var_Tipo_de_articulo = '0' THEN 
				BEGIN
					-- ------------------------------------------------------------------------------ --
					-- Es un artículo al que tenemos que controlarle el stock               
					-- ------------------------------------------------------------------------------ --
					-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
					-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
					-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
					-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
					-- lo en la tabla articulos_stock si no existe
					-- ------------------------------------------------------------------------------ --
					IF NOT NEW.id_almacenes IS NULL AND
					   NOT NEW.Unidades IS NULL     THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
                                                             NEW.id_almacenes );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							UPDATE articulos_stock AS arts
							SET arts.Stock = arts.Stock - NEW.Unidades
							WHERE arts.id_articulos = NEW.id_articulos
							AND arts.id_almacenes = NEW.id_almacenes;
							
						END;
					END IF;
					
				END;
			END IF;
      
		END;
	END IF;

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_albaranes_ventas_detalles_BEFORE_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_albaranes_ventas_detalles_BEFORE_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_albaranes_ventas_detalles_BEFORE_UPDATE` BEFORE UPDATE ON `albaranes_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el cliente a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	set NEW.id_almacenes = ( SELECT av.id_almacenes 
	                         FROM albaranes_ventas AS av
			  					    WHERE av.id = NEW.id_albaranes 
								    ORDER BY av.id );
								
	SET NEW.id_clientes = ( SELECT av.id_clientes 
	                        FROM albaranes_ventas AS av
							      WHERE av.id = NEW.id_albaranes 
							      ORDER BY av.id );
	
	-- ------------------------------------------------------------------------------------------ --
	-- Si el artículo antes de ser modificado, pertenecía a un artículo que se le controlaba el
	-- stock pues primero quitamos del stock el valor de OLD.Unidades que tuviera anteriormente   
	-- ------------------------------------------------------------------------------------------ --
	IF NOT OLD.id_articulos IS NULL THEN 
		BEGIN
			-- ------------------------------------------------------------------------------------ --
			-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
			-- ------------------------------------------------------------------------------------ --
			DECLARE var_Tipo_de_articulo VARCHAR(1);
			
			SELECT Tipo_de_articulo 
			INTO var_Tipo_de_articulo 
			FROM articulos AS art
			WHERE art.id = OLD.id_articulos; 
		    
			IF var_Tipo_de_articulo = '0' THEN 
				BEGIN
					-- ------------------------------------------------------------------------------ --
					-- Es un artículo al que tenemos que controlarle el stock               
					-- ------------------------------------------------------------------------------ --
					-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
					-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
					-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
					-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
					-- lo en la tabla articulos_stock si no existe
					-- ------------------------------------------------------------------------------ --
					IF NOT OLD.id_almacenes IS NULL AND
					   NOT OLD.Unidades IS NULL     THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( OLD.id_articulos,
                                                             OLD.id_almacenes );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							IF OLD.Del_WHEN IS NULL THEN
								BEGIN
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock + OLD.Unidades
									WHERE arts.id_articulos = OLD.id_articulos
									AND arts.id_almacenes = OLD.id_almacenes;
								END;
							END IF;
							
						END;
					END IF;
					
				END;
			END IF;
      
		END;
	END IF;

	-- ------------------------------------------------------------------------------------------ --
	-- Si el artículo después de ser modificado, pertenece a un artículo que se le controla el
	-- stock pues primero quitamos del stock el valor de NEW.Unidades            
	-- ------------------------------------------------------------------------------------------ --
	IF NOT NEW.id_articulos IS NULL THEN 
		BEGIN
			-- ------------------------------------------------------------------------------------ --
			-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
			-- ------------------------------------------------------------------------------------ --
			DECLARE var_Tipo_de_articulo VARCHAR(1);
			
			SELECT Tipo_de_articulo 
			INTO var_Tipo_de_articulo 
			FROM articulos AS art
			WHERE art.id = NEW.id_articulos; 
		    
			IF var_Tipo_de_articulo = '0' THEN 
				BEGIN
					-- ------------------------------------------------------------------------------ --
					-- Es un artículo al que tenemos que controlarle el stock               
					-- ------------------------------------------------------------------------------ --
					-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
					-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
					-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
					-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
					-- lo en la tabla articulos_stock si no existe
					-- ------------------------------------------------------------------------------ --
					IF NOT NEW.id_almacenes IS NULL AND
					   NOT NEW.Unidades IS NULL     THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
                                                             NEW.id_almacenes );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							IF NEW.Del_WHEN IS NULL THEN
								BEGIN
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock - NEW.Unidades
									WHERE arts.id_articulos = NEW.id_articulos
									AND arts.id_almacenes = NEW.id_almacenes;
								END;
							END IF;
							
						END;
					END IF;
					
				END;
			END IF;
      
		END;
	END IF;

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_almacenes_movimientos_detalles_BEFORE_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_almacenes_movimientos_detalles_BEFORE_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_almacenes_movimientos_detalles_BEFORE_INSERT` BEFORE INSERT ON `almacenes_movimientos_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el cliente a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes_destino = ( SELECT am.id_almacenes_destino
	                                 FROM almacenes_movimientos AS am
			  					            WHERE am.id = NEW.id_almacenes_movimientos 
								            ORDER BY am.id );
								
	SET NEW.id_almacenes_origen = ( SELECT am.id_almacenes_origen
	                                 FROM almacenes_movimientos AS am
			  					            WHERE am.id = NEW.id_almacenes_movimientos 
								            ORDER BY am.id );
	
	IF NOT NEW.id_articulos IS NULL THEN 
		BEGIN
			-- ------------------------------------------------------------------------------------ --
			-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
			-- ------------------------------------------------------------------------------------ --
			DECLARE var_Tipo_de_articulo VARCHAR(1);
			
			SELECT Tipo_de_articulo 
			INTO var_Tipo_de_articulo 
			FROM articulos AS art
			WHERE art.id = NEW.id_articulos; 
		    
			IF var_Tipo_de_articulo = '0' THEN 
				BEGIN
					-- ------------------------------------------------------------------------------ --
					-- Es un artículo al que tenemos que controlarle el stock               
					-- ------------------------------------------------------------------------------ --
					-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
					-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
					-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
					-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
					-- lo en la tabla articulos_stock si no existe
					-- ------------------------------------------------------------------------------ --
					IF NOT NEW.id_almacenes_destino IS NULL AND
					   NOT NEW.Unidades IS NULL             THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
                                                             NEW.id_almacenes_destino );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							UPDATE articulos_stock AS arts
							SET arts.Stock = arts.Stock + NEW.Unidades
							WHERE arts.id_articulos = NEW.id_articulos
							AND arts.id_almacenes = NEW.id_almacenes_destino;
							
						END;
					END IF;
					
					IF NOT NEW.id_almacenes_origen IS NULL AND
					   NOT NEW.Unidades IS NULL            THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
                                                             NEW.id_almacenes_origen );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							UPDATE articulos_stock AS arts
							SET arts.Stock = arts.Stock - NEW.Unidades
							WHERE arts.id_articulos = NEW.id_articulos
							AND arts.id_almacenes = NEW.id_almacenes_origen;
							
						END;
					END IF;
					
				END;
			END IF;
      
		END;
	END IF;

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_almacenes_movimientos_detalles_BEFORE_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_almacenes_movimientos_detalles_BEFORE_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_almacenes_movimientos_detalles_BEFORE_UPDATE` BEFORE UPDATE ON `almacenes_movimientos_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el cliente a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes_destino = ( SELECT am.id_almacenes_destino
	                                 FROM almacenes_movimientos AS am
			  					            WHERE am.id = NEW.id_almacenes_movimientos 
								            ORDER BY am.id );
								
	SET NEW.id_almacenes_origen = ( SELECT am.id_almacenes_origen
	                                 FROM almacenes_movimientos AS am
			  					            WHERE am.id = NEW.id_almacenes_movimientos 
								            ORDER BY am.id );
	
	IF NOT OLD.id_articulos IS NULL THEN 
		BEGIN
			-- ------------------------------------------------------------------------------------ --
			-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
			-- ------------------------------------------------------------------------------------ --
			DECLARE var_Tipo_de_articulo VARCHAR(1);
			
			SELECT Tipo_de_articulo 
			INTO var_Tipo_de_articulo 
			FROM articulos AS art
			WHERE art.id = OLD.id_articulos; 
		    
			IF var_Tipo_de_articulo = '0' THEN 
				BEGIN
					-- ------------------------------------------------------------------------------ --
					-- Es un artículo al que tenemos que controlarle el stock               
					-- ------------------------------------------------------------------------------ --
					-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
					-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
					-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
					-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
					-- lo en la tabla articulos_stock si no existe
					-- ------------------------------------------------------------------------------ --
					IF NOT OLD.id_almacenes_destino IS NULL AND
					   NOT OLD.Unidades IS NULL             THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( OLD.id_articulos,
                                                             OLD.id_almacenes_destino );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							IF OLD.Del_WHEN IS NULL THEN
								BEGIN
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock - OLD.Unidades
									WHERE arts.id_articulos = OLD.id_articulos
									AND arts.id_almacenes = OLD.id_almacenes_destino;
								END;
							END IF;
							
						END;
					END IF;
					
					IF NOT OLD.id_almacenes_origen IS NULL AND
					   NOT OLD.Unidades IS NULL            THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( OLD.id_articulos,
                                                             OLD.id_almacenes_origen );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							IF OLD.Del_WHEN IS NULL THEN
								BEGIN
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock + OLD.Unidades
									WHERE arts.id_articulos = OLD.id_articulos
									AND arts.id_almacenes = OLD.id_almacenes_origen;
								END;
							END IF;
							
						END;
					END IF;
					
				END;
			END IF;
      
		END;
	END IF;





	IF NOT NEW.id_articulos IS NULL THEN 
		BEGIN
			-- ------------------------------------------------------------------------------------ --
			-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
			-- ------------------------------------------------------------------------------------ --
			DECLARE var_Tipo_de_articulo VARCHAR(1);
			
			SELECT Tipo_de_articulo 
			INTO var_Tipo_de_articulo 
			FROM articulos AS art
			WHERE art.id = NEW.id_articulos; 
		    
			IF var_Tipo_de_articulo = '0' THEN 
				BEGIN
					-- ------------------------------------------------------------------------------ --
					-- Es un artículo al que tenemos que controlarle el stock               
					-- ------------------------------------------------------------------------------ --
					-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
					-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
					-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
					-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
					-- lo en la tabla articulos_stock si no existe
					-- ------------------------------------------------------------------------------ --
					IF NOT NEW.id_almacenes_destino IS NULL AND
					   NOT NEW.Unidades IS NULL             THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
                                                             NEW.id_almacenes_destino );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							IF NEW.Del_WHEN IS NULL THEN
								BEGIN
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock + NEW.Unidades
									WHERE arts.id_articulos = NEW.id_articulos
									AND arts.id_almacenes = NEW.id_almacenes_destino;
								END;
							END IF;
							
						END;
					END IF;
					
					IF NOT NEW.id_almacenes_origen IS NULL AND
					   NOT NEW.Unidades IS NULL            THEN
						BEGIN
							-- ------------------------------------------------------------------------ --
							-- Es imprescindible el almacén/tienda para controlar el stock del artículo
							-- ------------------------------------------------------------------------ --
							CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
                                                             NEW.id_almacenes_origen );
                                                             
							-- ------------------------------------------------------------------------ --
							-- Ahora pasamos a controlar el stock
							-- ------------------------------------------------------------------------ --
							IF NEW.Del_WHEN IS NULL THEN
								BEGIN
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock - NEW.Unidades
									WHERE arts.id_articulos = NEW.id_articulos
									AND arts.id_almacenes = NEW.id_almacenes_origen;
								END;
							END IF;
							
						END;
					END IF;
					
				END;
			END IF;
      
		END;
	END IF;


END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_articulos_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_articulos_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_articulos_AFTER_INSERT` AFTER INSERT ON `articulos` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Creamos todas las tarifas del artículo según las tarifas que ya existen y 
	-- no están dadas de baja
	-- -------------------------------------------------------------------------- --
	INSERT INTO articulos_tarifas
				( id_articulos,
				  id_tarifas,

				  Importe_Neto,
				  Importe_Impuestos_Incluidos,
				  Descuento,

				  Insert_WHEN,
				  Insert_Id_User )

	SELECT NEW.id,
          id,

          0,
          0,
          0,

          NEW.Insert_WHEN,
          NEW.Insert_Id_User

   FROM tarifas
   WHERE Del_WHEN IS NULL;

	-- -------------------------------------------------------------------------- --
	-- Creamos todos las terminales del artículo según los terminales que ya 
	-- existen y no están dadas de baja
	-- -------------------------------------------------------------------------- --
	INSERT INTO articulos_terminales
	       ( id_articulos,
	         id_terminales,
	         Visualizar_en_terminal_SN,
	
	         Insert_WHEN,
	         Insert_Id_User )
	
	SELECT NEW.id,
	       id,
	       'S',
	
	       NEW.Insert_WHEN,
	       NEW.Insert_Id_User
	
	FROM terminales
	WHERE Del_WHEN IS NULL;

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_articulos_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_articulos_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_articulos_AFTER_UPDATE` AFTER UPDATE ON `articulos` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Dependiendo de que sea un alta o una baja, doy de alta o doy de baja a las 
	-- tarifas y a los terminales
	-- -------------------------------------------------------------------------- --
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			-- -------------------------------------------------------------------- --
			-- Es un alta, pues anteriormente fue dada de baja
			-- -------------------------------------------------------------------- --
			-- Primero damos de ALTA a los TERMINALES del artículo que estuvieran
			-- dados de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_terminales
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_articulos = NEW.id
			AND NOT Del_WHEN IS NULL;
				 
			-- -------------------------------------------------------------------- --
			-- Ahora damos de ALTA a las TARIFAS del artículo que estuvieran dadas
			-- de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_tarifas
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_articulos = NEW.id
			AND NOT Del_WHEN IS NULL;
				 
			-- -------------------------------------------------------------------- --
			-- Ahora damos de ALTA a las COMPOSICIONES del artículo que estuvieran 
			-- dadas de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_composiciones
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_articulos = NEW.id
			AND NOT Del_WHEN IS NULL;
			
			-- -------------------------------------------------------------------- --
			-- Ahora damos de ALTA a las PROPORCIONES del artículo que estuvieran 
			-- dadas de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_proporciones
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_articulos = NEW.id
			AND NOT Del_WHEN IS NULL;
			
			-- -------------------------------------------------------------------- --
			-- Ahora damos de ALTA a las TARIFAS por PROPORCION del artículo que 
			-- estuvieran dadas de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_proporciones_tarifas
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_articulos = NEW.id
			AND NOT Del_WHEN IS NULL;
			
		END;
	ELSE
		BEGIN
			-- -------------------------------------------------------------------- --
			-- Es una baja
			-- -------------------------------------------------------------------- --
			-- Primero damos de BAJA a las TERMINALES del artículo
			-- -------------------------------------------------------------------- --
			UPDATE articulos_terminales
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_articulos = NEW.id
			AND Del_WHEN IS NULL;
				 
			-- -------------------------------------------------------------------- --
			-- Ahora damos de BAJA a las TARIFAS del artículo
			-- -------------------------------------------------------------------- --
			UPDATE articulos_tarifas
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_articulos = NEW.id
			AND Del_WHEN IS NULL;
				 
			-- -------------------------------------------------------------------- --
			-- Ahora damos de BAJA a las COMPOSICIONES del artículo
			-- -------------------------------------------------------------------- --
			UPDATE articulos_composiciones
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_articulos = NEW.id
			AND Del_WHEN IS NULL;
				 
			-- -------------------------------------------------------------------- --
			-- Ahora damos de BAJA a las PROPORCIONES del artículo
			-- -------------------------------------------------------------------- --
			UPDATE articulos_proporciones
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_articulos = NEW.id
			AND Del_WHEN IS NULL;
				 
			-- -------------------------------------------------------------------- --
			-- Ahora damos de BAJA a las TARIFAS por PROPORCION del artículo
			-- -------------------------------------------------------------------- --
			UPDATE articulos_proporciones_tarifas
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_articulos = NEW.id
			AND Del_WHEN IS NULL;
				 
		END;
	END IF;
	

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_articulos_familias_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_articulos_familias_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_articulos_familias_AFTER_INSERT` AFTER INSERT ON `articulos_familias` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Creamos todas las tarifas de la familia del artículo según las tarifas que 
	-- ya existen y no están dadas de baja
	-- -------------------------------------------------------------------------- --
	INSERT INTO articulos_familias_tarifas
				( id_articulos_familias,
				  id_tarifas,

				  Descuento,
				  Beneficio,

				  Insert_WHEN,
				  Insert_Id_User )

	SELECT NEW.id,
          id,

          0,
          0,

          NEW.Insert_WHEN,
          NEW.Insert_Id_User

   FROM tarifas
   WHERE Del_WHEN IS NULL;

	-- -------------------------------------------------------------------------- --
	-- Creamos todos las terminales de la familia del artículo según terminales 
	-- que ya existen y no están dadas de baja
	-- -------------------------------------------------------------------------- --
	INSERT INTO articulos_familias_terminales
	       ( id_articulos_familias,
	         id_terminales,
	         Visualizar_en_terminal_SN,
	
	         Insert_WHEN,
	         Insert_Id_User )
	
	SELECT NEW.id,
	       id,
	       'S',
	
	       NEW.Insert_WHEN,
	       NEW.Insert_Id_User
	
	FROM terminales
	WHERE Del_WHEN IS NULL;

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_articulos_familias_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_articulos_familias_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_articulos_familias_AFTER_UPDATE` AFTER UPDATE ON `articulos_familias` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Dependiendo de que sea un alta o una baja, doy de alta o doy de baja a las 
	-- tarifas y a los terminales
	-- -------------------------------------------------------------------------- --
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			-- -------------------------------------------------------------------- --
			-- Es un alta, pues anteriormente fue dada de baja
			-- -------------------------------------------------------------------- --
			-- Ahora damos de ALTA a las TARIFAS por FAMILIA DEL ARTICULO que 
			-- estuvieran dadas de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_familias_tarifas
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_articulos_familias = NEW.id
			AND NOT Del_WHEN IS NULL;
			
			-- -------------------------------------------------------------------- --
			-- Ahora damos de ALTA a los TERMINALES por FAMILIA DEL ARTICULO que 
			-- estuvieran dadas de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_familias_terminales
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_articulos_familias = NEW.id
			AND NOT Del_WHEN IS NULL;
			
		END;
	ELSE
		BEGIN
			-- -------------------------------------------------------------------- --
			-- Es una baja
			-- -------------------------------------------------------------------- --
			-- Ahora damos de BAJA a las TARIFAS por FAMILIA DEL ARTICULO
			-- -------------------------------------------------------------------- --
			UPDATE articulos_familias_tarifas
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_articulos_familias = NEW.id
			AND Del_WHEN IS NULL;
				 
			-- -------------------------------------------------------------------- --
			-- Ahora damos de BAJA a los TERMINALES por FAMILIA DEL ARTICULO
			-- -------------------------------------------------------------------- --
			UPDATE articulos_familias_terminales
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_articulos_familias = NEW.id
			AND Del_WHEN IS NULL;
				 
		END;
	END IF;
	

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_articulos_proporciones_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_articulos_proporciones_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_articulos_proporciones_AFTER_INSERT` AFTER INSERT ON `articulos_proporciones` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Creamos todas las tarifas del artículo_proporciones según las tarifas que 
	-- ya existen y  no están dadas de baja
	-- -------------------------------------------------------------------------- --
	INSERT INTO articulos_proporciones_tarifas
				( id_articulos,
				  id_articulos_proporciones,
				  id_tarifas,
				  
				  PVP,
				  PVP_Impuestos_Incluidos,

				  Insert_WHEN,
				  Insert_Id_User )

	SELECT NEW.id_articulos,
          NEW.id,
          id,
          
          0,
          0,

          NEW.Insert_WHEN,
          NEW.Insert_Id_User

   FROM tarifas
   WHERE Del_WHEN IS NULL;

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_articulos_proporciones_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_articulos_proporciones_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_articulos_proporciones_AFTER_UPDATE` AFTER UPDATE ON `articulos_proporciones` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Dependiendo de que sea un alta o una baja, doy de alta o doy de baja a las 
	-- tarifas y a los terminales
	-- -------------------------------------------------------------------------- --
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			-- -------------------------------------------------------------------- --
			-- Es un alta, pues anteriormente fue dada de baja
			-- -------------------------------------------------------------------- --
			-- Ahora damos de ALTA a las TARIFAS por PROPORCION del artículo que 
			-- estuvieran dadas de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_proporciones_tarifas
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_articulos_proporciones = NEW.id
			AND NOT Del_WHEN IS NULL;
			
		END;
	ELSE
		BEGIN
			-- -------------------------------------------------------------------- --
			-- Es una baja
			-- -------------------------------------------------------------------- --
			-- Ahora damos de BAJA a las TARIFAS por PROPORCION del artículo
			-- -------------------------------------------------------------------- --
			UPDATE articulos_proporciones_tarifas
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_articulos_proporciones = NEW.id
			AND Del_WHEN IS NULL;
				 
		END;
	END IF;
	

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_facturas_compras_detalles_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_facturas_compras_detalles_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_facturas_compras_detalles_AFTER_INSERT` AFTER INSERT ON `facturas_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales de la factura
	-- -------------------------------------------------------------------------- --
	CALL function_ACT_totales_facturas_compras( NEW.id_facturas, NEW.Insert_Id_User );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_facturas_compras_detalles_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_facturas_compras_detalles_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_facturas_compras_detalles_AFTER_UPDATE` AFTER UPDATE ON `facturas_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales de la factura
	-- -------------------------------------------------------------------------- --
	DECLARE var_id_users BIGINT;
	
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			SET var_id_users = NEW.Change_Id_User;
		END;
	ELSE
		BEGIN
			SET var_id_users = NEW.Del_Id_User;
		END;
	END IF;
	
	CALL function_ACT_totales_facturas_compras( NEW.id_facturas, var_id_users );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_facturas_compras_detalles_BEFORE_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_facturas_compras_detalles_BEFORE_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_facturas_compras_detalles_BEFORE_INSERT` BEFORE INSERT ON `facturas_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el proveedor a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	set NEW.id_almacenes = ( SELECT fc.id_almacenes 
	                         FROM facturas_compras AS fc
			  					    WHERE fc.id = NEW.id_facturas 
								    ORDER BY fc.id );
								
	SET NEW.id_proveedores = ( SELECT fc.id_proveedores 
	                           FROM facturas_compras AS fc
							         WHERE fc.id = NEW.id_facturas 
							         ORDER BY fc.id );
	
	-- ------------------------------------------------------------------------------------------------ --
	-- Tengo que comprobar que no proviene de un albarán. Solo así se actualizará el stock del artículo 
	-- desde facturas. Si proviniese de un albarán lo hará desde las líneas de detalle de los albaranes
	-- ------------------------------------------------------------------------------------------------ --
	IF NEW.Serie_Albaran IS NULL THEN
		BEGIN
			IF NOT NEW.id_articulos IS NULL THEN 
				BEGIN
					-- ------------------------------------------------------------------------------------ --
					-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
					-- ------------------------------------------------------------------------------------ --
					DECLARE var_Tipo_de_articulo VARCHAR(1);
					
					SELECT Tipo_de_articulo 
					INTO var_Tipo_de_articulo 
					FROM articulos AS art
					WHERE art.id = NEW.id_articulos; 
				    
					IF var_Tipo_de_articulo = '0' THEN 
						BEGIN
							-- ------------------------------------------------------------------------------ --
							-- Es un artículo al que tenemos que controlarle el stock               
							-- ------------------------------------------------------------------------------ --
							-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
							-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
							-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
							-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
							-- lo en la tabla articulos_stock si no existe
							-- ------------------------------------------------------------------------------ --
							IF NOT NEW.id_almacenes IS NULL AND
							   NOT NEW.Unidades IS NULL     THEN
								BEGIN
									-- ------------------------------------------------------------------------ --
									-- Es imprescindible el almacén/tienda para controlar el stock del artículo
									-- ------------------------------------------------------------------------ --
									CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
		                                                             NEW.id_almacenes );
		                                                             
									-- ------------------------------------------------------------------------ --
									-- Ahora pasamos a controlar el stock
									-- ------------------------------------------------------------------------ --
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock + NEW.Unidades
									WHERE arts.id_articulos = NEW.id_articulos
									AND arts.id_almacenes = NEW.id_almacenes;
									
								END;
							END IF;
							
						END;
					END IF;
		      
				END;
			END IF;
		      
		END;
	END IF;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_facturas_compras_detalles_BEFORE_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_facturas_compras_detalles_BEFORE_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_facturas_compras_detalles_BEFORE_UPDATE` BEFORE UPDATE ON `facturas_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el proveedor a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	set NEW.id_almacenes = ( SELECT fc.id_almacenes 
	                         FROM facturas_compras AS fc
			  					    WHERE fc.id = NEW.id_facturas 
								    ORDER BY fc.id );
								
	SET NEW.id_proveedores = ( SELECT fc.id_proveedores 
	                           FROM facturas_compras AS fc
							         WHERE fc.id = NEW.id_facturas 
							         ORDER BY fc.id );
	
	-- ------------------------------------------------------------------------------------------------ --
	-- Tengo que comprobar que no proviene de un albarán. Solo así se actualizará el stock del artículo 
	-- desde facturas. Si proviniese de un albarán lo hará desde las líneas de detalle de los albaranes
	-- ------------------------------------------------------------------------------------------------ --
	IF OLD.Serie_Albaran IS NULL THEN
		BEGIN
			-- ------------------------------------------------------------------------------------------ --
			-- Si el artículo antes de ser modificado, pertenecía a un artículo que se le controlaba el
			-- stock pues primero quitamos del stock el valor de OLD.Unidades que tuviera anteriormente   
			-- ------------------------------------------------------------------------------------------ --
			IF NOT OLD.id_articulos IS NULL THEN 
				BEGIN
					-- ------------------------------------------------------------------------------------ --
					-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
					-- ------------------------------------------------------------------------------------ --
					DECLARE var_Tipo_de_articulo VARCHAR(1);
					
					SELECT Tipo_de_articulo 
					INTO var_Tipo_de_articulo 
					FROM articulos AS art
					WHERE art.id = OLD.id_articulos; 
				    
					IF var_Tipo_de_articulo = '0' THEN 
						BEGIN
							-- ------------------------------------------------------------------------------ --
							-- Es un artículo al que tenemos que controlarle el stock               
							-- ------------------------------------------------------------------------------ --
							-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
							-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
							-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
							-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
							-- lo en la tabla articulos_stock si no existe
							-- ------------------------------------------------------------------------------ --
							IF NOT OLD.id_almacenes IS NULL AND
							   NOT OLD.Unidades IS NULL     THEN
								BEGIN
									-- ------------------------------------------------------------------------ --
									-- Es imprescindible el almacén/tienda para controlar el stock del artículo
									-- ------------------------------------------------------------------------ --
									CALL function_Articulos_Crear_en_Stock( OLD.id_articulos,
		                                                             OLD.id_almacenes );
		                                                             
									-- ------------------------------------------------------------------------ --
									-- Ahora pasamos a controlar el stock
									-- ------------------------------------------------------------------------ --
									IF OLD.Del_WHEN IS NULL THEN
										BEGIN
											UPDATE articulos_stock AS arts
											SET arts.Stock = arts.Stock - OLD.Unidades
											WHERE arts.id_articulos = OLD.id_articulos
											AND arts.id_almacenes = OLD.id_almacenes;
										END;
									END IF;
									
								END;
							END IF;
							
						END;
					END IF;
		      
				END;
			END IF;
		      
		END;
	END IF;
			
	-- ------------------------------------------------------------------------------------------------ --
	-- Tengo que comprobar que no proviene de un albarán. Solo así se actualizará el stock del artículo 
	-- desde facturas. Si proviniese de un albarán lo hará desde las líneas de detalle de los albaranes
	-- ------------------------------------------------------------------------------------------------ --
	IF NEW.Serie_Albaran IS NULL THEN
		BEGIN
			-- ------------------------------------------------------------------------------------------ --
			-- Si el artículo después de ser modificado, pertenece a un artículo que se le controla el
			-- stock pues primero quitamos del stock el valor de NEW.Unidades            
			-- ------------------------------------------------------------------------------------------ --
			IF NOT NEW.id_articulos IS NULL THEN 
				BEGIN
					-- ------------------------------------------------------------------------------------ --
					-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
					-- ------------------------------------------------------------------------------------ --
					DECLARE var_Tipo_de_articulo VARCHAR(1);
					
					SELECT Tipo_de_articulo 
					INTO var_Tipo_de_articulo 
					FROM articulos AS art
					WHERE art.id = NEW.id_articulos; 
				    
					IF var_Tipo_de_articulo = '0' THEN 
						BEGIN
							-- ------------------------------------------------------------------------------ --
							-- Es un artículo al que tenemos que controlarle el stock               
							-- ------------------------------------------------------------------------------ --
							-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
							-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
							-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
							-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
							-- lo en la tabla articulos_stock si no existe
							-- ------------------------------------------------------------------------------ --
							IF NOT NEW.id_almacenes IS NULL AND
							   NOT NEW.Unidades IS NULL     THEN
								BEGIN
									-- ------------------------------------------------------------------------ --
									-- Es imprescindible el almacén/tienda para controlar el stock del artículo
									-- ------------------------------------------------------------------------ --
									CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
		                                                             NEW.id_almacenes );
		                                                             
									-- ------------------------------------------------------------------------ --
									-- Ahora pasamos a controlar el stock
									-- ------------------------------------------------------------------------ --
									IF NEW.Del_WHEN IS NULL THEN
										BEGIN
											UPDATE articulos_stock AS arts
											SET arts.Stock = arts.Stock + NEW.Unidades
											WHERE arts.id_articulos = NEW.id_articulos
											AND arts.id_almacenes = NEW.id_almacenes;
										END;
									END IF;
									
								END;
							END IF;
							
						END;
					END IF;
		      
				END;
			END IF;
				      
		END;
	END IF;
			
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_facturas_ventas_detalles_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_facturas_ventas_detalles_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_facturas_ventas_detalles_AFTER_INSERT` AFTER INSERT ON `facturas_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales de la factura
	-- -------------------------------------------------------------------------- --
	CALL function_ACT_totales_facturas_ventas( NEW.id_facturas, NEW.Insert_Id_User );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_facturas_ventas_detalles_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_facturas_ventas_detalles_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_facturas_ventas_detalles_AFTER_UPDATE` AFTER UPDATE ON `facturas_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales de la factura
	-- -------------------------------------------------------------------------- --
	DECLARE var_id_users BIGINT;
	
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			SET var_id_users = NEW.Change_Id_User;
		END;
	ELSE
		BEGIN
			SET var_id_users = NEW.Del_Id_User;
		END;
	END IF;
	
	CALL function_ACT_totales_facturas_ventas( NEW.id_facturas, var_id_users );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_facturas_ventas_detalles_BEFORE_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_facturas_ventas_detalles_BEFORE_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_facturas_ventas_detalles_BEFORE_INSERT` BEFORE INSERT ON `facturas_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el cliente a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	set NEW.id_almacenes = ( SELECT fv.id_almacenes 
	                         FROM facturas_ventas AS fv
			  					    WHERE fv.id = NEW.id_facturas 
								    ORDER BY fv.id );
								
	SET NEW.id_clientes = ( SELECT fv.id_clientes 
	                        FROM facturas_ventas AS fv
							      WHERE fv.id = NEW.id_facturas 
							      ORDER BY fv.id );
	
	-- ------------------------------------------------------------------------------------------------ --
	-- Tengo que comprobar que no proviene de un albarán. Solo así se actualizará el stock del artículo 
	-- desde facturas. Si proviniese de un albarán lo hará desde las líneas de detalle de los albaranes
	-- ------------------------------------------------------------------------------------------------ --
	IF NEW.Serie_Albaran IS NULL THEN
		BEGIN
			IF NOT NEW.id_articulos IS NULL THEN 
				BEGIN
					-- ------------------------------------------------------------------------------------ --
					-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
					-- ------------------------------------------------------------------------------------ --
					DECLARE var_Tipo_de_articulo VARCHAR(1);
					
					SELECT Tipo_de_articulo 
					INTO var_Tipo_de_articulo 
					FROM articulos AS art
					WHERE art.id = NEW.id_articulos; 
				    
					IF var_Tipo_de_articulo = '0' THEN 
						BEGIN
							-- ------------------------------------------------------------------------------ --
							-- Es un artículo al que tenemos que controlarle el stock               
							-- ------------------------------------------------------------------------------ --
							-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
							-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
							-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
							-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
							-- lo en la tabla articulos_stock si no existe
							-- ------------------------------------------------------------------------------ --
							IF NOT NEW.id_almacenes IS NULL AND
							   NOT NEW.Unidades IS NULL     THEN
								BEGIN
									-- ------------------------------------------------------------------------ --
									-- Es imprescindible el almacén/tienda para controlar el stock del artículo
									-- ------------------------------------------------------------------------ --
									CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
		                                                             NEW.id_almacenes );
		                                                             
									-- ------------------------------------------------------------------------ --
									-- Ahora pasamos a controlar el stock
									-- ------------------------------------------------------------------------ --
									UPDATE articulos_stock AS arts
									SET arts.Stock = arts.Stock - NEW.Unidades
									WHERE arts.id_articulos = NEW.id_articulos
									AND arts.id_almacenes = NEW.id_almacenes;
									
								END;
							END IF;
							
						END;
					END IF;
		      
				END;
			END IF;
		      
		END;
	END IF;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_facturas_ventas_detalles_BEFORE_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_facturas_ventas_detalles_BEFORE_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_facturas_ventas_detalles_BEFORE_UPDATE` BEFORE UPDATE ON `facturas_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el cliente a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	set NEW.id_almacenes = ( SELECT fv.id_almacenes 
	                         FROM facturas_ventas AS fv
			  					    WHERE fv.id = NEW.id_facturas 
								    ORDER BY fv.id );
								
	SET NEW.id_clientes = ( SELECT fv.id_clientes 
	                        FROM facturas_ventas AS fv
							      WHERE fv.id = NEW.id_facturas 
							      ORDER BY fv.id );
	
	-- ------------------------------------------------------------------------------------------------ --
	-- Tengo que comprobar que no proviene de un albarán. Solo así se actualizará el stock del artículo 
	-- desde facturas. Si proviniese de un albarán lo hará desde las líneas de detalle de los albaranes
	-- ------------------------------------------------------------------------------------------------ --
	IF OLD.Serie_Albaran IS NULL THEN
		BEGIN
			-- ------------------------------------------------------------------------------------------ --
			-- Si el artículo antes de ser modificado, pertenecía a un artículo que se le controlaba el
			-- stock pues primero quitamos del stock el valor de OLD.Unidades que tuviera anteriormente   
			-- ------------------------------------------------------------------------------------------ --
			IF NOT OLD.id_articulos IS NULL THEN 
				BEGIN
					-- ------------------------------------------------------------------------------------ --
					-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
					-- ------------------------------------------------------------------------------------ --
					DECLARE var_Tipo_de_articulo VARCHAR(1);
					
					SELECT Tipo_de_articulo 
					INTO var_Tipo_de_articulo 
					FROM articulos AS art
					WHERE art.id = OLD.id_articulos; 
				    
					IF var_Tipo_de_articulo = '0' THEN 
						BEGIN
							-- ------------------------------------------------------------------------------ --
							-- Es un artículo al que tenemos que controlarle el stock               
							-- ------------------------------------------------------------------------------ --
							-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
							-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
							-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
							-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
							-- lo en la tabla articulos_stock si no existe
							-- ------------------------------------------------------------------------------ --
							IF NOT OLD.id_almacenes IS NULL AND
							   NOT OLD.Unidades IS NULL     THEN
								BEGIN
									-- ------------------------------------------------------------------------ --
									-- Es imprescindible el almacén/tienda para controlar el stock del artículo
									-- ------------------------------------------------------------------------ --
									CALL function_Articulos_Crear_en_Stock( OLD.id_articulos,
		                                                             OLD.id_almacenes );
		                                                             
									-- ------------------------------------------------------------------------ --
									-- Ahora pasamos a controlar el stock
									-- ------------------------------------------------------------------------ --
									IF OLD.Del_WHEN IS NULL THEN
										BEGIN
											UPDATE articulos_stock AS arts
											SET arts.Stock = arts.Stock + OLD.Unidades
											WHERE arts.id_articulos = OLD.id_articulos
											AND arts.id_almacenes = OLD.id_almacenes;
										END;
									END IF;
									
								END;
							END IF;
							
						END;
					END IF;
		      
				END;
			END IF;
		      
		END;
	END IF;
			
	-- ------------------------------------------------------------------------------------------------ --
	-- Tengo que comprobar que no proviene de un albarán. Solo así se actualizará el stock del artículo 
	-- desde facturas. Si proviniese de un albarán lo hará desde las líneas de detalle de los albaranes
	-- ------------------------------------------------------------------------------------------------ --
	IF NEW.Serie_Albaran IS NULL THEN
		BEGIN
			-- ------------------------------------------------------------------------------------------ --
			-- Si el artículo después de ser modificado, pertenece a un artículo que se le controla el
			-- stock pues primero quitamos del stock el valor de NEW.Unidades            
			-- ------------------------------------------------------------------------------------------ --
			IF NOT NEW.id_articulos IS NULL THEN 
				BEGIN
					-- ------------------------------------------------------------------------------------ --
					-- Es un artículo, así que vamos a comprobar si se le tiene que controlar o no el stock
					-- ------------------------------------------------------------------------------------ --
					DECLARE var_Tipo_de_articulo VARCHAR(1);
					
					SELECT Tipo_de_articulo 
					INTO var_Tipo_de_articulo 
					FROM articulos AS art
					WHERE art.id = NEW.id_articulos; 
				    
					IF var_Tipo_de_articulo = '0' THEN 
						BEGIN
							-- ------------------------------------------------------------------------------ --
							-- Es un artículo al que tenemos que controlarle el stock               
							-- ------------------------------------------------------------------------------ --
							-- Lo primero que tenemos que controlar es ver si el artículo ya está creado para 
							-- controlar su stock por almacén. Pero claro necesito que el almacén se hubiera 
							-- introducido y por supuesto también el artículo. Pero si es un artículo ya lo 
							-- controlo más arriba. Así que si se ha introducido el almacén pues voy a crear
							-- lo en la tabla articulos_stock si no existe
							-- ------------------------------------------------------------------------------ --
							IF NOT NEW.id_almacenes IS NULL AND
							   NOT NEW.Unidades IS NULL     THEN
								BEGIN
									-- ------------------------------------------------------------------------ --
									-- Es imprescindible el almacén/tienda para controlar el stock del artículo
									-- ------------------------------------------------------------------------ --
									CALL function_Articulos_Crear_en_Stock( NEW.id_articulos,
		                                                             NEW.id_almacenes );
		                                                             
									-- ------------------------------------------------------------------------ --
									-- Ahora pasamos a controlar el stock
									-- ------------------------------------------------------------------------ --
									IF NEW.Del_WHEN IS NULL THEN
										BEGIN
											UPDATE articulos_stock AS arts
											SET arts.Stock = arts.Stock - NEW.Unidades
											WHERE arts.id_articulos = NEW.id_articulos
											AND arts.id_almacenes = NEW.id_almacenes;
										END;
									END IF;
									
								END;
							END IF;
							
						END;
					END IF;
		      
				END;
			END IF;
				      
		END;
	END IF;
	
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_pedidos_compras_detalles_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_pedidos_compras_detalles_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_pedidos_compras_detalles_AFTER_INSERT` AFTER INSERT ON `pedidos_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del PEDIDO
	-- -------------------------------------------------------------------------- --
	CALL function_ACT_totales_pedidos_compras( NEW.id_pedidos, NEW.Insert_Id_User );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_pedidos_compras_detalles_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_pedidos_compras_detalles_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_pedidos_compras_detalles_AFTER_UPDATE` AFTER UPDATE ON `pedidos_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del PEDIDO
	-- -------------------------------------------------------------------------- --
	DECLARE var_id_users BIGINT;
	
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			SET var_id_users = NEW.Change_Id_User;
		END;
	ELSE
		BEGIN
			SET var_id_users = NEW.Del_Id_User;
		END;
	END IF;
	
	CALL function_ACT_totales_pedidos_compras( NEW.id_pedidos, var_id_users );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_pedidos_compras_detalles_BEFORE_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_pedidos_compras_detalles_BEFORE_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_pedidos_compras_detalles_BEFORE_INSERT` BEFORE INSERT ON `pedidos_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el proveedor a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes = ( SELECT id_almacenes 
	                         FROM pedidos_compras
			  					    WHERE id = NEW.id_pedidos
								    ORDER BY id );
								
	SET NEW.id_proveedores = ( SELECT id_proveedores 
	                           FROM pedidos_compras
							         WHERE id = NEW.id_pedidos
							         ORDER BY id );
	
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_pedidos_compras_detalles_BEFORE_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_pedidos_compras_detalles_BEFORE_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_pedidos_compras_detalles_BEFORE_UPDATE` BEFORE UPDATE ON `pedidos_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el proveedor a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes = ( SELECT id_almacenes 
	                         FROM pedidos_compras
			  					    WHERE id = NEW.id_pedidos
								    ORDER BY id );
								
	SET NEW.id_proveedores = ( SELECT id_proveedores 
	                           FROM pedidos_compras
							         WHERE id = NEW.id_pedidos
							         ORDER BY id );
	
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_pedidos_ventas_detalles_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_pedidos_ventas_detalles_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_pedidos_ventas_detalles_AFTER_INSERT` AFTER INSERT ON `pedidos_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del PEDIDOD
	-- -------------------------------------------------------------------------- --
	CALL function_ACT_totales_pedidos_ventas( NEW.id_pedidos, NEW.Insert_Id_User );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_pedidos_ventas_detalles_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_pedidos_ventas_detalles_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_pedidos_ventas_detalles_AFTER_UPDATE` AFTER UPDATE ON `pedidos_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales deL PEDIDO
	-- -------------------------------------------------------------------------- --
	DECLARE var_id_users BIGINT;
	
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			SET var_id_users = NEW.Change_Id_User;
		END;
	ELSE
		BEGIN
			SET var_id_users = NEW.Del_Id_User;
		END;
	END IF;
	 
	CALL function_ACT_totales_pedidos_ventas( NEW.id_pedidos, var_id_users );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_pedidos_ventas_detalles_BEFORE_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_pedidos_ventas_detalles_BEFORE_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_pedidos_ventas_detalles_BEFORE_INSERT` BEFORE INSERT ON `pedidos_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el CLIENTE a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes = ( SELECT id_almacenes 
	                         FROM pedidos_ventas
			  					    WHERE id = NEW.id_pedidos
								    ORDER BY id );
								
	SET NEW.id_clientes = ( SELECT id_clientes 
                           FROM pedidos_ventas
						         WHERE id = NEW.id_pedidos
						         ORDER BY id );
	
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_pedidos_ventas_detalles_BEFORE_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_pedidos_ventas_detalles_BEFORE_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_pedidos_ventas_detalles_BEFORE_UPDATE` BEFORE UPDATE ON `pedidos_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el CLIENTE a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes = ( SELECT id_almacenes 
	                         FROM pedidos_ventas
			  					    WHERE id = NEW.id_pedidos
								    ORDER BY id );
								
	SET NEW.id_clientes = ( SELECT id_clientes 
                           FROM pedidos_ventas
						         WHERE id = NEW.id_pedidos
						         ORDER BY id );
	
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_presupuestos_compras_detalles_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_presupuestos_compras_detalles_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_presupuestos_compras_detalles_AFTER_INSERT` AFTER INSERT ON `presupuestos_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del PRESUPUESTO
	-- -------------------------------------------------------------------------- --
	CALL function_ACT_totales_presupuestos_compras( NEW.id_presupuestos, NEW.Insert_Id_User );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_presupuestos_compras_detalles_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_presupuestos_compras_detalles_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_presupuestos_compras_detalles_AFTER_UPDATE` AFTER UPDATE ON `presupuestos_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del PRESUPUESTO
	-- -------------------------------------------------------------------------- --
	DECLARE var_id_users BIGINT;
	
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			SET var_id_users = NEW.Change_Id_User;
		END;
	ELSE
		BEGIN
			SET var_id_users = NEW.Del_Id_User;
		END;
	END IF;
	
	CALL function_ACT_totales_presupuestos_compras( NEW.id_presupuestos, var_id_users );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_presupuestos_compras_detalles_BEFORE_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_presupuestos_compras_detalles_BEFORE_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_presupuestos_compras_detalles_BEFORE_INSERT` BEFORE INSERT ON `presupuestos_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el proveedor a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes = ( SELECT id_almacenes 
	                         FROM presupuestos_compras
			  					    WHERE id = NEW.id_presupuestos
								    ORDER BY id );
								
	SET NEW.id_proveedores = ( SELECT id_proveedores 
	                           FROM presupuestos_compras
							         WHERE id = NEW.id_presupuestos
							         ORDER BY id );
	
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_presupuestos_compras_detalles_BEFORE_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_presupuestos_compras_detalles_BEFORE_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_presupuestos_compras_detalles_BEFORE_UPDATE` BEFORE UPDATE ON `presupuestos_compras_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el proveedor a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes = ( SELECT id_almacenes 
	                         FROM presupuestos_compras
			  					    WHERE id = NEW.id_presupuestos
								    ORDER BY id );
								
	SET NEW.id_proveedores = ( SELECT id_proveedores 
	                           FROM presupuestos_compras
							         WHERE id = NEW.id_presupuestos
							         ORDER BY id );
	
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_presupuestos_ventas_detalles_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_presupuestos_ventas_detalles_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_presupuestos_ventas_detalles_AFTER_INSERT` AFTER INSERT ON `presupuestos_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del PRESUPUESTO
	-- -------------------------------------------------------------------------- --
	CALL function_ACT_totales_presupuestos_ventas( NEW.id_presupuestos, NEW.Insert_Id_User );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_presupuestos_ventas_detalles_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_presupuestos_ventas_detalles_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_presupuestos_ventas_detalles_AFTER_UPDATE` AFTER UPDATE ON `presupuestos_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos los totales del presupuesto
	-- -------------------------------------------------------------------------- --
	DECLARE var_id_users BIGINT;
	
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			SET var_id_users = NEW.Change_Id_User;
		END;
	ELSE
		BEGIN
			SET var_id_users = NEW.Del_Id_User;
		END;
	END IF;
	
	CALL function_ACT_totales_presupuestos_ventas( NEW.id_presupuestos, var_id_users );
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_presupuestos_ventas_detalles_BEFORE_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_presupuestos_ventas_detalles_BEFORE_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_presupuestos_ventas_detalles_BEFORE_INSERT` BEFORE INSERT ON `presupuestos_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el CLIENTE a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes = ( SELECT id_almacenes 
	                         FROM presupuestos_ventas
			  					    WHERE id = NEW.id_presupuestos
								    ORDER BY id );
								
	SET NEW.id_clientes = ( SELECT id_clientes 
                           FROM presupuestos_ventas
						         WHERE id = NEW.id_presupuestos
						         ORDER BY id );
	
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_presupuestos_ventas_detalles_BEFORE_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_presupuestos_ventas_detalles_BEFORE_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_presupuestos_ventas_detalles_BEFORE_UPDATE` BEFORE UPDATE ON `presupuestos_ventas_detalles` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Actualizamos el almacen y el CLIENTE a las líneas de detalle por si en 
	-- la cabecera  se han cambiado
	-- -------------------------------------------------------------------------- --
	SET NEW.id_almacenes = ( SELECT id_almacenes 
	                         FROM presupuestos_ventas
			  					    WHERE id = NEW.id_presupuestos
								    ORDER BY id );
								
	SET NEW.id_clientes = ( SELECT id_clientes 
                           FROM presupuestos_ventas
						         WHERE id = NEW.id_presupuestos
						         ORDER BY id );
	
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_terminales_AFTER_INSERT
DROP TRIGGER IF EXISTS `TRIGGER_terminales_AFTER_INSERT`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_terminales_AFTER_INSERT` AFTER INSERT ON `terminales` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Creamos terminal a ARTICULOS_FAMILIAS
	-- -------------------------------------------------------------------------- --
	INSERT INTO articulos_familias_terminales
				( id_articulos_familias,
				  id_terminales,
				  Visualizar_en_terminal_SN,

				  Insert_WHEN,
				  Insert_Id_User )

	SELECT id,
          NEW.id,
	       'S',

          NEW.Insert_WHEN,
          NEW.Insert_Id_User

   FROM articulos_familias;
   -- esta linea siguiente la quito para que se inserte también en las dadas de baja
   -- WHERE Del_WHEN IS NULL;

	-- -------------------------------------------------------------------------- --
	-- Creamos terminal a ARTICULOS
	-- -------------------------------------------------------------------------- --
	INSERT INTO articulos_terminales
	       ( id_articulos,
	         id_terminales,
	         Visualizar_en_terminal_SN,
	
	         Insert_WHEN,
	         Insert_Id_User )
	
	SELECT id,
	       NEW.id,
	       'S',
	
	       NEW.Insert_WHEN,
	       NEW.Insert_Id_User
	
	FROM articulos;
   -- esta linea siguiente la quito para que se inserte también en las dadas de baja
   -- WHERE Del_WHEN IS NULL;

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;


-- Volcando estructura para disparador socger.TRIGGER_terminales_AFTER_UPDATE
DROP TRIGGER IF EXISTS `TRIGGER_terminales_AFTER_UPDATE`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `TRIGGER_terminales_AFTER_UPDATE` AFTER UPDATE ON `terminales` FOR EACH ROW BEGIN
	-- -------------------------------------------------------------------------- --
	-- Dependiendo de que sea un alta o una baja, doy de alta o doy de baja a las 
	-- tarifas y a los terminales
	-- -------------------------------------------------------------------------- --
	IF NEW.Del_Id_User IS NULL THEN
		BEGIN
			-- -------------------------------------------------------------------- --
			-- Es un alta, pues anteriormente fue dada de baja
			-- -------------------------------------------------------------------- --
			-- Ahora damos de ALTA el TERMINAL en todas las FAMILIAS DE ARTICULOS
			-- que estuvieran dadas de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_familias_terminales
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_terminales = NEW.id
			AND NOT Del_WHEN IS NULL;
			
			-- -------------------------------------------------------------------- --
			-- Ahora damos de ALTA el TERMINAL en todos los ARTICULOS que 
			-- estuvieran dadas de baja
			-- -------------------------------------------------------------------- --
			UPDATE articulos_terminales
			SET Del_WHEN = NULL,
				 Del_Id_User = NULL,
				 Del_WHY = NULL
			WHERE id_terminales = NEW.id
			AND NOT Del_WHEN IS NULL;
			
		END;
	ELSE
		BEGIN
			-- -------------------------------------------------------------------- --
			-- Es una baja
			-- -------------------------------------------------------------------- --
			-- Ahora damos de BAJA el TERMINAL en todas las FAMILIAS DE ARTICULOS
			-- -------------------------------------------------------------------- --
			UPDATE articulos_familias_terminales
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_terminales = NEW.id
			AND Del_WHEN IS NULL;
				 
			-- -------------------------------------------------------------------- --
			-- Ahora damos de BAJA a los TERMINALES por FAMILIA DEL ARTICULO
			-- -------------------------------------------------------------------- --
			UPDATE articulos_terminales
			SET Del_WHEN = NEW.Insert_WHEN,
				 Del_Id_User = NEW.Insert_Id_User,
				 Del_WHY = NEW.Del_WHY
			WHERE id_terminales = NEW.id
			AND Del_WHEN IS NULL;
				 
		END;
	END IF;
	

END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
