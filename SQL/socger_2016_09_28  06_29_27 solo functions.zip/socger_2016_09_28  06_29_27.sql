-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.6.28-log - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando estructura de base de datos para socger
DROP DATABASE IF EXISTS `socger`;
CREATE DATABASE IF NOT EXISTS `socger` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci */;
USE `socger`;


-- Volcando estructura para procedimiento socger.function_ACT_totales_albaranes_compras
DROP PROCEDURE IF EXISTS `function_ACT_totales_albaranes_compras`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_albaranes_compras`(IN `param_id_albaranes` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_albaranes <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM albaranes_compras_impuestos
				WHERE id_albaranes = param_id_albaranes 
				ORDER BY id_albaranes ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO albaranes_compras_impuestos
				          ( id_albaranes,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_albaranes,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM albaranes_compras_detalles  
				                         WHERE id_albaranes = param_id_albaranes 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN albaranes_compras_detalles AS f_c_d
				                ON f_c_d.id_albaranes = param_id_albaranes AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_Compras
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM albaranes_compras_impuestos
				                  WHERE id_albaranes = param_id_albaranes
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_albaranes ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO albaranes_compras_impuestos
				          ( id_albaranes,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_albaranes,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM albaranes_compras_detalles  
				                         WHERE id_albaranes = param_id_albaranes 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN albaranes_compras_detalles AS f_c_d
				                ON f_c_d.id_albaranes = param_id_albaranes AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_Compras
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en albaranes_compras_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM albaranes_compras_impuestos
				                  WHERE id_albaranes = param_id_albaranes
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_albaranes ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE albaranes_compras_impuestos
				SET albaranes_compras_impuestos.Importe = ( albaranes_compras_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = albaranes_compras_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE albaranes_compras_impuestos.id_albaranes = param_id_albaranes;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE albaranes_compras

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM albaranes_compras_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_albaranes = param_id_albaranes 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM albaranes_compras_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_albaranes = param_id_albaranes 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM albaranes_compras_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_albaranes = param_id_albaranes 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM albaranes_compras_detalles AS f_c_d
 				                     WHERE f_c_d.id_albaranes = param_id_albaranes 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
			                     (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                            FROM albaranes_compras_impuestos AS f_c_i
                                            LEFT JOIN impuestos AS i
										              ON i.id = f_c_i.id_impuestos 
 				                                WHERE f_c_i.id_albaranes = param_id_albaranes 
										              AND f_c_i.Del_WHEN IS NULL 
										              AND i.Sumado_A_Ftra_SN = 'S' ), 0)
											 -
											 IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                FROM albaranes_compras_impuestos AS f_c_i
                                            LEFT JOIN impuestos AS i
													     ON i.id = f_c_i.id_impuestos
 				                                WHERE f_c_i.id_albaranes = param_id_albaranes 
										              AND f_c_i.Del_WHEN IS NULL 
													     AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )

				WHERE id = param_id_albaranes;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_albaranes_ventas
DROP PROCEDURE IF EXISTS `function_ACT_totales_albaranes_ventas`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_albaranes_ventas`(IN `param_id_albaranes` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_albaranes <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM albaranes_ventas_impuestos
				WHERE id_albaranes = param_id_albaranes 
				ORDER BY id_albaranes ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO albaranes_ventas_impuestos
				          ( id_albaranes,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_albaranes,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM albaranes_ventas_detalles  
				                         WHERE id_albaranes = param_id_albaranes 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN albaranes_ventas_detalles AS f_c_d
				                ON f_c_d.id_albaranes = param_id_albaranes AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_ventas
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM albaranes_ventas_impuestos
				                  WHERE id_albaranes = param_id_albaranes
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_albaranes ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO albaranes_ventas_impuestos
				          ( id_albaranes,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_albaranes,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM albaranes_ventas_detalles  
				                         WHERE id_albaranes = param_id_albaranes 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN albaranes_ventas_detalles AS f_c_d
				                ON f_c_d.id_albaranes = param_id_albaranes AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_ventas
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en albaranes_ventas_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM albaranes_ventas_impuestos
				                  WHERE id_albaranes = param_id_albaranes
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_albaranes ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE albaranes_ventas_impuestos
				SET albaranes_ventas_impuestos.Importe = ( albaranes_ventas_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = albaranes_ventas_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE albaranes_ventas_impuestos.id_albaranes = param_id_albaranes;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE albaranes_ventas

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM albaranes_ventas_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_albaranes = param_id_albaranes 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM albaranes_ventas_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_albaranes = param_id_albaranes 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM albaranes_ventas_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_albaranes = param_id_albaranes 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM albaranes_ventas_detalles AS f_c_d
 				                     WHERE f_c_d.id_albaranes = param_id_albaranes 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM albaranes_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_albaranes = param_id_albaranes 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM albaranes_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_albaranes = param_id_albaranes 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   
				WHERE id = param_id_albaranes;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_facturas_compras
DROP PROCEDURE IF EXISTS `function_ACT_totales_facturas_compras`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_facturas_compras`(IN `param_id_facturas` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- Si la factura está cerrada, pues no se actualiza nada
    -- ----------------------------------------------------------------------------------------------------------------- --
	 IF NOT EXISTS( SELECT fco.*
                   FROM facturas_compras AS fco
                   RIGHT JOIN facturas_cerradas AS fce
                   ON fce.id_empresas = fco.id_empresas AND
                      fco.Fecha >= fce.Desde AND
                      fco.Fecha <= fce.Hasta AND
                      fce.Del_WHEN IS NULL AND
                      fce.Tipo_Ventas_o_Compras_VC = 'C'
                   WHERE fco.id = param_id_facturas
                   ORDER BY fco.id ) THEN
        BEGIN
			    -- ----------------------------------------------------------------------------------------------------------------- --
			    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
			    -- ----------------------------------------------------------------------------------------------------------------- --
			    IF param_id_facturas <> 0 THEN
			        BEGIN
							-- --------------------------------------------------------------------------------------------------------- --
							-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
							-- --------------------------------------------------------------------------------------------------------- --
			        		DELETE FROM facturas_compras_impuestos
							WHERE id_facturas = param_id_facturas 
							ORDER BY id_facturas ASC, id_impuestos ASC;
							
							-- --------------------------------------------------------------------------------------------------------- --
							-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
							-- ENGLOBAN. PERO SOLO SI NO EXISTEN
							-- --------------------------------------------------------------------------------------------------------- --
							INSERT INTO facturas_compras_impuestos
							          ( id_facturas,
							            Base,
							            Importe,
							            Insert_Id_User,
							            Insert_WHEN, 
							            id_impuestos )
							
							SELECT * FROM ( SELECT param_id_facturas,
							
														  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
														                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(Unidades, 1) * PVP) -
														                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
														    FROM facturas_compras_detalles  
							                         WHERE id_facturas = param_id_facturas 
														    AND Del_WHEN IS NULL
														    AND Excluido_su_Cobro_SN <> 'S'
														    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) AS a,
							                     
							                     0 as b,
							                     
							                     param_id_users,
							                     NOW(),
							                     
							                     i_p.id_impuestos
							                     
							                FROM impuestos_composiciones AS i_p
							              
							                RIGHT JOIN facturas_compras_detalles AS f_c_d
							                ON f_c_d.id_facturas = param_id_facturas AND
							                   f_c_d.Del_WHEN IS NULL
							              
							              
							                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_Compras
							                AND i_p.Del_WHEN IS NULL
							                GROUP BY i_p.id_impuestos
							                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
							              ) AS tmp
							
							WHERE NOT EXISTS ( SELECT *
							                  FROM facturas_compras_impuestos
							                  WHERE id_facturas = param_id_facturas
							                  AND id_impuestos = tmp.id_impuestos
							                  ORDER BY id_facturas ASC, id_impuestos ASC 
							                );
							                
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
							-- NO EXISTEN
							-- --------------------------------------------------------------------------------------------------------- --
							INSERT INTO facturas_compras_impuestos
							          ( id_facturas,
							            Base,
							            Importe,
							            Insert_Id_User,
							            Insert_WHEN, 
							            id_impuestos )
							
							SELECT * FROM ( SELECT param_id_facturas,
							
														  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
														                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(Unidades, 1) * PVP) -
														                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
														    FROM facturas_compras_detalles  
							                         WHERE id_facturas = param_id_facturas 
														    AND Del_WHEN IS NULL
														    AND Excluido_su_Cobro_SN <> 'S'
														    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) as a,
							                     
							                     0 as b,
							                     
							                     param_id_users,
							                     NOW(),
							                     
							                     i.id
							                     
							                FROM impuestos AS i
							              
							                RIGHT JOIN facturas_compras_detalles AS f_c_d
							                ON f_c_d.id_facturas = param_id_facturas AND
							                   f_c_d.Del_WHEN IS NULL
							              
							              
							                WHERE i.id = f_c_d.id_impuestos_Compras
							                AND NOT i.Tanto_Por_Ciento IS NULL
							                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en facturas_compras_detalles
							                GROUP BY i.id
							                ORDER BY i.id ASC
							              ) AS tmp
							
							WHERE NOT EXISTS ( SELECT *
							                  FROM facturas_compras_impuestos
							                  WHERE id_facturas = param_id_facturas
							                  AND id_impuestos = tmp.id
							                  ORDER BY id_facturas ASC, id_impuestos ASC 
							                );
			
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
							-- DETALLE DE LA FACTURA
							-- --------------------------------------------------------------------------------------------------------- --
							UPDATE facturas_compras_impuestos
							SET facturas_compras_impuestos.Importe = ( facturas_compras_impuestos.Base * 
							                                           ( SELECT Tanto_Por_Ciento 
							                									   FROM impuestos
							                									   WHERE impuestos.id = facturas_compras_impuestos.id_impuestos ) )
							                								  / 100	   
							WHERE facturas_compras_impuestos.id_facturas = param_id_facturas;
			
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
							-- DETALLE DE LA FACTURA
							-- --------------------------------------------------------------------------------------------------------- --
							UPDATE facturas_compras
			
							SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                        FROM facturas_compras_detalles AS f_c_d
							                        
							                        RIGHT JOIN articulos AS a
							                        ON a.id = f_c_d.id_articulos AND
							                           a.Tipo_de_articulo = 2
							                        
			 				                        WHERE f_c_d.id_facturas = param_id_facturas 
			 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
														   AND f_c_d.Del_WHEN IS NULL ),
														    
			 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                         FROM facturas_compras_detalles AS f_c_d
							                        
							                         RIGHT JOIN articulos AS a
							                         ON a.id = f_c_d.id_articulos AND
							                            a.Tipo_de_articulo = 0
							                        
			 				                         WHERE f_c_d.id_facturas = param_id_facturas 
			 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
														    AND f_c_d.Del_WHEN IS NULL ),
														   
								 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                    FROM facturas_compras_detalles AS f_c_d
							                        
							                    RIGHT JOIN articulos AS a
							                    ON a.id = f_c_d.id_articulos AND
							                       (  ( a.Tipo_de_articulo <> 0 AND
							                            a.Tipo_de_articulo <> 2 )
																 OR 
															  ( a.Tipo_de_articulo IS NULL ) ) 	 
							                        
			 				                    WHERE f_c_d.id_facturas = param_id_facturas 
			 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
													  AND f_c_d.Del_WHEN IS NULL ),
														   
								 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
			                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
			                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
			                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
			                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                     FROM facturas_compras_detalles AS f_c_d
			 				                     WHERE f_c_d.id_facturas = param_id_facturas 
			 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
													   AND f_c_d.Del_WHEN IS NULL ),
														   
			 					 Total_Total = Total_Lineas + 
								                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM facturas_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_facturas = param_id_facturas 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM facturas_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_facturas = param_id_facturas 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
														   

							WHERE id = param_id_facturas;
							
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA VAMOS A CREAR SUS VENCIMIENTOS/RECIBOS (CARTERA)
							-- --------------------------------------------------------------------------------------------------------- --
							CALL function_Recibos_Crear_a_Ftra( 'P', param_id_facturas, param_id_users );
										
			        END;
			    END IF;	
			    
			    
        END;
	 END IF;

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_facturas_ventas
DROP PROCEDURE IF EXISTS `function_ACT_totales_facturas_ventas`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_facturas_ventas`(IN `param_id_facturas` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- Si la factura está cerrada, pues no se actualiza nada
    -- ----------------------------------------------------------------------------------------------------------------- --
	 IF NOT EXISTS( SELECT fco.*
                   FROM facturas_ventas AS fco
                   RIGHT JOIN facturas_cerradas AS fce
                   ON fce.id_empresas = fco.id_empresas AND
                      fco.Fecha >= fce.Desde AND
                      fco.Fecha <= fce.Hasta AND
                      fce.Del_WHEN IS NULL AND
                      fce.Tipo_Ventas_o_Compras_VC = 'V'
                   WHERE fco.id = param_id_facturas
                   ORDER BY fco.id ) THEN
        BEGIN
			    -- ----------------------------------------------------------------------------------------------------------------- --
			    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
			    -- ----------------------------------------------------------------------------------------------------------------- --
			    IF param_id_facturas <> 0 THEN
			        BEGIN
							-- --------------------------------------------------------------------------------------------------------- --
							-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
							-- --------------------------------------------------------------------------------------------------------- --
			        		DELETE FROM facturas_ventas_impuestos
							WHERE id_facturas = param_id_facturas 
							ORDER BY id_facturas ASC, id_impuestos ASC;
							
							-- --------------------------------------------------------------------------------------------------------- --
							-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
							-- ENGLOBAN. PERO SOLO SI NO EXISTEN
							-- --------------------------------------------------------------------------------------------------------- --
							INSERT INTO facturas_ventas_impuestos
							          ( id_facturas,
							            Base,
							            Importe,
							            Insert_Id_User,
							            Insert_WHEN, 
							            id_impuestos )
							
							SELECT * FROM ( SELECT param_id_facturas,
							
														  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
														                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(Unidades, 1) * PVP) -
														                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
														    FROM facturas_ventas_detalles  
							                         WHERE id_facturas = param_id_facturas 
														    AND Del_WHEN IS NULL
														    AND Excluido_su_Cobro_SN <> 'S'
														    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) AS a,
							                     
							                     0 as b,
							                     
							                     param_id_users,
							                     NOW(),
							                     
							                     i_p.id_impuestos
							                     
							                FROM impuestos_composiciones AS i_p
							              
							                RIGHT JOIN facturas_ventas_detalles AS f_c_d
							                ON f_c_d.id_facturas = param_id_facturas AND
							                   f_c_d.Del_WHEN IS NULL
							              
							              
							                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_ventas
							                AND i_p.Del_WHEN IS NULL
							                GROUP BY i_p.id_impuestos
							                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
							              ) AS tmp
							
							WHERE NOT EXISTS ( SELECT *
							                  FROM facturas_ventas_impuestos
							                  WHERE id_facturas = param_id_facturas
							                  AND id_impuestos = tmp.id_impuestos
							                  ORDER BY id_facturas ASC, id_impuestos ASC 
							                );
							                
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
							-- NO EXISTEN
							-- --------------------------------------------------------------------------------------------------------- --
							INSERT INTO facturas_ventas_impuestos
							          ( id_facturas,
							            Base,
							            Importe,
							            Insert_Id_User,
							            Insert_WHEN, 
							            id_impuestos )
							
							SELECT * FROM ( SELECT param_id_facturas,
							
														  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
														                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(Unidades, 1) * PVP) -
														                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
														    FROM facturas_ventas_detalles  
							                         WHERE id_facturas = param_id_facturas 
														    AND Del_WHEN IS NULL
														    AND Excluido_su_Cobro_SN <> 'S'
														    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) as a,
							                     
							                     0 as b,
							                     
							                     param_id_users,
							                     NOW(),
							                     
							                     i.id
							                     
							                FROM impuestos AS i
							              
							                RIGHT JOIN facturas_ventas_detalles AS f_c_d
							                ON f_c_d.id_facturas = param_id_facturas AND
							                   f_c_d.Del_WHEN IS NULL
							              
							              
							                WHERE i.id = f_c_d.id_impuestos_ventas
							                AND NOT i.Tanto_Por_Ciento IS NULL
							                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en facturas_ventas_detalles
							                GROUP BY i.id
							                ORDER BY i.id ASC
							              ) AS tmp
							
							WHERE NOT EXISTS ( SELECT *
							                  FROM facturas_ventas_impuestos
							                  WHERE id_facturas = param_id_facturas
							                  AND id_impuestos = tmp.id
							                  ORDER BY id_facturas ASC, id_impuestos ASC 
							                );
			
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
							-- DETALLE DE LA FACTURA
							-- --------------------------------------------------------------------------------------------------------- --
							UPDATE facturas_ventas_impuestos
							SET facturas_ventas_impuestos.Importe = ( facturas_ventas_impuestos.Base * 
							                                           ( SELECT Tanto_Por_Ciento 
							                									   FROM impuestos
							                									   WHERE impuestos.id = facturas_ventas_impuestos.id_impuestos ) )
							                								  / 100	   
							WHERE facturas_ventas_impuestos.id_facturas = param_id_facturas;
			
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
							-- DETALLE DE LA FACTURA
							-- --------------------------------------------------------------------------------------------------------- --
							UPDATE facturas_ventas
			
							SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                        FROM facturas_ventas_detalles AS f_c_d
							                        
							                        RIGHT JOIN articulos AS a
							                        ON a.id = f_c_d.id_articulos AND
							                           a.Tipo_de_articulo = 2
							                        
			 				                        WHERE f_c_d.id_facturas = param_id_facturas 
			 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
														   AND f_c_d.Del_WHEN IS NULL ),
														    
			 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                         FROM facturas_ventas_detalles AS f_c_d
							                        
							                         RIGHT JOIN articulos AS a
							                         ON a.id = f_c_d.id_articulos AND
							                            a.Tipo_de_articulo = 0
							                        
			 				                         WHERE f_c_d.id_facturas = param_id_facturas 
			 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
														    AND f_c_d.Del_WHEN IS NULL ),
														   
								 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
														            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
														              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
																  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                    FROM facturas_ventas_detalles AS f_c_d
							                        
							                    RIGHT JOIN articulos AS a
							                    ON a.id = f_c_d.id_articulos AND
							                       (  ( a.Tipo_de_articulo <> 0 AND
							                            a.Tipo_de_articulo <> 2 )
																 OR 
															  ( a.Tipo_de_articulo IS NULL ) ) 	 
							                        
			 				                    WHERE f_c_d.id_facturas = param_id_facturas 
			 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
													  AND f_c_d.Del_WHEN IS NULL ),
														   
								 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
			                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
																	 
			                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
			                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
			                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
							                     FROM facturas_ventas_detalles AS f_c_d
			 				                     WHERE f_c_d.id_facturas = param_id_facturas 
			 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
													   AND f_c_d.Del_WHEN IS NULL ),
														   
			 					 Total_Total = Total_Lineas + 
								                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM facturas_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_facturas = param_id_facturas 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM facturas_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_facturas = param_id_facturas 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

							WHERE id = param_id_facturas;
							
							-- --------------------------------------------------------------------------------------------------------- --
							-- AHORA VAMOS A CREAR SUS VENCIMIENTOS/RECIBOS (CARTERA)
							-- --------------------------------------------------------------------------------------------------------- --
							CALL function_Recibos_Crear_a_Ftra( 'C', param_id_facturas, param_id_users );
										
			        END;
			    END IF;	
			    
        END;
	 END IF;

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_pedidos_compras
DROP PROCEDURE IF EXISTS `function_ACT_totales_pedidos_compras`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_pedidos_compras`(IN `param_id_pedidos` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_pedidos <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM pedidos_compras_impuestos
				WHERE id_pedidos = param_id_pedidos 
				ORDER BY id_pedidos ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO pedidos_compras_impuestos
				          ( id_pedidos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_pedidos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM pedidos_compras_detalles  
				                         WHERE id_pedidos = param_id_pedidos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN pedidos_compras_detalles AS f_c_d
				                ON f_c_d.id_pedidos = param_id_pedidos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_Compras
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM pedidos_compras_impuestos
				                  WHERE id_pedidos = param_id_pedidos
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_pedidos ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO pedidos_compras_impuestos
				          ( id_pedidos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_pedidos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM pedidos_compras_detalles  
				                         WHERE id_pedidos = param_id_pedidos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN pedidos_compras_detalles AS f_c_d
				                ON f_c_d.id_pedidos = param_id_pedidos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_Compras
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en pedidos_compras_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM pedidos_compras_impuestos
				                  WHERE id_pedidos = param_id_pedidos
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_pedidos ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE pedidos_compras_impuestos
				SET pedidos_compras_impuestos.Importe = ( pedidos_compras_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = pedidos_compras_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE pedidos_compras_impuestos.id_pedidos = param_id_pedidos;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE pedidos_compras

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM pedidos_compras_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_pedidos = param_id_pedidos 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM pedidos_compras_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_pedidos = param_id_pedidos 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM pedidos_compras_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_pedidos = param_id_pedidos 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM pedidos_compras_detalles AS f_c_d
 				                     WHERE f_c_d.id_pedidos = param_id_pedidos 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM pedidos_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_pedidos = param_id_pedidos 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM pedidos_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_pedidos = param_id_pedidos 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

				WHERE id = param_id_pedidos;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_pedidos_ventas
DROP PROCEDURE IF EXISTS `function_ACT_totales_pedidos_ventas`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_pedidos_ventas`(IN `param_id_pedidos` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_pedidos <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM pedidos_ventas_impuestos
				WHERE id_pedidos = param_id_pedidos 
				ORDER BY id_pedidos ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO pedidos_ventas_impuestos
				          ( id_pedidos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_pedidos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM pedidos_ventas_detalles  
				                         WHERE id_pedidos = param_id_pedidos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN pedidos_ventas_detalles AS f_c_d
				                ON f_c_d.id_pedidos = param_id_pedidos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_ventas
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM pedidos_ventas_impuestos
				                  WHERE id_pedidos = param_id_pedidos
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_pedidos ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO pedidos_ventas_impuestos
				          ( id_pedidos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_pedidos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM pedidos_ventas_detalles  
				                         WHERE id_pedidos = param_id_pedidos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN pedidos_ventas_detalles AS f_c_d
				                ON f_c_d.id_pedidos = param_id_pedidos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_ventas
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en pedidos_ventas_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM pedidos_ventas_impuestos
				                  WHERE id_pedidos = param_id_pedidos
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_pedidos ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE pedidos_ventas_impuestos
				SET pedidos_ventas_impuestos.Importe = ( pedidos_ventas_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = pedidos_ventas_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE pedidos_ventas_impuestos.id_pedidos = param_id_pedidos;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE pedidos_ventas

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM pedidos_ventas_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_pedidos = param_id_pedidos 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM pedidos_ventas_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_pedidos = param_id_pedidos 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM pedidos_ventas_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_pedidos = param_id_pedidos 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM pedidos_ventas_detalles AS f_c_d
 				                     WHERE f_c_d.id_pedidos = param_id_pedidos 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM pedidos_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_pedidos = param_id_pedidos 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM pedidos_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_pedidos = param_id_pedidos 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

				WHERE id = param_id_pedidos;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_presupuestos_compras
DROP PROCEDURE IF EXISTS `function_ACT_totales_presupuestos_compras`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_presupuestos_compras`(IN `param_id_presupuestos` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_presupuestos <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM presupuestos_compras_impuestos
				WHERE id_presupuestos = param_id_presupuestos 
				ORDER BY id_presupuestos ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO presupuestos_compras_impuestos
				          ( id_presupuestos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_presupuestos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM presupuestos_compras_detalles  
				                         WHERE id_presupuestos = param_id_presupuestos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN presupuestos_compras_detalles AS f_c_d
				                ON f_c_d.id_presupuestos = param_id_presupuestos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_Compras
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM presupuestos_compras_impuestos
				                  WHERE id_presupuestos = param_id_presupuestos
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_presupuestos ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO presupuestos_compras_impuestos
				          ( id_presupuestos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_presupuestos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM presupuestos_compras_detalles  
				                         WHERE id_presupuestos = param_id_presupuestos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_compras = f_c_d.id_impuestos_Compras ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN presupuestos_compras_detalles AS f_c_d
				                ON f_c_d.id_presupuestos = param_id_presupuestos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_Compras
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en presupuestos_compras_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM presupuestos_compras_impuestos
				                  WHERE id_presupuestos = param_id_presupuestos
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_presupuestos ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE presupuestos_compras_impuestos
				SET presupuestos_compras_impuestos.Importe = ( presupuestos_compras_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = presupuestos_compras_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE presupuestos_compras_impuestos.id_presupuestos = param_id_presupuestos;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE presupuestos_compras

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM presupuestos_compras_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM presupuestos_compras_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM presupuestos_compras_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM presupuestos_compras_detalles AS f_c_d
 				                     WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
 					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM presupuestos_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_presupuestos = param_id_presupuestos 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM presupuestos_compras_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_presupuestos = param_id_presupuestos 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

				WHERE id = param_id_presupuestos;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ACT_totales_presupuestos_ventas
DROP PROCEDURE IF EXISTS `function_ACT_totales_presupuestos_ventas`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ACT_totales_presupuestos_ventas`(IN `param_id_presupuestos` BIGINT, IN `param_id_users` BIGINT)
BEGIN
    -- ----------------------------------------------------------------------------------------------------------------- --
    -- SOLO ACTUALIZAREMOS SUS IMPUESTOS SI SE INTRODUJO LA ID DE LA FACTURA
    -- ----------------------------------------------------------------------------------------------------------------- --
    IF param_id_presupuestos <> 0 THEN
        BEGIN
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SE BORRAN TODOS LOS CALCULOS DE IMPUESTOS DE LA FACTURA 
				-- --------------------------------------------------------------------------------------------------------- --
        		DELETE FROM presupuestos_ventas_impuestos
				WHERE id_presupuestos = param_id_presupuestos 
				ORDER BY id_presupuestos ASC, id_impuestos ASC;
				
				-- --------------------------------------------------------------------------------------------------------- --
				-- PRIMERO, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS COMPUESTOS, CREAMOS LOS IMPUESTOS QUE LOS 
				-- ENGLOBAN. PERO SOLO SI NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO presupuestos_ventas_impuestos
				          ( id_presupuestos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_presupuestos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM presupuestos_ventas_detalles  
				                         WHERE id_presupuestos = param_id_presupuestos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) AS a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i_p.id_impuestos
				                     
				                FROM impuestos_composiciones AS i_p
				              
				                RIGHT JOIN presupuestos_ventas_detalles AS f_c_d
				                ON f_c_d.id_presupuestos = param_id_presupuestos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i_p.id_impuestos_al_que_pertenece = f_c_d.id_impuestos_ventas
				                AND i_p.Del_WHEN IS NULL
				                GROUP BY i_p.id_impuestos
				                ORDER BY i_p.id_impuestos_al_que_pertenece ASC, i_p.id_impuestos ASC 
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM presupuestos_ventas_impuestos
				                  WHERE id_presupuestos = param_id_presupuestos
				                  AND id_impuestos = tmp.id_impuestos
				                  ORDER BY id_presupuestos ASC, id_impuestos ASC 
				                );
				                
				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA, SI LAS LINEAS DE DETALLE DE LA FACTURA TIENE IMPUESTOS NO COMPUESTOS, LOS CREAMOS. PERO SOLO SI 
				-- NO EXISTEN
				-- --------------------------------------------------------------------------------------------------------- --
				INSERT INTO presupuestos_ventas_impuestos
				          ( id_presupuestos,
				            Base,
				            Importe,
				            Insert_Id_User,
				            Insert_WHEN, 
				            id_impuestos )
				
				SELECT * FROM ( SELECT param_id_presupuestos,
				
											  ( SELECT SUM(  (IFNULL(Unidades, 1) * PVP) -
											                 ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(Unidades, 1) * PVP) -
											                   ((IFNULL(Unidades, 1) * PVP) * IFNULL(Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(Descuento_Comercial_2, 0) /100  ) 
											    FROM presupuestos_ventas_detalles  
				                         WHERE id_presupuestos = param_id_presupuestos 
											    AND Del_WHEN IS NULL
											    AND Excluido_su_Cobro_SN <> 'S'
											    AND id_impuestos_ventas = f_c_d.id_impuestos_ventas ) as a,
				                     
				                     0 as b,
				                     
				                     param_id_users,
				                     NOW(),
				                     
				                     i.id
				                     
				                FROM impuestos AS i
				              
				                RIGHT JOIN presupuestos_ventas_detalles AS f_c_d
				                ON f_c_d.id_presupuestos = param_id_presupuestos AND
				                   f_c_d.Del_WHEN IS NULL
				              
				              
				                WHERE i.id = f_c_d.id_impuestos_ventas
				                AND NOT i.Tanto_Por_Ciento IS NULL
				                -- AND i.Del_WHEN IS NULL no ponerlo porque pueden haber dado de baja el impuesto aunque ha sido usado en presupuestos_ventas_detalles
				                GROUP BY i.id
				                ORDER BY i.id ASC
				              ) AS tmp
				
				WHERE NOT EXISTS ( SELECT *
				                  FROM presupuestos_ventas_impuestos
				                  WHERE id_presupuestos = param_id_presupuestos
				                  AND id_impuestos = tmp.id
				                  ORDER BY id_presupuestos ASC, id_impuestos ASC 
				                );

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS LOS IMPUESTOS CREADOS, VAMOS A PONERLE SUS BASES IMPONIBLES, SEGUN LAS LINEAS DE 
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE presupuestos_ventas_impuestos
				SET presupuestos_ventas_impuestos.Importe = ( presupuestos_ventas_impuestos.Base * 
				                                           ( SELECT Tanto_Por_Ciento 
				                									   FROM impuestos
				                									   WHERE impuestos.id = presupuestos_ventas_impuestos.id_impuestos ) )
				                								  / 100	   
				WHERE presupuestos_ventas_impuestos.id_presupuestos = param_id_presupuestos;

				-- --------------------------------------------------------------------------------------------------------- --
				-- AHORA QUE YA TENEMOS ACTUALIZADOS LOS IMPUESTOS, PUES VAMOS A ACTUALIZAR LOS TOTALES DE LA FACTURA
				-- DETALLE DE LA FACTURA
				-- --------------------------------------------------------------------------------------------------------- --
				UPDATE presupuestos_ventas

				SET Total_Mano_Obra = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                  ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		    * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                        FROM presupuestos_ventas_detalles AS f_c_d
				                        
				                        RIGHT JOIN articulos AS a
				                        ON a.id = f_c_d.id_articulos AND
				                           a.Tipo_de_articulo = 2
				                        
 				                        WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											   AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											   AND f_c_d.Del_WHEN IS NULL ),
											    
 					 Total_Materiales = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                 ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											                 ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											                   ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		     * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                         FROM presupuestos_ventas_detalles AS f_c_d
				                        
				                         RIGHT JOIN articulos AS a
				                         ON a.id = f_c_d.id_articulos AND
				                            a.Tipo_de_articulo = 0
				                        
 				                         WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											    AND f_c_d.Excluido_su_Cobro_SN <> 'S'
											    AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Resto = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											            ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
											            ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
											              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
													  		* IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                    FROM presupuestos_ventas_detalles AS f_c_d
				                        
				                    RIGHT JOIN articulos AS a
				                    ON a.id = f_c_d.id_articulos AND
				                       (  ( a.Tipo_de_articulo <> 0 AND
				                            a.Tipo_de_articulo <> 2 )
													 OR 
												  ( a.Tipo_de_articulo IS NULL ) ) 	 
				                        
 				                    WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 										  AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										  AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Lineas = ( SELECT SUM(  (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                              ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) -
														 
                                              ( (IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) -
                                                ((IFNULL(f_c_d.Unidades, 1) * f_c_d.PVP) * IFNULL(f_c_d.Descuento_Comercial_1, 0) /100) ) 
                                              * IFNULL(f_c_d.Descuento_Comercial_2, 0) /100  ) 
				                     FROM presupuestos_ventas_detalles AS f_c_d
 				                     WHERE f_c_d.id_presupuestos = param_id_presupuestos 
 											AND f_c_d.Excluido_su_Cobro_SN <> 'S'
										   AND f_c_d.Del_WHEN IS NULL ),
											   
					 Total_Total = Total_Lineas + 
					                   (   IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
                                                FROM presupuestos_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos 
 				                                    WHERE f_c_i.id_presupuestos = param_id_presupuestos 
										                  AND f_c_i.Del_WHEN IS NULL 
										                  AND i.Sumado_A_Ftra_SN = 'S' ), 0)
												  -
												  IFNULL( ( SELECT SUM(IFNULL(Importe, 0))
				                                    FROM presupuestos_ventas_impuestos AS f_c_i
                                                LEFT JOIN impuestos AS i
													         ON i.id = f_c_i.id_impuestos
 				                                    WHERE f_c_i.id_presupuestos = param_id_presupuestos 
										                  AND f_c_i.Del_WHEN IS NULL 
													         AND i.Sumado_A_Ftra_SN <> 'S' ), 0)   )
											   

				WHERE id = param_id_presupuestos;

        END;
    END IF;	

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_Articulos_Crear_en_Stock
DROP PROCEDURE IF EXISTS `function_Articulos_Crear_en_Stock`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_Articulos_Crear_en_Stock`(IN `param_id_articulos` BIGINT, IN `param_id_almacenes` BIGINT)
BEGIN
	IF NOT EXISTS( SELECT * FROM articulos_stock
						WHERE id_articulos = param_id_articulos
						AND id_almacenes = param_id_almacenes
						ORDER BY id_almacenes ASC, id_almacenes ASC ) THEN
		begin
			INSERT INTO articulos_stock
				( id_articulos,
			  	  id_almacenes,
			     Stock )
			VALUES ( param_id_articulos,
			   	   param_id_almacenes,
				   	0 );
		end;
	END IF;

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_ejecutar
DROP PROCEDURE IF EXISTS `function_ejecutar`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_ejecutar`(IN `Param1` LINESTRING)
BEGIN
SET @snt = Param1; 
PREPARE sent FROM @snt;
EXECUTE sent;
DEALLOCATE PREPARE sent;

END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_Recibos_Borrar_a_Ftra
DROP PROCEDURE IF EXISTS `function_Recibos_Borrar_a_Ftra`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_Recibos_Borrar_a_Ftra`(IN `param_clientes_o_proveedores` CHAR(1), IN `param_id_facturas` BIGINT)
BEGIN
		-- ----------------------------------------------------------------------------------------------------------------- --
		-- SOLO ACTUALIZAREMOS SUS RECIBOS SI SE INTRODUJO LA ID DE LA FACTURA
		-- ----------------------------------------------------------------------------------------------------------------- --
		IF param_id_facturas <> 0 THEN
			BEGIN
        		IF param_clientes_o_proveedores = 'C' THEN
        		
        			-- ------------------------------------------------------------------------------------------------------ --
        			-- SE TRATA DE UNA FACTURA DE VENTAS
        			-- ------------------------------------------------------------------------------------------------------ --
        			BEGIN
        				-- --------------------------------------------------------------------------------------------------- --
        				-- SI NO ESTA CERRADA LA FACTURA PUES CREAMOS SUS RECIBOS / CARTERA
        				-- --------------------------------------------------------------------------------------------------- --
						IF NOT EXISTS( SELECT fco.*
						               FROM facturas_ventas AS fco
						               RIGHT JOIN facturas_cerradas AS fce
						               ON fce.id_empresas = fco.id_empresas AND
						                  fco.Fecha >= fce.Desde AND
						                  fco.Fecha <= fce.Hasta AND
						                  fce.Del_WHEN IS NULL AND
						                  fce.Tipo_Ventas_o_Compras_VC = 'V'
						               WHERE fco.id = param_id_facturas
						               ORDER BY fco.id ) THEN
							BEGIN
								-- --------------------------------------------------------------------------------------------- --
								-- PRIMERO, SE BORRAN TODOS LOS VENCIMIENTOS QUE TUVIERA LA FACTURA 
								-- --------------------------------------------------------------------------------------------- --
								DELETE FROM facturas_cobros_pagos
								WHERE id_facturas = param_id_facturas 
		            		AND NOT id_clientes IS NULL
		            		ORDER BY id_clientes ASC, id_facturas ASC, id ASC;
							END;
						END IF;			
						
					END;
					
					
				ELSE
				
				
        			-- ------------------------------------------------------------------------------------------------------ --
        			-- SE TRATA DE UNA FACTURA DE COMPRAS
        			-- ------------------------------------------------------------------------------------------------------ --
        			BEGIN
        				-- --------------------------------------------------------------------------------------------------- --
        				-- SI NO ESTA CERRADA LA FACTURA PUES CREAMOS SUS RECIBOS / CARTERA
        				-- --------------------------------------------------------------------------------------------------- --
						IF NOT EXISTS( SELECT fco.*
					                  FROM facturas_compras AS fco
					                  RIGHT JOIN facturas_cerradas AS fce
					                  ON fce.id_empresas = fco.id_empresas AND
					                     fco.Fecha >= fce.Desde AND
					                     fco.Fecha <= fce.Hasta AND
					                     fce.Del_WHEN IS NULL AND
					                     fce.Tipo_Ventas_o_Compras_VC = 'C'
					                  WHERE fco.id = param_id_facturas
					                  ORDER BY fco.id ) THEN
					        BEGIN
									-- --------------------------------------------------------------------------------------------------- --
									-- PRIMERO, SE BORRAN TODOS LOS VENCIMIENTOS QUE TUVIERA LA FACTURA 
									-- --------------------------------------------------------------------------------------------------- --
									DELETE FROM facturas_cobros_pagos
									WHERE id_facturas = param_id_facturas 
			            		AND NOT id_proveedores IS NULL
			            		ORDER BY id_proveedores ASC, id_facturas ASC, id ASC;
							  END;
						END IF;	
				
					END;
				END IF;	
				
			END;
		END IF;				


END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.function_Recibos_Crear_a_Ftra
DROP PROCEDURE IF EXISTS `function_Recibos_Crear_a_Ftra`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `function_Recibos_Crear_a_Ftra`(IN `param_clientes_o_proveedores` CHAR(1), IN `param_id_facturas` BIGINT, IN `param_id_users` BIGINT)
BEGIN
		-- ----------------------------------------------------------------------------------------------------------------- --
		-- SOLO ACTUALIZAREMOS SUS RECIBOS SI SE INTRODUJO LA ID DE LA FACTURA
		-- ----------------------------------------------------------------------------------------------------------------- --
		IF param_id_facturas <> 0 THEN
			BEGIN
				DECLARE var_Cliente_o_Proveedor BIGINT;
				DECLARE var_fecha_ftra DATETIME;
				DECLARE var_Vencimientos_Cantidad TINYINT;
				DECLARE var_Vencimientos_1_Dias TINYINT;
				DECLARE var_Vencimientos_Dias_Entre TINYINT;
				
				DECLARE var_donde_estoy TINYINT DEFAULT 0;
				DECLARE var_cantidad_que_queda DECIMAL(12,2);
				DECLARE var_cantidad_por_recibo DECIMAL(12,2);
				DECLARE var_total_ftra DECIMAL(12,2);
				DECLARE var_importe_recibo DECIMAL(12,2);
				DECLARE var_fecha_vencimiento DATETIME;
				DECLARE var_Vencimientos_automaticos_SN CHAR(1);
				
				DECLARE var_Year VARCHAR(15);
				DECLARE var_Month VARCHAR(15);
				DECLARE var_Day VARCHAR(15);
				DECLARE var_Hora VARCHAR(15);
				
				DECLARE var_Forma_pago_Dia_1 TINYINT DEFAULT 0;
				DECLARE var_Forma_pago_Dia_2 TINYINT DEFAULT 0;
				
        		IF param_clientes_o_proveedores = 'C' THEN
        		
        			-- ------------------------------------------------------------------------------------------------------ --
        			-- SE TRATA DE UNA FACTURA DE VENTAS
        			-- ------------------------------------------------------------------------------------------------------ --
        			BEGIN
        				-- --------------------------------------------------------------------------------------------------- --
        				-- SI NO ESTA CERRADA LA FACTURA PUES CREAMOS SUS RECIBOS / CARTERA
        				-- --------------------------------------------------------------------------------------------------- --
						IF NOT EXISTS( SELECT fco.*
						               FROM facturas_ventas AS fco
						               RIGHT JOIN facturas_cerradas AS fce
						               ON fce.id_empresas = fco.id_empresas AND
						                  fco.Fecha >= fce.Desde AND
						                  fco.Fecha <= fce.Hasta AND
						                  fce.Del_WHEN IS NULL AND
						                  fce.Tipo_Ventas_o_Compras_VC = 'V'
						               WHERE fco.id = param_id_facturas
						               ORDER BY fco.id ) THEN
							BEGIN
								-- --------------------------------------------------------------------------------------------- --
								-- PRIMERO, SE BORRAN TODOS LOS VENCIMIENTOS QUE TUVIERA LA FACTURA 
								-- --------------------------------------------------------------------------------------------- --
								CALL function_Recibos_Borrar_a_Ftra( param_clientes_o_proveedores, param_id_facturas );

								-- --------------------------------------------------------------------------------------------- --
								-- Traemos de la factura de ventas los datos que necesitamos            		
								-- --------------------------------------------------------------------------------------------- --
								SELECT f.id_clientes, 
										 f.Fecha,
										 f.Vencimientos_Cantidad,
										 f.Vencimientos_1_Dias,
										 f.Vencimientos_Dias_Entre,
										 f.Total_Total,
										 IFNULL(f.Forma_pago_Dia_1, 0),
										 IFNULL(f.Forma_pago_Dia_2, 0)
										 
								INTO var_Cliente_o_Proveedor, 
								     var_fecha_ftra,
								     var_Vencimientos_Cantidad,
								     var_Vencimientos_1_Dias,
								     var_Vencimientos_Dias_Entre,
								     var_total_ftra,
								     var_Forma_pago_Dia_1,
								     var_Forma_pago_Dia_2
								     
								FROM facturas_ventas AS f
								WHERE f.id = param_id_facturas; 
							    
								-- --------------------------------------------------------------------------------------------- --
								-- AHORA PASAMOS A CREAR CADA UNO DE LOS VENCIMIENTOS QUE NECESITE LA FACTURA
								-- --------------------------------------------------------------------------------------------- --
								SET var_cantidad_por_recibo = var_total_ftra / var_Vencimientos_Cantidad;
								SET var_cantidad_que_queda = var_total_ftra;
								SET var_donde_estoy = 1;
								
								WHILE var_donde_estoy <= var_Vencimientos_Cantidad DO
									BEGIN
										-- --------------------------------------------------------------------------------------- --
										-- Vamos a ver cual es la cantidad para el próximo vencimiento
										-- --------------------------------------------------------------------------------------- --
										IF var_donde_estoy = var_Vencimientos_Cantidad THEN
											BEGIN
												SET var_importe_recibo = var_cantidad_que_queda;
											END;
										ELSE
											BEGIN
												SET var_importe_recibo = var_cantidad_por_recibo;
											END;
										END IF;
										
										SET var_cantidad_que_queda = var_cantidad_que_queda - var_importe_recibo;
										
										-- --------------------------------------------------------------------------------------- --
										-- Vamos a ver cual es la fecha para para el próximo vencimiento
										-- --------------------------------------------------------------------------------------- --
										SET var_fecha_vencimiento = DATE_ADD(var_fecha_ftra, INTERVAL (var_Vencimientos_1_Dias * var_donde_estoy) DAY);
										
										-- --------------------------------------------------------------------------------------- --
										-- Separamos el año, mes, dia y hora de la fecha de vencimiento
										-- --------------------------------------------------------------------------------------- --
										-- select YEAR(NOW());  #Selecciona el año
										-- select MONTH (NOW()) as mes;  #Selecciona el mes
										-- select DAY(NOW()) as dia; #Selecciona el día 
										-- select TIME(NOW()) as hora;  #Selecciona la hora
										-- Select LAST_DAY(NOW()); # Selecciona el ultimo dia del mes
										-- --------------------------------------------------------------------------------------- --
										-- VER EJEMPLOS EN ... http://www.cristalab.com/tutoriales/fechas-con-mysql-c84136l/
										-- --------------------------------------------------------------------------------------- --
										SET var_Year  = YEAR(var_fecha_vencimiento);  -- Selecciona el AÑO
										SET var_Month = MONTH(var_fecha_vencimiento); -- Selecciona el MES
										SET var_Day   = DAY(var_fecha_vencimiento);   -- Selecciona el DIA
										SET var_Hora  = TIME(var_fecha_vencimiento);  -- Selecciona la HORA
										
										-- --------------------------------------------------------------------------------------- --
										-- El primer día no puede ser mayor que el segundo día de pago
										-- --------------------------------------------------------------------------------------- --
										IF (var_Forma_pago_Dia_1 > var_Forma_pago_Dia_2) then
											BEGIN
												SET var_Forma_pago_Dia_1 = var_Forma_pago_Dia_2;
												SET var_Forma_pago_Dia_2 = var_Forma_pago_Dia_1;
											END;
										END IF;
										
										-- --------------------------------------------------------------------------------------- --
										-- Cambiamos el vencimiento solo si se puso algún día fijo de pago
										-- --------------------------------------------------------------------------------------- --
										IF var_Forma_pago_Dia_1 <> 0 OR
										   var_Forma_pago_Dia_2 <> 0 THEN
											BEGIN
												IF var_Day <= var_Forma_pago_Dia_2 AND
												   var_Day >= var_Forma_pago_Dia_1 THEN
													BEGIN
									            	-- --------------------------------------------------------------------------- --
													   -- El dia del vencimiento puede ser igual al primer día de pago o superior al 
														-- primer día de pago. Por lo que si es igual al primer día, pues lo dejamos, 
														-- pero si es mayor pues ponemos como vencimiento el segundo día de pago
									            	-- --------------------------------------------------------------------------- --
													   IF var_Day > var_Forma_pago_Dia_1 THEN
														   BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_2 )
																											 AS DATETIME );
														   END;
													   END IF;
													END;
												ELSE 
													BEGIN
									            	-- --------------------------------------------------------------------------- --
													   -- El día de pago puede ser inferior al primer día de pago o superior a el 
														-- segundo día.                                                     
									            	-- --------------------------------------------------------------------------- --
													   -- Imaginemos que los días de pago son 15 y 20 ...
													   -- Ahora el programa nos ha calculado como vencimiento el día 13, pues tenemos 
														-- que ponerle el 15.
													   -- Pero y si calculo el 21, pues tambien tenemos que ponerle el 15.
									            	-- --------------------------------------------------------------------------- --
													   -- Pero imaginemos que los días de pago son 0(no se puso el 1er.día) y 20 para 
														-- el segundo día de pago
													   -- Ahora el programa nos ha calculado como vencimiento el día 13, pues tenemos 
														-- que ponerle el 20.
													   -- Pero y si calculo el 21, pues tambien tenemos que ponerle el 20.
									            	-- --------------------------------------------------------------------------- --
													   if var_Forma_pago_Dia_1 <> 0 then
														   BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_1 )
																											 AS DATETIME );
														   END;
														ELSE 
															BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_2 )
																											 AS DATETIME );
														   END;
													   END IF;
													   
													END;
												END IF;

											END;
										END IF;
										
										-- --------------------------------------------------------------------------------------- --
										-- Pasamos a crear el vencimiento con todos los campos calculados hasta el momento
										-- --------------------------------------------------------------------------------------- --
										INSERT INTO facturas_cobros_pagos (
										   id_clientes, -- id_proveedores,
					
										   id_facturas,
										   fecha_expedicion,
										   
										   fecha_vencimiento,
										   importe,
										   
										   Insert_WHEN,
										   Insert_Id_User )
									   
										VALUES (
											var_Cliente_o_Proveedor,
											
											param_id_facturas,
											var_fecha_ftra,
											
										   var_fecha_vencimiento,
										   var_importe_recibo,
											
											NOW(),
											param_id_users );
											
										SET var_donde_estoy = var_donde_estoy + 1;
									END;
								END WHILE;
							END;
						END IF;			
						
					END;
					
					
				ELSE
				
				
        			-- ------------------------------------------------------------------------------------------------------ --
        			-- SE TRATA DE UNA FACTURA DE COMPRAS
        			-- ------------------------------------------------------------------------------------------------------ --
        			BEGIN
        				-- --------------------------------------------------------------------------------------------------- --
        				-- SI NO ESTA CERRADA LA FACTURA PUES CREAMOS SUS RECIBOS / CARTERA
        				-- --------------------------------------------------------------------------------------------------- --
						 IF NOT EXISTS( SELECT fco.*
					                   FROM facturas_compras AS fco
					                   RIGHT JOIN facturas_cerradas AS fce
					                   ON fce.id_empresas = fco.id_empresas AND
					                      fco.Fecha >= fce.Desde AND
					                      fco.Fecha <= fce.Hasta AND
					                      fce.Del_WHEN IS NULL AND
					                      fce.Tipo_Ventas_o_Compras_VC = 'C'
					                   WHERE fco.id = param_id_facturas
					                   ORDER BY fco.id ) THEN
					   	BEGIN
								-- --------------------------------------------------------------------------------------------------- --
								-- PRIMERO, SE BORRAN TODOS LOS VENCIMIENTOS QUE TUVIERA LA FACTURA 
								-- --------------------------------------------------------------------------------------------------- --
								CALL function_Recibos_Borrar_a_Ftra( param_clientes_o_proveedores, param_id_facturas );

								-- --------------------------------------------------------------------------------------------------- --
								-- Traemos de la factura de compras los datos que necesitamos            		
								-- --------------------------------------------------------------------------------------------------- --
								SELECT f.id_proveedores, 
										 f.Fecha,
										 f.Vencimientos_Cantidad,
										 f.Vencimientos_1_Dias,
										 f.Vencimientos_Dias_Entre,
										 f.Total_Total,
										 IFNULL(f.Forma_pago_Dia_1, 0),
										 IFNULL(f.Forma_pago_Dia_2, 0)
										 
								INTO var_Cliente_o_Proveedor, 
								     var_fecha_ftra,
								     var_Vencimientos_Cantidad,
								     var_Vencimientos_1_Dias,
								     var_Vencimientos_Dias_Entre,
								     var_total_ftra,
								     var_Forma_pago_Dia_1,
								     var_Forma_pago_Dia_2
								     
								FROM facturas_compras AS f
								WHERE f.id = param_id_facturas; 
							    
								-- --------------------------------------------------------------------------------------------------------- --
								-- AHORA PASAMOS A CREAR CADA UNO DE LOS VENCIMIENTOS QUE NECESITE LA FACTURA
								-- --------------------------------------------------------------------------------------------------------- --
								SET var_cantidad_por_recibo = var_total_ftra / var_Vencimientos_Cantidad;
								SET var_cantidad_que_queda = var_total_ftra;
								SET var_donde_estoy = 1;
								
								WHILE var_donde_estoy <= var_Vencimientos_Cantidad DO
									BEGIN
										-- --------------------------------------------------------------------------------------------------- --
										-- Vamos a ver cual es la cantidad para el próximo vencimiento
										-- --------------------------------------------------------------------------------------------------- --
										IF var_donde_estoy = var_Vencimientos_Cantidad THEN
											BEGIN
												SET var_importe_recibo = var_cantidad_que_queda;
											END;
										ELSE
											BEGIN
												SET var_importe_recibo = var_cantidad_por_recibo;
											END;
										END IF;
										
										SET var_cantidad_que_queda = var_cantidad_que_queda - var_importe_recibo;
										
										-- --------------------------------------------------------------------------------------------------- --
										-- Vamos a ver cual es la fecha para para el próximo vencimiento
										-- --------------------------------------------------------------------------------------------------- --
										SET var_fecha_vencimiento = DATE_ADD(var_fecha_ftra, INTERVAL (var_Vencimientos_1_Dias * var_donde_estoy) DAY);
										
										-- --------------------------------------------------------------------------------------- --
										-- Separamos el año, mes, dia y hora de la fecha de vencimiento
										-- --------------------------------------------------------------------------------------- --
										-- select YEAR(NOW());  #Selecciona el año
										-- select MONTH (NOW()) as mes;  #Selecciona el mes
										-- select DAY(NOW()) as dia; #Selecciona el día 
										-- select TIME(NOW()) as hora;  #Selecciona la hora
										-- Select LAST_DAY(NOW()); # Selecciona el ultimo dia del mes
										-- --------------------------------------------------------------------------------------- --
										-- VER EJEMPLOS EN ... http://www.cristalab.com/tutoriales/fechas-con-mysql-c84136l/
										-- --------------------------------------------------------------------------------------- --
										SET var_Year  = YEAR(var_fecha_vencimiento);  -- Selecciona el AÑO
										SET var_Month = MONTH(var_fecha_vencimiento); -- Selecciona el MES
										SET var_Day   = DAY(var_fecha_vencimiento);   -- Selecciona el DIA
										SET var_Hora  = TIME(var_fecha_vencimiento);  -- Selecciona la HORA
										
										-- --------------------------------------------------------------------------------------- --
										-- El primer día no puede ser mayor que el segundo día de pago
										-- --------------------------------------------------------------------------------------- --
										IF (var_Forma_pago_Dia_1 > var_Forma_pago_Dia_2) then
											BEGIN
												SET var_Forma_pago_Dia_1 = var_Forma_pago_Dia_2;
												SET var_Forma_pago_Dia_2 = var_Forma_pago_Dia_1;
											END;
										END IF;
										
										-- --------------------------------------------------------------------------------------- --
										-- Cambiamos el vencimiento solo si se puso algún día fijo de pago
										-- --------------------------------------------------------------------------------------- --
										IF var_Forma_pago_Dia_1 <> 0 OR
										   var_Forma_pago_Dia_2 <> 0 THEN
											BEGIN
												IF var_Day <= var_Forma_pago_Dia_2 AND
												   var_Day >= var_Forma_pago_Dia_1 THEN
													BEGIN
									            	-- --------------------------------------------------------------------------- --
													   -- El dia del vencimiento puede ser igual al primer día de pago o superior al 
														-- primer día de pago. Por lo que si es igual al primer día, pues lo dejamos, 
														-- pero si es mayor pues ponemos como vencimiento el segundo día de pago
									            	-- --------------------------------------------------------------------------- --
													   IF var_Day > var_Forma_pago_Dia_1 THEN
														   BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_2 )
																											 AS DATETIME );
														   END;
													   END IF;
													END;
												ELSE 
													BEGIN
									            	-- --------------------------------------------------------------------------- --
													   -- El día de pago puede ser inferior al primer día de pago o superior a el 
														-- segundo día.                                                     
									            	-- --------------------------------------------------------------------------- --
													   -- Imaginemos que los días de pago son 15 y 20 ...
													   -- Ahora el programa nos ha calculado como vencimiento el día 13, pues tenemos 
														-- que ponerle el 15.
													   -- Pero y si calculo el 21, pues tambien tenemos que ponerle el 15.
									            	-- --------------------------------------------------------------------------- --
													   -- Pero imaginemos que los días de pago son 0(no se puso el 1er.día) y 20 para 
														-- el segundo día de pago
													   -- Ahora el programa nos ha calculado como vencimiento el día 13, pues tenemos 
														-- que ponerle el 20.
													   -- Pero y si calculo el 21, pues tambien tenemos que ponerle el 20.
									            	-- --------------------------------------------------------------------------- --
													   if var_Forma_pago_Dia_1 <> 0 then
														   BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_1 )
																											 AS DATETIME );
														   END;
														ELSE 
															BEGIN
																SET var_fecha_vencimiento = CAST( CONCAT( TRIM(var_Year),
																                                          '-',
																                                  		   TRIM(var_Month),
																                                          '-',
														                                                var_Forma_pago_Dia_2 )
																											 AS DATETIME );
														   END;
													   END IF;
													   
													END;
												END IF;

											END;
										END IF;
										
										-- --------------------------------------------------------------------------------------- --
										-- Pasamos a crear el vencimiento con todos los campos calculados hasta el momento
										-- --------------------------------------------------------------------------------------- --
										INSERT INTO facturas_cobros_pagos (
										   id_proveedores, 
					
										   id_facturas,
										   fecha_expedicion,
										   
										   fecha_vencimiento,
										   importe,
										   
										   Insert_WHEN,
										   Insert_Id_User )
									   
										VALUES (
											var_Cliente_o_Proveedor,
											
											param_id_facturas,
											var_fecha_ftra,
											
										   var_fecha_vencimiento,
											var_importe_recibo,
											
											NOW(),
											param_id_users );
											
										SET var_donde_estoy = var_donde_estoy + 1;
									END;
								END WHILE;
								
							END;
						END IF;	
				
					END;
				END IF;	
				
			END;
		END IF;				


END//
DELIMITER ;


-- Volcando estructura para procedimiento socger.funct_Impresora_Predeterminada
DROP PROCEDURE IF EXISTS `funct_Impresora_Predeterminada`;
DELIMITER //
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `funct_Impresora_Predeterminada`(IN `param_id` BIGINT)
BEGIN
	UPDATE impresoras
	SET predeterminada_SN = 'N';

	UPDATE impresoras
	SET predeterminada_SN = 'S'
   WHERE id = param_id;
END//
DELIMITER ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
